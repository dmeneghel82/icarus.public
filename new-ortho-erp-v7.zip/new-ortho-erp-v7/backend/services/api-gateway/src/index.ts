import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { createProxyMiddleware } from 'http-proxy-middleware';
import swaggerUi from 'swagger-ui-express';
import YAML from 'yamljs';
import dotenv from 'dotenv';
import { authMiddleware } from './middleware/auth';
import { errorHandler } from './middleware/errorHandler';
import { logger } from './utils/logger';
import { redisClient } from './utils/redis';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8000;

// ======================
// SECURITY MIDDLEWARE
// ======================

// Security headers
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      scriptSrc: ["'self'"],
    },
  },
}));

// CORS configuration
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://app.neworth.com'] 
    : ['http://localhost:3000', 'http://localhost:3001'],
  credentials: true,
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
});
app.use(limiter);

// Logging
app.use(morgan('combined', { stream: { write: message => logger.info(message.trim()) } }));

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ======================
// API DOCUMENTATION
// ======================

// Load Swagger documentation
try {
  const swaggerDocument = YAML.load('./docs/swagger.yml');
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
} catch (error) {
  logger.warn('Swagger documentation not found');
}

// ======================
// HEALTH CHECK
// ======================

app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: process.env.npm_package_version || '1.0.0',
  });
});

// ======================
// MICROSERVICES ROUTING
// ======================

// Auth Service Routes
app.use('/api/auth', createProxyMiddleware({
  target: 'http://auth-service:8001',
  changeOrigin: true,
  pathRewrite: {
    '^/api/auth': '/api',
  },
  onError: (err, req, res) => {
    logger.error('Auth Service Error:', err);
    res.status(503).json({ error: 'Auth service unavailable' });
  },
}));

// User Service Routes (Protected)
app.use('/api/users', authMiddleware, createProxyMiddleware({
  target: 'http://user-service:8002',
  changeOrigin: true,
  pathRewrite: {
    '^/api/users': '/api',
  },
  onError: (err, req, res) => {
    logger.error('User Service Error:', err);
    res.status(503).json({ error: 'User service unavailable' });
  },
}));

// Cadastros Service Routes (Protected)
app.use('/api/cadastros', authMiddleware, createProxyMiddleware({
  target: 'http://cadastros-service:8003',
  changeOrigin: true,
  pathRewrite: {
    '^/api/cadastros': '/api',
  },
  onError: (err, req, res) => {
    logger.error('Cadastros Service Error:', err);
    res.status(503).json({ error: 'Cadastros service unavailable' });
  },
}));

// Surgery Service Routes (Protected)
app.use('/api/cirurgias', authMiddleware, createProxyMiddleware({
  target: 'http://surgery-service:8004',
  changeOrigin: true,
  pathRewrite: {
    '^/api/cirurgias': '/api',
  },
  onError: (err, req, res) => {
    logger.error('Surgery Service Error:', err);
    res.status(503).json({ error: 'Surgery service unavailable' });
  },
}));

// Inventory Service Routes (Protected)
app.use('/api/estoque', authMiddleware, createProxyMiddleware({
  target: 'http://inventory-service:8005',
  changeOrigin: true,
  pathRewrite: {
    '^/api/estoque': '/api',
  },
  onError: (err, req, res) => {
    logger.error('Inventory Service Error:', err);
    res.status(503).json({ error: 'Inventory service unavailable' });
  },
}));

// Financial Service Routes (Protected)
app.use('/api/financeiro', authMiddleware, createProxyMiddleware({
  target: 'http://financial-service:8006',
  changeOrigin: true,
  pathRewrite: {
    '^/api/financeiro': '/api',
  },
  onError: (err, req, res) => {
    logger.error('Financial Service Error:', err);
    res.status(503).json({ error: 'Financial service unavailable' });
  },
}));

// Dashboard Service Routes (Protected)
app.use('/api/dashboard', authMiddleware, createProxyMiddleware({
  target: 'http://dashboard-service:8007',
  changeOrigin: true,
  pathRewrite: {
    '^/api/dashboard': '/api',
  },
  onError: (err, req, res) => {
    logger.error('Dashboard Service Error:', err);
    res.status(503).json({ error: 'Dashboard service unavailable' });
  },
}));

// ======================
// ERROR HANDLING
// ======================

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.originalUrl} not found`,
    timestamp: new Date().toISOString(),
  });
});

// Global error handler
app.use(errorHandler);

// ======================
// SERVER STARTUP
// ======================

const startServer = async () => {
  try {
    // Test Redis connection
    await redisClient.ping();
    logger.info('Connected to Redis');

    // Start server
    app.listen(PORT, () => {
      logger.info(`🚀 NEW ORTHO API Gateway running on port ${PORT}`);
      logger.info(`📚 API Documentation: http://localhost:${PORT}/api-docs`);
      logger.info(`💚 Health Check: http://localhost:${PORT}/health`);
    });

  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received. Shutting down gracefully...');
  await redisClient.quit();
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received. Shutting down gracefully...');
  await redisClient.quit();
  process.exit(0);
});

startServer();