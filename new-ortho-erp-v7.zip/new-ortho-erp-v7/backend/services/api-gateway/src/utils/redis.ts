import { createClient } from 'redis';
import { logger } from './logger';

const redisUrl = process.env.REDIS_URL || 'redis://ortho_redis_2025@localhost:6379';

export const redisClient = createClient({
  url: redisUrl,
  socket: {
    reconnectStrategy: (retries) => Math.min(retries * 50, 1000),
  },
});

// Redis event handlers
redisClient.on('connect', () => {
  logger.info('Redis client connected');
});

redisClient.on('ready', () => {
  logger.info('Redis client ready');
});

redisClient.on('error', (error) => {
  logger.error('Redis client error:', error);
});

redisClient.on('end', () => {
  logger.info('Redis client connection ended');
});

redisClient.on('reconnecting', () => {
  logger.info('Redis client reconnecting');
});

// Connect to Redis
redisClient.connect().catch((error) => {
  logger.error('Failed to connect to Redis:', error);
});

// Redis utility functions
export class RedisService {
  static async set(key: string, value: string, expireInSeconds?: number): Promise<void> {
    try {
      if (expireInSeconds) {
        await redisClient.setEx(key, expireInSeconds, value);
      } else {
        await redisClient.set(key, value);
      }
    } catch (error) {
      logger.error('Redis SET error:', error);
      throw error;
    }
  }

  static async get(key: string): Promise<string | null> {
    try {
      return await redisClient.get(key);
    } catch (error) {
      logger.error('Redis GET error:', error);
      throw error;
    }
  }

  static async del(key: string): Promise<void> {
    try {
      await redisClient.del(key);
    } catch (error) {
      logger.error('Redis DEL error:', error);
      throw error;
    }
  }

  static async exists(key: string): Promise<boolean> {
    try {
      const exists = await redisClient.exists(key);
      return exists === 1;
    } catch (error) {
      logger.error('Redis EXISTS error:', error);
      throw error;
    }
  }

  static async increment(key: string, by: number = 1): Promise<number> {
    try {
      return await redisClient.incrBy(key, by);
    } catch (error) {
      logger.error('Redis INCREMENT error:', error);
      throw error;
    }
  }

  static async setHash(key: string, field: string, value: string): Promise<void> {
    try {
      await redisClient.hSet(key, field, value);
    } catch (error) {
      logger.error('Redis HSET error:', error);
      throw error;
    }
  }

  static async getHash(key: string, field: string): Promise<string | undefined> {
    try {
      return await redisClient.hGet(key, field);
    } catch (error) {
      logger.error('Redis HGET error:', error);
      throw error;
    }
  }

  static async getAllHash(key: string): Promise<Record<string, string>> {
    try {
      return await redisClient.hGetAll(key);
    } catch (error) {
      logger.error('Redis HGETALL error:', error);
      throw error;
    }
  }

  static async addToSet(key: string, members: string[]): Promise<void> {
    try {
      await redisClient.sAdd(key, members);
    } catch (error) {
      logger.error('Redis SADD error:', error);
      throw error;
    }
  }

  static async isSetMember(key: string, member: string): Promise<boolean> {
    try {
      return await redisClient.sIsMember(key, member);
    } catch (error) {
      logger.error('Redis SISMEMBER error:', error);
      throw error;
    }
  }

  static async getSetMembers(key: string): Promise<string[]> {
    try {
      return await redisClient.sMembers(key);
    } catch (error) {
      logger.error('Redis SMEMBERS error:', error);
      throw error;
    }
  }

  static async removeFromSet(key: string, members: string[]): Promise<void> {
    try {
      await redisClient.sRem(key, members);
    } catch (error) {
      logger.error('Redis SREM error:', error);
      throw error;
    }
  }
}

export default redisClient;