import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { AIOrchestrator } from './orchestrator/AIOrchestrator';
import { logger } from './utils/logger';
import { redisClient } from './utils/redis';
import { aiRoutes } from './routes/ai';
import { healthRoutes } from './routes/health';
import { metricsRoutes } from './routes/metrics';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8010;

// ======================
// MIDDLEWARE
// ======================

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));

// ======================
// ROUTES
// ======================

app.use('/health', healthRoutes);
app.use('/api/ai', aiRoutes);
app.use('/metrics', metricsRoutes);

// ======================
// AI ORCHESTRATOR INITIALIZATION
// ======================

const orchestrator = new AIOrchestrator();

// ======================
// SERVER STARTUP
// ======================

const startServer = async () => {
  try {
    // Initialize Redis connection
    await redisClient.connect();
    logger.info('Connected to Redis');

    // Initialize AI Orchestrator
    await orchestrator.initialize();
    logger.info('AI Orchestrator initialized with 105 specialized AIs');

    // Start periodic AI tasks
    await orchestrator.startPeriodicTasks();
    logger.info('AI periodic tasks started');

    // Start server
    app.listen(PORT, () => {
      logger.info(`🤖 NEW ORTHO AI Orchestrator running on port ${PORT}`);
      logger.info(`📊 Metrics: http://localhost:${PORT}/metrics`);
      logger.info(`💚 Health: http://localhost:${PORT}/health`);
    });

  } catch (error) {
    logger.error('Failed to start AI Orchestrator:', error);
    process.exit(1);
  }
};

// ======================
// GRACEFUL SHUTDOWN
// ======================

process.on('SIGTERM', async () => {
  logger.info('SIGTERM received. Shutting down AI Orchestrator...');
  await orchestrator.shutdown();
  await redisClient.quit();
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received. Shutting down AI Orchestrator...');
  await orchestrator.shutdown();
  await redisClient.quit();
  process.exit(0);
});

startServer();