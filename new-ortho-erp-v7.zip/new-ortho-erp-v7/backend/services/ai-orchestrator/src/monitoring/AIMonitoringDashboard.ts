import { EventEmitter } from 'events';
import { logger } from '../utils/logger';
import { redisClient } from '../utils/redis';
import WebSocket from 'ws';

interface AIMonitoringMetrics {
  ai_id: string;
  ai_name: string;
  status: 'ACTIVE' | 'INACTIVE' | 'ERROR' | 'TRAINING' | 'MAINTENANCE';
  performance_metrics: PerformanceMetrics;
  resource_usage: ResourceUsage;
  prediction_metrics: PredictionMetrics;
  error_metrics: ErrorMetrics;
  training_metrics?: TrainingMetrics;
  last_updated: Date;
}

interface PerformanceMetrics {
  total_predictions: number;
  predictions_per_minute: number;
  average_response_time: number; // milliseconds
  p95_response_time: number;
  p99_response_time: number;
  throughput: number; // predictions per second
  availability: number; // percentage
  success_rate: number; // percentage
}

interface ResourceUsage {
  cpu_usage: number; // percentage
  memory_usage: number; // MB
  gpu_usage?: number; // percentage
  disk_usage: number; // MB
  network_io: number; // MB/s
  model_memory: number; // MB
  cache_usage: number; // percentage
}

interface PredictionMetrics {
  accuracy: number; // percentage
  precision: number;
  recall: number;
  f1_score: number;
  confidence_distribution: ConfidenceDistribution[];
  prediction_drift: number; // percentage change
  feature_importance: FeatureImportance[];
}

interface ConfidenceDistribution {
  confidence_range: string;
  count: number;
  percentage: number;
}

interface FeatureImportance {
  feature_name: string;
  importance_score: number;
  trend: 'INCREASING' | 'STABLE' | 'DECREASING';
}

interface ErrorMetrics {
  total_errors: number;
  error_rate: number; // percentage
  critical_errors: number;
  timeout_errors: number;
  validation_errors: number;
  model_errors: number;
  recent_errors: RecentError[];
}

interface RecentError {
  error_id: string;
  timestamp: Date;
  error_type: 'TIMEOUT' | 'VALIDATION' | 'MODEL' | 'SYSTEM' | 'NETWORK';
  error_message: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  resolution_status: 'PENDING' | 'IN_PROGRESS' | 'RESOLVED';
  impact_scope: string;
}

interface TrainingMetrics {
  training_status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED';
  current_epoch: number;
  total_epochs: number;
  training_loss: number;
  validation_loss: number;
  training_accuracy: number;
  validation_accuracy: number;
  learning_rate: number;
  batch_size: number;
  training_time: number; // minutes
  estimated_completion: Date;
  data_quality_score: number;
}

interface SystemOverview {
  total_ais: number;
  active_ais: number;
  total_predictions_today: number;
  average_system_accuracy: number;
  system_health_score: number; // 0-100
  alerts_count: number;
  critical_alerts_count: number;
  resource_utilization: SystemResourceUtilization;
  top_performing_ais: TopPerformingAI[];
  underperforming_ais: UnderperformingAI[];
}

interface SystemResourceUtilization {
  total_cpu_usage: number;
  total_memory_usage: number;
  total_gpu_usage: number;
  total_disk_usage: number;
  cluster_health: 'HEALTHY' | 'WARNING' | 'CRITICAL';
  node_count: number;
  active_nodes: number;
}

interface TopPerformingAI {
  ai_name: string;
  accuracy: number;
  predictions_count: number;
  uptime: number; // percentage
}

interface UnderperformingAI {
  ai_name: string;
  accuracy: number;
  error_rate: number;
  issue_description: string;
  recommended_action: string;
}

interface AlertRule {
  rule_id: string;
  rule_name: string;
  ai_target: string; // specific AI or 'ALL'
  metric_type: 'ACCURACY' | 'ERROR_RATE' | 'RESPONSE_TIME' | 'RESOURCE_USAGE' | 'AVAILABILITY';
  condition: 'LESS_THAN' | 'GREATER_THAN' | 'EQUALS' | 'NOT_EQUALS';
  threshold: number;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  notification_channels: NotificationChannel[];
  cooldown_minutes: number;
  is_active: boolean;
}

interface NotificationChannel {
  channel_type: 'EMAIL' | 'SLACK' | 'WEBHOOK' | 'SMS' | 'WHATSAPP';
  destination: string;
  template: string;
}

interface DashboardAlert {
  alert_id: string;
  rule_id: string;
  ai_name: string;
  alert_type: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  message: string;
  triggered_at: Date;
  status: 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED';
  acknowledged_by?: string;
  acknowledged_at?: Date;
  resolution_notes?: string;
  metric_value: number;
  threshold_value: number;
}

export class AIMonitoringDashboard extends EventEmitter {
  private aiMetrics: Map<string, AIMonitoringMetrics> = new Map();
  private alertRules: Map<string, AlertRule> = new Map();
  private activeAlerts: Map<string, DashboardAlert> = new Map();
  private wsServer: WebSocket.Server;
  private isRunning: boolean = false;
  private monitoringInterval?: NodeJS.Timeout;

  constructor(port: number = 8080) {
    super();
    
    this.wsServer = new WebSocket.Server({ port });
    this.setupWebSocketServer();
    this.setupDefaultAlertRules();
    
    logger.info(`AI Monitoring Dashboard initialized on port ${port}`);
  }

  async start(): Promise<void> {
    try {
      this.isRunning = true;
      
      // Start periodic monitoring
      this.monitoringInterval = setInterval(async () => {
        await this.collectMetrics();
        await this.evaluateAlerts();
        this.broadcastMetrics();
      }, 30000); // Every 30 seconds

      // Initialize system overview
      await this.initializeSystemOverview();
      
      logger.info('AI Monitoring Dashboard started successfully');
      
    } catch (error) {
      logger.error('Failed to start AI Monitoring Dashboard:', error);
      throw error;
    }
  }

  private setupWebSocketServer(): void {
    this.wsServer.on('connection', (ws: WebSocket) => {
      logger.info('New dashboard client connected');
      
      // Send current metrics immediately
      this.sendCurrentMetrics(ws);
      
      ws.on('message', async (message: string) => {
        try {
          const data = JSON.parse(message);
          await this.handleWebSocketMessage(ws, data);
        } catch (error) {
          logger.error('Error processing WebSocket message:', error);
        }
      });
      
      ws.on('close', () => {
        logger.info('Dashboard client disconnected');
      });
    });
  }

  private async handleWebSocketMessage(ws: WebSocket, data: any): Promise<void> {
    switch (data.type) {
      case 'GET_AI_DETAILS':
        await this.sendAIDetails(ws, data.ai_name);
        break;
        
      case 'ACKNOWLEDGE_ALERT':
        await this.acknowledgeAlert(data.alert_id, data.user_id);
        break;
        
      case 'RESOLVE_ALERT':
        await this.resolveAlert(data.alert_id, data.resolution_notes, data.user_id);
        break;
        
      case 'UPDATE_ALERT_RULE':
        await this.updateAlertRule(data.rule_id, data.rule_data);
        break;
        
      case 'TRIGGER_AI_ACTION':
        await this.triggerAIAction(data.ai_name, data.action);
        break;
        
      default:
        logger.warn(`Unknown WebSocket message type: ${data.type}`);
    }
  }

  async collectMetrics(): Promise<void> {
    try {
      // Collect metrics from all registered AIs
      const aiNames = await this.getRegisteredAIs();
      
      for (const aiName of aiNames) {
        const metrics = await this.collectAIMetrics(aiName);
        this.aiMetrics.set(aiName, metrics);
      }
      
      // Store metrics in Redis for persistence
      await this.storeMetricsInRedis();
      
    } catch (error) {
      logger.error('Error collecting AI metrics:', error);
    }
  }

  private async collectAIMetrics(aiName: string): Promise<AIMonitoringMetrics> {
    // Get metrics from Redis cache or direct AI monitoring
    const cacheKey = `ai-metrics:${aiName}`;
    const cachedMetrics = await redisClient.get(cacheKey);
    
    if (cachedMetrics) {
      return JSON.parse(cachedMetrics);
    }

    // Collect real-time metrics (this would interface with actual AI services)
    const metrics: AIMonitoringMetrics = {
      ai_id: `ai_${aiName.toLowerCase().replace(/\s+/g, '_')}`,
      ai_name: aiName,
      status: 'ACTIVE',
      performance_metrics: {
        total_predictions: Math.floor(Math.random() * 10000) + 1000,
        predictions_per_minute: Math.floor(Math.random() * 100) + 10,
        average_response_time: Math.random() * 200 + 50,
        p95_response_time: Math.random() * 400 + 100,
        p99_response_time: Math.random() * 800 + 200,
        throughput: Math.random() * 50 + 5,
        availability: 95 + Math.random() * 5,
        success_rate: 90 + Math.random() * 10
      },
      resource_usage: {
        cpu_usage: Math.random() * 80 + 10,
        memory_usage: Math.random() * 2000 + 500,
        gpu_usage: Math.random() * 90 + 5,
        disk_usage: Math.random() * 1000 + 100,
        network_io: Math.random() * 50 + 5,
        model_memory: Math.random() * 800 + 200,
        cache_usage: Math.random() * 80 + 10
      },
      prediction_metrics: {
        accuracy: 80 + Math.random() * 15,
        precision: 0.8 + Math.random() * 0.15,
        recall: 0.75 + Math.random() * 0.2,
        f1_score: 0.8 + Math.random() * 0.15,
        confidence_distribution: this.generateConfidenceDistribution(),
        prediction_drift: (Math.random() - 0.5) * 10,
        feature_importance: this.generateFeatureImportance()
      },
      error_metrics: {
        total_errors: Math.floor(Math.random() * 50),
        error_rate: Math.random() * 5,
        critical_errors: Math.floor(Math.random() * 3),
        timeout_errors: Math.floor(Math.random() * 10),
        validation_errors: Math.floor(Math.random() * 20),
        model_errors: Math.floor(Math.random() * 5),
        recent_errors: this.generateRecentErrors()
      },
      last_updated: new Date()
    };

    // Cache metrics for 1 minute
    await redisClient.setEx(cacheKey, 60, JSON.stringify(metrics));
    
    return metrics;
  }

  private async evaluateAlerts(): Promise<void> {
    try {
      for (const [aiName, metrics] of this.aiMetrics) {
        for (const [ruleId, rule] of this.alertRules) {
          if (!rule.is_active || (rule.ai_target !== 'ALL' && rule.ai_target !== aiName)) {
            continue;
          }

          const shouldTrigger = this.evaluateAlertRule(rule, metrics);
          
          if (shouldTrigger) {
            await this.triggerAlert(rule, metrics);
          }
        }
      }
    } catch (error) {
      logger.error('Error evaluating alerts:', error);
    }
  }

  private evaluateAlertRule(rule: AlertRule, metrics: AIMonitoringMetrics): boolean {
    let metricValue: number;

    switch (rule.metric_type) {
      case 'ACCURACY':
        metricValue = metrics.prediction_metrics.accuracy;
        break;
      case 'ERROR_RATE':
        metricValue = metrics.error_metrics.error_rate;
        break;
      case 'RESPONSE_TIME':
        metricValue = metrics.performance_metrics.average_response_time;
        break;
      case 'RESOURCE_USAGE':
        metricValue = metrics.resource_usage.cpu_usage;
        break;
      case 'AVAILABILITY':
        metricValue = metrics.performance_metrics.availability;
        break;
      default:
        return false;
    }

    switch (rule.condition) {
      case 'LESS_THAN':
        return metricValue < rule.threshold;
      case 'GREATER_THAN':
        return metricValue > rule.threshold;
      case 'EQUALS':
        return Math.abs(metricValue - rule.threshold) < 0.001;
      case 'NOT_EQUALS':
        return Math.abs(metricValue - rule.threshold) >= 0.001;
      default:
        return false;
    }
  }

  private async triggerAlert(rule: AlertRule, metrics: AIMonitoringMetrics): Promise<void> {
    const alertId = `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Check if similar alert is already active (cooldown)
    const existingAlert = Array.from(this.activeAlerts.values()).find(alert => 
      alert.rule_id === rule.rule_id && 
      alert.ai_name === metrics.ai_name &&
      alert.status === 'ACTIVE' &&
      (Date.now() - alert.triggered_at.getTime()) < (rule.cooldown_minutes * 60 * 1000)
    );

    if (existingAlert) {
      return; // Still in cooldown period
    }

    const alert: DashboardAlert = {
      alert_id: alertId,
      rule_id: rule.rule_id,
      ai_name: metrics.ai_name,
      alert_type: rule.metric_type,
      severity: rule.severity,
      message: this.generateAlertMessage(rule, metrics),
      triggered_at: new Date(),
      status: 'ACTIVE',
      metric_value: this.getMetricValue(rule.metric_type, metrics),
      threshold_value: rule.threshold
    };

    this.activeAlerts.set(alertId, alert);
    
    // Send notifications
    await this.sendAlertNotifications(rule, alert);
    
    // Emit alert event
    this.emit('alert-triggered', alert);
    
    logger.warn(`Alert triggered: ${alert.message}`);
  }

  private generateAlertMessage(rule: AlertRule, metrics: AIMonitoringMetrics): string {
    const metricValue = this.getMetricValue(rule.metric_type, metrics);
    
    return `AI "${metrics.ai_name}" ${rule.metric_type.toLowerCase().replace('_', ' ')} ` +
           `${rule.condition.toLowerCase().replace('_', ' ')} ${rule.threshold}. ` +
           `Current value: ${metricValue.toFixed(2)}`;
  }

  private getMetricValue(metricType: string, metrics: AIMonitoringMetrics): number {
    switch (metricType) {
      case 'ACCURACY': return metrics.prediction_metrics.accuracy;
      case 'ERROR_RATE': return metrics.error_metrics.error_rate;
      case 'RESPONSE_TIME': return metrics.performance_metrics.average_response_time;
      case 'RESOURCE_USAGE': return metrics.resource_usage.cpu_usage;
      case 'AVAILABILITY': return metrics.performance_metrics.availability;
      default: return 0;
    }
  }

  private async sendAlertNotifications(rule: AlertRule, alert: DashboardAlert): Promise<void> {
    for (const channel of rule.notification_channels) {
      try {
        switch (channel.channel_type) {
          case 'EMAIL':
            await this.sendEmailNotification(channel.destination, alert, channel.template);
            break;
          case 'SLACK':
            await this.sendSlackNotification(channel.destination, alert, channel.template);
            break;
          case 'WEBHOOK':
            await this.sendWebhookNotification(channel.destination, alert);
            break;
          case 'WHATSAPP':
            await this.sendWhatsAppNotification(channel.destination, alert);
            break;
        }
      } catch (error) {
        logger.error(`Failed to send notification via ${channel.channel_type}:`, error);
      }
    }
  }

  private broadcastMetrics(): void {
    const systemOverview = this.generateSystemOverview();
    const message = {
      type: 'METRICS_UPDATE',
      data: {
        system_overview: systemOverview,
        ai_metrics: Array.from(this.aiMetrics.values()),
        active_alerts: Array.from(this.activeAlerts.values()),
        timestamp: new Date()
      }
    };

    this.wsServer.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }

  private generateSystemOverview(): SystemOverview {
    const aiMetricsArray = Array.from(this.aiMetrics.values());
    const activeAIs = aiMetricsArray.filter(ai => ai.status === 'ACTIVE');
    
    return {
      total_ais: aiMetricsArray.length,
      active_ais: activeAIs.length,
      total_predictions_today: aiMetricsArray.reduce((sum, ai) => sum + ai.performance_metrics.total_predictions, 0),
      average_system_accuracy: aiMetricsArray.reduce((sum, ai) => sum + ai.prediction_metrics.accuracy, 0) / aiMetricsArray.length,
      system_health_score: this.calculateSystemHealthScore(aiMetricsArray),
      alerts_count: this.activeAlerts.size,
      critical_alerts_count: Array.from(this.activeAlerts.values()).filter(alert => alert.severity === 'CRITICAL').length,
      resource_utilization: {
        total_cpu_usage: aiMetricsArray.reduce((sum, ai) => sum + ai.resource_usage.cpu_usage, 0) / aiMetricsArray.length,
        total_memory_usage: aiMetricsArray.reduce((sum, ai) => sum + ai.resource_usage.memory_usage, 0),
        total_gpu_usage: aiMetricsArray.reduce((sum, ai) => sum + (ai.resource_usage.gpu_usage || 0), 0) / aiMetricsArray.length,
        total_disk_usage: aiMetricsArray.reduce((sum, ai) => sum + ai.resource_usage.disk_usage, 0),
        cluster_health: 'HEALTHY',
        node_count: 5,
        active_nodes: 5
      },
      top_performing_ais: this.getTopPerformingAIs(aiMetricsArray),
      underperforming_ais: this.getUnderperformingAIs(aiMetricsArray)
    };
  }

  // API methods for dashboard interactions
  async getSystemOverview(): Promise<SystemOverview> {
    return this.generateSystemOverview();
  }

  async getAIMetrics(aiName?: string): Promise<AIMonitoringMetrics[]> {
    if (aiName) {
      const metrics = this.aiMetrics.get(aiName);
      return metrics ? [metrics] : [];
    }
    return Array.from(this.aiMetrics.values());
  }

  async getActiveAlerts(): Promise<DashboardAlert[]> {
    return Array.from(this.activeAlerts.values()).filter(alert => alert.status === 'ACTIVE');
  }

  async acknowledgeAlert(alertId: string, userId: string): Promise<void> {
    const alert = this.activeAlerts.get(alertId);
    if (alert) {
      alert.status = 'ACKNOWLEDGED';
      alert.acknowledged_by = userId;
      alert.acknowledged_at = new Date();
      
      this.emit('alert-acknowledged', alert);
      logger.info(`Alert ${alertId} acknowledged by ${userId}`);
    }
  }

  async resolveAlert(alertId: string, resolutionNotes: string, userId: string): Promise<void> {
    const alert = this.activeAlerts.get(alertId);
    if (alert) {
      alert.status = 'RESOLVED';
      alert.resolution_notes = resolutionNotes;
      
      // Move to resolved alerts (could be stored separately)
      this.activeAlerts.delete(alertId);
      
      this.emit('alert-resolved', alert);
      logger.info(`Alert ${alertId} resolved by ${userId}: ${resolutionNotes}`);
    }
  }

  async createAlertRule(rule: Omit<AlertRule, 'rule_id'>): Promise<string> {
    const ruleId = `rule_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const alertRule: AlertRule = {
      rule_id: ruleId,
      ...rule
    };
    
    this.alertRules.set(ruleId, alertRule);
    
    // Store in Redis
    await redisClient.setEx(
      `alert-rule:${ruleId}`,
      86400 * 7, // 7 days
      JSON.stringify(alertRule)
    );
    
    logger.info(`Alert rule created: ${ruleId}`);
    return ruleId;
  }

  // Helper methods
  private setupDefaultAlertRules(): void {
    const defaultRules: Omit<AlertRule, 'rule_id'>[] = [
      {
        rule_name: 'Low Accuracy Alert',
        ai_target: 'ALL',
        metric_type: 'ACCURACY',
        condition: 'LESS_THAN',
        threshold: 80,
        severity: 'HIGH',
        notification_channels: [
          { channel_type: 'EMAIL', destination: 'alerts@newortho.com', template: 'accuracy_alert' }
        ],
        cooldown_minutes: 30,
        is_active: true
      },
      {
        rule_name: 'High Error Rate Alert',
        ai_target: 'ALL',
        metric_type: 'ERROR_RATE',
        condition: 'GREATER_THAN',
        threshold: 5,
        severity: 'CRITICAL',
        notification_channels: [
          { channel_type: 'EMAIL', destination: 'alerts@newortho.com', template: 'error_alert' },
          { channel_type: 'SLACK', destination: '#ai-alerts', template: 'slack_alert' }
        ],
        cooldown_minutes: 15,
        is_active: true
      },
      {
        rule_name: 'High Response Time Alert',
        ai_target: 'ALL',
        metric_type: 'RESPONSE_TIME',
        condition: 'GREATER_THAN',
        threshold: 1000,
        severity: 'MEDIUM',
        notification_channels: [
          { channel_type: 'SLACK', destination: '#ai-performance', template: 'performance_alert' }
        ],
        cooldown_minutes: 60,
        is_active: true
      }
    ];

    defaultRules.forEach(async (rule) => {
      await this.createAlertRule(rule);
    });
  }

  private async getRegisteredAIs(): Promise<string[]> {
    // This would typically query a service registry or database
    return [
      'Financial Forecasting AI',
      'Container Validity AI',
      'Surgery Scheduling AI',
      'Inventory Optimization AI',
      'Pricing Negotiation AI',
      'Lead Scoring AI',
      'Churn Prediction AI',
      'Risk Analysis AI'
    ];
  }

  private generateConfidenceDistribution(): ConfidenceDistribution[] {
    return [
      { confidence_range: '0.9-1.0', count: 150, percentage: 30 },
      { confidence_range: '0.8-0.9', count: 200, percentage: 40 },
      { confidence_range: '0.7-0.8', count: 100, percentage: 20 },
      { confidence_range: '0.6-0.7', count: 50, percentage: 10 }
    ];
  }

  private generateFeatureImportance(): FeatureImportance[] {
    return [
      { feature_name: 'Historical Data', importance_score: 0.35, trend: 'STABLE' },
      { feature_name: 'Market Conditions', importance_score: 0.25, trend: 'INCREASING' },
      { feature_name: 'Customer Profile', importance_score: 0.20, trend: 'STABLE' },
      { feature_name: 'Seasonal Factors', importance_score: 0.15, trend: 'DECREASING' },
      { feature_name: 'External Events', importance_score: 0.05, trend: 'STABLE' }
    ];
  }

  private generateRecentErrors(): RecentError[] {
    return [
      {
        error_id: 'err_001',
        timestamp: new Date(Date.now() - 3600000), // 1 hour ago
        error_type: 'TIMEOUT',
        error_message: 'Request timeout after 30 seconds',
        severity: 'MEDIUM',
        resolution_status: 'RESOLVED',
        impact_scope: 'Single prediction'
      }
    ];
  }

  private calculateSystemHealthScore(aiMetrics: AIMonitoringMetrics[]): number {
    if (aiMetrics.length === 0) return 0;
    
    const avgAccuracy = aiMetrics.reduce((sum, ai) => sum + ai.prediction_metrics.accuracy, 0) / aiMetrics.length;
    const avgAvailability = aiMetrics.reduce((sum, ai) => sum + ai.performance_metrics.availability, 0) / aiMetrics.length;
    const avgSuccessRate = aiMetrics.reduce((sum, ai) => sum + ai.performance_metrics.success_rate, 0) / aiMetrics.length;
    
    return (avgAccuracy * 0.4 + avgAvailability * 0.3 + avgSuccessRate * 0.3);
  }

  private getTopPerformingAIs(aiMetrics: AIMonitoringMetrics[]): TopPerformingAI[] {
    return aiMetrics
      .sort((a, b) => b.prediction_metrics.accuracy - a.prediction_metrics.accuracy)
      .slice(0, 5)
      .map(ai => ({
        ai_name: ai.ai_name,
        accuracy: ai.prediction_metrics.accuracy,
        predictions_count: ai.performance_metrics.total_predictions,
        uptime: ai.performance_metrics.availability
      }));
  }

  private getUnderperformingAIs(aiMetrics: AIMonitoringMetrics[]): UnderperformingAI[] {
    return aiMetrics
      .filter(ai => ai.prediction_metrics.accuracy < 85 || ai.error_metrics.error_rate > 3)
      .map(ai => ({
        ai_name: ai.ai_name,
        accuracy: ai.prediction_metrics.accuracy,
        error_rate: ai.error_metrics.error_rate,
        issue_description: ai.prediction_metrics.accuracy < 85 ? 'Low accuracy' : 'High error rate',
        recommended_action: 'Review and retrain model'
      }));
  }

  // Notification methods (simplified implementations)
  private async sendEmailNotification(email: string, alert: DashboardAlert, template: string): Promise<void> {
    logger.info(`Sending email alert to ${email}: ${alert.message}`);
  }

  private async sendSlackNotification(channel: string, alert: DashboardAlert, template: string): Promise<void> {
    logger.info(`Sending Slack alert to ${channel}: ${alert.message}`);
  }

  private async sendWebhookNotification(url: string, alert: DashboardAlert): Promise<void> {
    logger.info(`Sending webhook alert to ${url}: ${alert.message}`);
  }

  private async sendWhatsAppNotification(phone: string, alert: DashboardAlert): Promise<void> {
    logger.info(`Sending WhatsApp alert to ${phone}: ${alert.message}`);
  }

  private async sendCurrentMetrics(ws: WebSocket): Promise<void> {
    const systemOverview = this.generateSystemOverview();
    const message = {
      type: 'INITIAL_METRICS',
      data: {
        system_overview: systemOverview,
        ai_metrics: Array.from(this.aiMetrics.values()),
        active_alerts: Array.from(this.activeAlerts.values())
      }
    };
    
    ws.send(JSON.stringify(message));
  }

  private async sendAIDetails(ws: WebSocket, aiName: string): Promise<void> {
    const metrics = this.aiMetrics.get(aiName);
    if (metrics) {
      const message = {
        type: 'AI_DETAILS',
        data: {
          ai_name: aiName,
          metrics: metrics,
          historical_data: await this.getHistoricalMetrics(aiName)
        }
      };
      
      ws.send(JSON.stringify(message));
    }
  }

  private async getHistoricalMetrics(aiName: string): Promise<any[]> {
    // Retrieve historical metrics from Redis or database
    return [];
  }

  private async storeMetricsInRedis(): Promise<void> {
    for (const [aiName, metrics] of this.aiMetrics) {
      await redisClient.setEx(
        `historical-metrics:${aiName}:${Date.now()}`,
        86400 * 7, // 7 days
        JSON.stringify(metrics)
      );
    }
  }

  private async initializeSystemOverview(): Promise<void> {
    // Initialize with stored metrics if available
    try {
      const storedMetrics = await redisClient.keys('ai-metrics:*');
      for (const key of storedMetrics) {
        const metrics = await redisClient.get(key);
        if (metrics) {
          const parsedMetrics: AIMonitoringMetrics = JSON.parse(metrics);
          this.aiMetrics.set(parsedMetrics.ai_name, parsedMetrics);
        }
      }
    } catch (error) {
      logger.error('Error initializing system overview:', error);
    }
  }

  private async updateAlertRule(ruleId: string, ruleData: Partial<AlertRule>): Promise<void> {
    const existingRule = this.alertRules.get(ruleId);
    if (existingRule) {
      const updatedRule = { ...existingRule, ...ruleData };
      this.alertRules.set(ruleId, updatedRule);
      
      await redisClient.setEx(
        `alert-rule:${ruleId}`,
        86400 * 7,
        JSON.stringify(updatedRule)
      );
      
      logger.info(`Alert rule ${ruleId} updated`);
    }
  }

  private async triggerAIAction(aiName: string, action: string): Promise<void> {
    logger.info(`Triggering action "${action}" on AI "${aiName}"`);
    
    // This would interface with the actual AI services to perform actions like:
    // - Restart AI
    // - Retrain model
    // - Scale resources
    // - Update configuration
    
    this.emit('ai-action-triggered', { aiName, action });
  }

  async shutdown(): Promise<void> {
    this.isRunning = false;
    
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }
    
    this.wsServer.close();
    
    logger.info('AI Monitoring Dashboard shut down');
  }
}