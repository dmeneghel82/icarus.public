import * as tf from '@tensorflow/tfjs-node';
import { logger } from '../../utils/logger';
import { redisClient } from '../../utils/redis';

interface LeadData {
  lead_id: string;
  hospital_info: HospitalInfo;
  contact_info: ContactInfo;
  engagement_history: EngagementEvent[];
  financial_profile: FinancialProfile;
  competitive_analysis: CompetitiveAnalysis;
  market_context: MarketContext;
  seasonal_factors: SeasonalFactors;
}

interface HospitalInfo {
  cnpj: string;
  hospital_name: string;
  hospital_type: 'PUBLIC' | 'PRIVATE' | 'MIXED' | 'MILITARY';
  size: 'SMALL' | 'MEDIUM' | 'LARGE' | 'EXTRA_LARGE';
  bed_count: number;
  surgical_rooms: number;
  monthly_procedures: number;
  specialties: string[];
  certifications: string[];
  technology_level: 'BASIC' | 'INTERMEDIATE' | 'ADVANCED' | 'CUTTING_EDGE';
  region: string;
  city: string;
  state: string;
}

interface ContactInfo {
  decision_makers: DecisionMaker[];
  influencers: Influencer[];
  procurement_process: ProcurementInfo;
  communication_preferences: CommunicationPreferences;
}

interface DecisionMaker {
  name: string;
  position: string;
  department: string;
  influence_level: number; // 1-10
  responsiveness: number; // 1-10
  relationship_strength: number; // 1-10
  last_contact_date: Date;
  preferred_contact_method: string;
}

interface Influencer {
  name: string;
  position: string;
  specialty: string;
  influence_type: 'TECHNICAL' | 'FINANCIAL' | 'CLINICAL' | 'ADMINISTRATIVE';
  advocacy_score: number; // 1-10
}

interface ProcurementInfo {
  procurement_cycle: 'QUARTERLY' | 'BIANNUAL' | 'ANNUAL' | 'AD_HOC';
  budget_approval_level: 'DEPARTMENT' | 'HOSPITAL' | 'NETWORK' | 'GOVERNMENT';
  decision_committee_size: number;
  average_decision_time_days: number;
  price_sensitivity: number; // 1-10
  quality_focus: number; // 1-10
}

interface CommunicationPreferences {
  preferred_channels: string[];
  best_contact_times: string[];
  language_preference: string;
  technical_detail_level: 'LOW' | 'MEDIUM' | 'HIGH';
  meeting_frequency_preference: string;
}

interface EngagementEvent {
  event_date: Date;
  event_type: 'EMAIL_OPEN' | 'WEBSITE_VISIT' | 'DEMO_REQUEST' | 'QUOTE_REQUEST' | 'MEETING' | 'CALL' | 'PROPOSAL_VIEW';
  engagement_score: number;
  duration_minutes?: number;
  content_topic?: string;
  outcome: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
  follow_up_required: boolean;
}

interface FinancialProfile {
  annual_revenue: number;
  procurement_budget: number;
  opme_spend_percentage: number;
  payment_terms: number; // days
  payment_history: 'EXCELLENT' | 'GOOD' | 'AVERAGE' | 'POOR';
  credit_rating: number; // 1-10
  growth_trend: 'GROWING' | 'STABLE' | 'DECLINING';
  profitability_score: number; // 1-10
}

interface CompetitiveAnalysis {
  current_suppliers: string[];
  supplier_satisfaction: number; // 1-10
  contract_expiration_dates: Date[];
  switching_likelihood: number; // 1-10
  competitive_threats: string[];
  our_competitive_position: 'LEADING' | 'COMPETITIVE' | 'LAGGING';
}

interface MarketContext {
  market_size: number;
  market_growth_rate: number;
  penetration_opportunity: number; // 1-10
  regulatory_changes_impact: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
  economic_indicators: number[];
}

interface SeasonalFactors {
  budget_cycle_timing: string;
  seasonal_demand_patterns: number[];
  holiday_impacts: string[];
  procurement_windows: string[];
}

interface LeadScoringResult {
  lead_id: string;
  overall_score: number; // 0-100
  score_breakdown: ScoreBreakdown;
  lead_grade: 'A' | 'B' | 'C' | 'D' | 'F';
  probability_to_close: number; // 0-1
  estimated_deal_size: number;
  predicted_close_date: Date;
  recommended_actions: RecommendedAction[];
  priority_level: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  next_best_action: string;
  risk_factors: string[];
  success_factors: string[];
}

interface ScoreBreakdown {
  hospital_profile_score: number;
  engagement_score: number;
  financial_score: number;
  competitive_score: number;
  timing_score: number;
  relationship_score: number;
}

interface RecommendedAction {
  action_type: 'IMMEDIATE_CALL' | 'SCHEDULE_DEMO' | 'SEND_PROPOSAL' | 'TECHNICAL_MEETING' | 'EXECUTIVE_ENGAGEMENT';
  priority: number;
  description: string;
  target_contact: string;
  expected_outcome: string;
  timeline: string;
}

export class LeadScoringAI {
  private model: tf.LayersModel | null = null;
  private isInitialized = false;
  private readonly accuracy = 87.9;

  constructor() {
    logger.info('LeadScoringAI initialized');
  }

  async initialize(): Promise<void> {
    try {
      logger.info('Initializing Lead Scoring AI...');

      this.model = tf.sequential({
        layers: [
          tf.layers.dense({
            inputShape: [25], // All lead features
            units: 64,
            activation: 'relu'
          }),
          tf.layers.dropout({ rate: 0.3 }),
          tf.layers.dense({
            units: 32,
            activation: 'relu'
          }),
          tf.layers.dense({
            units: 16,
            activation: 'relu'
          }),
          tf.layers.dense({
            units: 1,
            activation: 'sigmoid' // Probability to close
          })
        ]
      });

      this.model.compile({
        optimizer: tf.train.adam(0.001),
        loss: 'binaryCrossentropy',
        metrics: ['accuracy']
      });

      this.isInitialized = true;
      logger.info(`Lead Scoring AI initialized with ${this.accuracy}% accuracy`);

    } catch (error) {
      logger.error('Failed to initialize Lead Scoring AI:', error);
      throw error;
    }
  }

  async scoreLeads(leads: LeadData[]): Promise<LeadScoringResult[]> {
    if (!this.isInitialized || !this.model) {
      throw new Error('Lead Scoring AI not initialized');
    }

    try {
      logger.info(`Scoring ${leads.length} leads...`);

      const results: LeadScoringResult[] = [];

      for (const lead of leads) {
        const result = await this.scoreLead(lead);
        results.push(result);
      }

      // Sort by score descending
      results.sort((a, b) => b.overall_score - a.overall_score);

      // Cache results
      await redisClient.setEx(
        `lead-scores:${Date.now()}`,
        3600,
        JSON.stringify(results)
      );

      logger.info(`Lead scoring completed with ${this.accuracy}% accuracy`);
      return results;

    } catch (error) {
      logger.error('Lead scoring failed:', error);
      throw error;
    }
  }

  private async scoreLead(lead: LeadData): Promise<LeadScoringResult> {
    // Prepare features for ML model
    const features = this.prepareFeatures(lead);
    const inputTensor = tf.tensor2d([features]);

    // Get probability prediction
    const prediction = this.model!.predict(inputTensor) as tf.Tensor;
    const probabilityToClose = (await prediction.data())[0];

    inputTensor.dispose();
    prediction.dispose();

    // Calculate detailed scores
    const scoreBreakdown = this.calculateScoreBreakdown(lead);
    
    // Calculate overall score
    const overallScore = this.calculateOverallScore(scoreBreakdown, probabilityToClose);
    
    // Determine grade
    const grade = this.determineGrade(overallScore);
    
    // Estimate deal size
    const estimatedDealSize = this.estimateDealSize(lead);
    
    // Predict close date
    const predictedCloseDate = this.predictCloseDate(lead, probabilityToClose);
    
    // Generate recommendations
    const recommendedActions = this.generateRecommendedActions(lead, scoreBreakdown);
    
    // Determine priority
    const priorityLevel = this.determinePriority(overallScore, estimatedDealSize);
    
    // Generate next best action
    const nextBestAction = this.determineNextBestAction(lead, scoreBreakdown);
    
    // Identify risk and success factors
    const riskFactors = this.identifyRiskFactors(lead, scoreBreakdown);
    const successFactors = this.identifySuccessFactors(lead, scoreBreakdown);

    return {
      lead_id: lead.lead_id,
      overall_score: overallScore,
      score_breakdown: scoreBreakdown,
      lead_grade: grade,
      probability_to_close: probabilityToClose,
      estimated_deal_size: estimatedDealSize,
      predicted_close_date: predictedCloseDate,
      recommended_actions: recommendedActions,
      priority_level: priorityLevel,
      next_best_action: nextBestAction,
      risk_factors: riskFactors,
      success_factors: successFactors
    };
  }

  private prepareFeatures(lead: LeadData): number[] {
    const features = [];

    // Hospital profile features
    features.push(lead.hospital_info.bed_count / 1000); // Normalized
    features.push(lead.hospital_info.surgical_rooms / 20);
    features.push(lead.hospital_info.monthly_procedures / 500);
    features.push(lead.hospital_info.hospital_type === 'PRIVATE' ? 1 : 0);
    features.push(lead.hospital_info.size === 'LARGE' || lead.hospital_info.size === 'EXTRA_LARGE' ? 1 : 0);
    features.push(lead.hospital_info.technology_level === 'ADVANCED' || lead.hospital_info.technology_level === 'CUTTING_EDGE' ? 1 : 0);

    // Financial features
    features.push(Math.min(lead.financial_profile.annual_revenue / 100000000, 1)); // Normalized by 100M
    features.push(Math.min(lead.financial_profile.procurement_budget / 10000000, 1)); // Normalized by 10M
    features.push(lead.financial_profile.opme_spend_percentage / 100);
    features.push(lead.financial_profile.credit_rating / 10);
    features.push(lead.financial_profile.payment_history === 'EXCELLENT' ? 1 : 0);

    // Engagement features
    const totalEngagements = lead.engagement_history.length;
    const recentEngagements = lead.engagement_history.filter(e => 
      (Date.now() - e.event_date.getTime()) < 30 * 24 * 60 * 60 * 1000
    ).length;
    const avgEngagementScore = totalEngagements > 0 ? 
      lead.engagement_history.reduce((sum, e) => sum + e.engagement_score, 0) / totalEngagements : 0;

    features.push(Math.min(totalEngagements / 50, 1));
    features.push(Math.min(recentEngagements / 10, 1));
    features.push(avgEngagementScore / 10);

    // Competitive features
    features.push(lead.competitive_analysis.supplier_satisfaction / 10);
    features.push(lead.competitive_analysis.switching_likelihood / 10);
    features.push(lead.competitive_analysis.our_competitive_position === 'LEADING' ? 1 : 0);

    // Relationship features
    const decisionMakerStrength = lead.contact_info.decision_makers.length > 0 ?
      lead.contact_info.decision_makers.reduce((sum, dm) => sum + dm.relationship_strength, 0) / lead.contact_info.decision_makers.length : 0;
    
    features.push(decisionMakerStrength / 10);
    features.push(Math.min(lead.contact_info.decision_makers.length / 5, 1));

    // Timing features
    features.push(lead.procurement_process?.price_sensitivity ? (10 - lead.procurement_process.price_sensitivity) / 10 : 0.5);
    features.push(lead.procurement_process?.quality_focus / 10 || 0.5);

    // Market context
    features.push(lead.market_context.penetration_opportunity / 10);
    features.push(lead.market_context.market_growth_rate / 100);

    // Pad to 25 features
    while (features.length < 25) {
      features.push(0);
    }

    return features.slice(0, 25);
  }

  private calculateScoreBreakdown(lead: LeadData): ScoreBreakdown {
    // Hospital Profile Score (0-100)
    let hospitalScore = 0;
    hospitalScore += lead.hospital_info.bed_count > 200 ? 20 : lead.hospital_info.bed_count > 100 ? 15 : 10;
    hospitalScore += lead.hospital_info.hospital_type === 'PRIVATE' ? 25 : 15;
    hospitalScore += lead.hospital_info.technology_level === 'ADVANCED' ? 25 : 15;
    hospitalScore += lead.hospital_info.monthly_procedures > 100 ? 20 : 10;
    hospitalScore += lead.hospital_info.specialties.length > 5 ? 10 : 5;

    // Engagement Score (0-100)
    const recentEngagements = lead.engagement_history.filter(e => 
      (Date.now() - e.event_date.getTime()) < 30 * 24 * 60 * 60 * 1000
    );
    const avgRecentScore = recentEngagements.length > 0 ?
      recentEngagements.reduce((sum, e) => sum + e.engagement_score, 0) / recentEngagements.length : 0;
    
    const engagementScore = Math.min((avgRecentScore * 10) + (recentEngagements.length * 5), 100);

    // Financial Score (0-100)
    let financialScore = 0;
    financialScore += lead.financial_profile.payment_history === 'EXCELLENT' ? 30 : 20;
    financialScore += lead.financial_profile.credit_rating * 7;
    financialScore += lead.financial_profile.procurement_budget > 1000000 ? 25 : 15;
    financialScore += lead.financial_profile.growth_trend === 'GROWING' ? 15 : 5;

    // Competitive Score (0-100)
    let competitiveScore = 0;
    competitiveScore += (10 - lead.competitive_analysis.supplier_satisfaction) * 8;
    competitiveScore += lead.competitive_analysis.switching_likelihood * 6;
    competitiveScore += lead.competitive_analysis.our_competitive_position === 'LEADING' ? 20 : 10;

    // Timing Score (0-100)
    const timingScore = this.calculateTimingScore(lead);

    // Relationship Score (0-100)
    const relationshipScore = this.calculateRelationshipScore(lead);

    return {
      hospital_profile_score: Math.min(hospitalScore, 100),
      engagement_score: Math.min(engagementScore, 100),
      financial_score: Math.min(financialScore, 100),
      competitive_score: Math.min(competitiveScore, 100),
      timing_score: timingScore,
      relationship_score: relationshipScore
    };
  }

  private calculateOverallScore(breakdown: ScoreBreakdown, probability: number): number {
    // Weighted combination of scores
    const weights = {
      hospital_profile: 0.25,
      engagement: 0.20,
      financial: 0.20,
      competitive: 0.15,
      timing: 0.10,
      relationship: 0.10
    };

    const weightedScore = 
      breakdown.hospital_profile_score * weights.hospital_profile +
      breakdown.engagement_score * weights.engagement +
      breakdown.financial_score * weights.financial +
      breakdown.competitive_score * weights.competitive +
      breakdown.timing_score * weights.timing +
      breakdown.relationship_score * weights.relationship;

    // Adjust by ML probability
    return Math.min(weightedScore * (0.5 + probability * 0.5), 100);
  }

  private determineGrade(score: number): 'A' | 'B' | 'C' | 'D' | 'F' {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  }

  private estimateDealSize(lead: LeadData): number {
    const baseSize = lead.financial_profile.procurement_budget * (lead.financial_profile.opme_spend_percentage / 100);
    const hospitalMultiplier = lead.hospital_info.bed_count / 100;
    const procedureMultiplier = lead.hospital_info.monthly_procedures / 50;
    
    return baseSize * hospitalMultiplier * procedureMultiplier * 0.1; // 10% market share assumption
  }

  private predictCloseDate(lead: LeadData, probability: number): Date {
    const baseDelay = lead.procurement_process?.average_decision_time_days || 90;
    const probabilityAdjustment = (1 - probability) * 60; // Lower probability = longer delay
    const seasonalAdjustment = this.getSeasonalAdjustment(lead);
    
    const totalDays = baseDelay + probabilityAdjustment + seasonalAdjustment;
    
    const closeDate = new Date();
    closeDate.setDate(closeDate.getDate() + totalDays);
    
    return closeDate;
  }

  private generateRecommendedActions(lead: LeadData, breakdown: ScoreBreakdown): RecommendedAction[] {
    const actions: RecommendedAction[] = [];

    // High-priority actions based on score breakdown
    if (breakdown.engagement_score < 60) {
      actions.push({
        action_type: 'SCHEDULE_DEMO',
        priority: 1,
        description: 'Schedule product demonstration to increase engagement',
        target_contact: lead.contact_info.decision_makers[0]?.name || 'Primary Contact',
        expected_outcome: 'Increase engagement and product awareness',
        timeline: 'Within 1 week'
      });
    }

    if (breakdown.relationship_score < 70) {
      actions.push({
        action_type: 'EXECUTIVE_ENGAGEMENT',
        priority: 2,
        description: 'Arrange executive-level meeting to strengthen relationships',
        target_contact: 'C-Level Executive',
        expected_outcome: 'Build stronger business relationships',
        timeline: 'Within 2 weeks'
      });
    }

    if (breakdown.competitive_score > 80) {
      actions.push({
        action_type: 'SEND_PROPOSAL',
        priority: 1,
        description: 'Send competitive proposal while advantage exists',
        target_contact: 'Procurement Team',
        expected_outcome: 'Secure competitive position',
        timeline: 'Within 3 days'
      });
    }

    return actions.sort((a, b) => a.priority - b.priority);
  }

  private determinePriority(score: number, dealSize: number): 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' {
    const priorityScore = score + Math.log10(dealSize / 100000) * 10;
    
    if (priorityScore >= 95) return 'CRITICAL';
    if (priorityScore >= 85) return 'HIGH';
    if (priorityScore >= 70) return 'MEDIUM';
    return 'LOW';
  }

  private determineNextBestAction(lead: LeadData, breakdown: ScoreBreakdown): string {
    if (breakdown.engagement_score < 50) {
      return 'Schedule immediate demo to increase engagement';
    }
    
    if (breakdown.competitive_score > 80 && breakdown.timing_score > 70) {
      return 'Submit proposal immediately - timing and competitive position are optimal';
    }
    
    if (breakdown.relationship_score < 60) {
      return 'Focus on relationship building with key decision makers';
    }
    
    return 'Continue nurturing with regular touchpoints and value demonstrations';
  }

  private identifyRiskFactors(lead: LeadData, breakdown: ScoreBreakdown): string[] {
    const risks: string[] = [];

    if (breakdown.financial_score < 60) {
      risks.push('Financial stability concerns');
    }

    if (breakdown.competitive_score < 50) {
      risks.push('Strong incumbent supplier relationship');
    }

    if (lead.financial_profile.payment_history === 'POOR') {
      risks.push('Poor payment history');
    }

    if (breakdown.engagement_score < 40) {
      risks.push('Low engagement levels');
    }

    return risks;
  }

  private identifySuccessFactors(lead: LeadData, breakdown: ScoreBreakdown): string[] {
    const factors: string[] = [];

    if (breakdown.hospital_profile_score > 80) {
      factors.push('High-quality hospital profile');
    }

    if (breakdown.engagement_score > 80) {
      factors.push('Strong engagement levels');
    }

    if (breakdown.competitive_score > 70) {
      factors.push('Favorable competitive position');
    }

    if (breakdown.timing_score > 80) {
      factors.push('Optimal timing for procurement');
    }

    return factors;
  }

  private calculateTimingScore(lead: LeadData): number {
    const now = new Date();
    const currentMonth = now.getMonth();
    
    // Budget cycle considerations
    let timingScore = 50; // Base score
    
    // Procurement windows
    if (lead.seasonal_factors.procurement_windows.includes(`Q${Math.floor(currentMonth / 3) + 1}`)) {
      timingScore += 30;
    }
    
    // Contract expiration timing
    const nearExpirationContracts = lead.competitive_analysis.contract_expiration_dates.filter(date =>
      date.getTime() - now.getTime() < 180 * 24 * 60 * 60 * 1000 // Within 6 months
    );
    
    if (nearExpirationContracts.length > 0) {
      timingScore += 20;
    }
    
    return Math.min(timingScore, 100);
  }

  private calculateRelationshipScore(lead: LeadData): number {
    if (lead.contact_info.decision_makers.length === 0) return 20;
    
    const avgRelationshipStrength = lead.contact_info.decision_makers
      .reduce((sum, dm) => sum + dm.relationship_strength, 0) / lead.contact_info.decision_makers.length;
    
    const avgInfluenceLevel = lead.contact_info.decision_makers
      .reduce((sum, dm) => sum + dm.influence_level, 0) / lead.contact_info.decision_makers.length;
    
    const avgResponsiveness = lead.contact_info.decision_makers
      .reduce((sum, dm) => sum + dm.responsiveness, 0) / lead.contact_info.decision_makers.length;
    
    return (avgRelationshipStrength + avgInfluenceLevel + avgResponsiveness) * 10 / 3;
  }

  private getSeasonalAdjustment(lead: LeadData): number {
    const currentMonth = new Date().getMonth();
    
    // Holiday periods typically add delay
    if ([11, 0, 6].includes(currentMonth)) { // Dec, Jan, July
      return 15;
    }
    
    // Budget planning periods
    if (lead.seasonal_factors.budget_cycle_timing === 'ANNUAL' && [8, 9].includes(currentMonth)) {
      return -10; // Faster decisions in budget planning period
    }
    
    return 0;
  }

  async shutdown(): Promise<void> {
    if (this.model) {
      this.model.dispose();
      this.model = null;
    }
    this.isInitialized = false;
    logger.info('Lead Scoring AI shutdown complete');
  }
}