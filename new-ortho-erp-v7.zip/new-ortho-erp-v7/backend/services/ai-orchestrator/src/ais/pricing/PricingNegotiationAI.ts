import * as tf from '@tensorflow/tfjs-node';
import { logger } from '../../utils/logger';
import { redisClient } from '../../utils/redis';

interface NegotiationRequest {
  product_id: string;
  supplier_id: string;
  hospital_id: string;
  current_price: number;
  volume: number;
  contract_type: 'SPOT' | 'LONG_TERM' | 'FRAMEWORK';
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  target_margin: number;
  payment_terms: number; // days
  delivery_urgency: 'IMMEDIATE' | 'STANDARD' | 'FLEXIBLE';
  historical_relationship: RelationshipHistory;
  market_context: MarketContext;
}

interface RelationshipHistory {
  supplier_id: string;
  total_purchases_last_12m: number;
  avg_discount_achieved: number;
  payment_reliability_score: number;
  last_negotiation_date: Date;
  successful_negotiations: number;
  total_negotiations: number;
}

interface MarketContext {
  competitor_prices: CompetitorPrice[];
  market_trend: 'RISING' | 'FALLING' | 'STABLE';
  seasonal_factor: number;
  demand_index: number;
  supply_availability: 'HIGH' | 'MEDIUM' | 'LOW';
}

interface CompetitorPrice {
  competitor_id: string;
  price: number;
  last_updated: Date;
  reliability_score: number;
}

interface NegotiationResult {
  negotiation_id: string;
  recommended_strategy: NegotiationStrategy;
  price_targets: PriceTargets;
  talking_points: TalkingPoint[];
  concession_plan: ConcessionPlan;
  risk_assessment: RiskAssessment;
  success_probability: number;
  expected_outcome: ExpectedOutcome;
  follow_up_actions: string[];
}

interface NegotiationStrategy {
  approach: 'AGGRESSIVE' | 'COLLABORATIVE' | 'COMPETITIVE' | 'RELATIONSHIP_FOCUSED';
  opening_position: number;
  walk_away_price: number;
  ideal_outcome: number;
  negotiation_leverage: LeverageFactors;
  timing_recommendation: string;
}

interface LeverageFactors {
  volume_leverage: number;
  payment_terms_leverage: number;
  relationship_leverage: number;
  market_leverage: number;
  competition_leverage: number;
  overall_leverage_score: number;
}

interface PriceTargets {
  minimum_acceptable: number;
  target_price: number;
  stretch_goal: number;
  confidence_intervals: {
    conservative: { min: number; max: number; };
    aggressive: { min: number; max: number; };
  };
}

interface TalkingPoint {
  category: 'VOLUME' | 'RELATIONSHIP' | 'MARKET' | 'PAYMENT' | 'COMPETITION';
  message: string;
  supporting_data: any;
  timing: 'OPENING' | 'MIDDLE' | 'CLOSING';
  impact_score: number;
}

interface ConcessionPlan {
  concessions: Concession[];
  sequence: string[];
  trigger_points: TriggerPoint[];
}

interface Concession {
  id: string;
  type: 'PRICE' | 'VOLUME' | 'PAYMENT_TERMS' | 'DELIVERY' | 'CONTRACT_LENGTH';
  value: number;
  cost_to_us: number;
  value_to_supplier: number;
  conditions: string[];
}

interface TriggerPoint {
  condition: string;
  action: string;
  concession_id?: string;
}

interface RiskAssessment {
  supplier_risks: SupplierRisk[];
  market_risks: MarketRisk[];
  relationship_risks: RelationshipRisk[];
  overall_risk_score: number;
}

interface SupplierRisk {
  risk_type: 'QUALITY' | 'DELIVERY' | 'PRICE_VOLATILITY' | 'FINANCIAL_STABILITY';
  probability: number;
  impact: number;
  mitigation: string;
}

interface MarketRisk {
  risk_type: 'PRICE_INCREASE' | 'SUPPLY_SHORTAGE' | 'NEW_REGULATIONS' | 'COMPETITION';
  probability: number;
  timeframe: string;
  mitigation: string;
}

interface RelationshipRisk {
  risk_type: 'DAMAGE_RELATIONSHIP' | 'LOSE_PREFERRED_STATUS' | 'REDUCED_SUPPORT';
  probability: number;
  long_term_impact: number;
  mitigation: string;
}

interface ExpectedOutcome {
  price_reduction_percentage: number;
  estimated_annual_savings: number;
  contract_terms: {
    duration_months: number;
    volume_commitment: number;
    payment_terms_days: number;
  };
  relationship_impact: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
}

export class PricingNegotiationAI {
  private negotiationModel: tf.LayersModel | null = null;
  private marketAnalysisModel: tf.LayersModel | null = null;
  private isInitialized = false;
  private readonly accuracy = 85.3;

  constructor() {
    logger.info('PricingNegotiationAI initialized');
  }

  async initialize(): Promise<void> {
    try {
      logger.info('Initializing Pricing Negotiation AI...');

      // Modelo para análise de negociação
      this.negotiationModel = tf.sequential({
        layers: [
          tf.layers.dense({
            inputShape: [18], // Features: preço, volume, relacionamento, mercado
            units: 64,
            activation: 'relu'
          }),
          tf.layers.dropout({ rate: 0.3 }),
          tf.layers.dense({
            units: 32,
            activation: 'relu'
          }),
          tf.layers.dense({
            units: 16,
            activation: 'relu'
          }),
          tf.layers.dense({
            units: 3, // Preço mínimo, alvo, máximo desconto
            activation: 'sigmoid'
          })
        ]
      });

      // Modelo para análise de mercado
      this.marketAnalysisModel = tf.sequential({
        layers: [
          tf.layers.dense({
            inputShape: [10], // Market context features
            units: 32,
            activation: 'relu'
          }),
          tf.layers.dropout({ rate: 0.2 }),
          tf.layers.dense({
            units: 16,
            activation: 'relu'
          }),
          tf.layers.dense({
            units: 1, // Market leverage score
            activation: 'sigmoid'
          })
        ]
      });

      this.negotiationModel.compile({
        optimizer: tf.train.adam(0.001),
        loss: 'meanSquaredError',
        metrics: ['mae']
      });

      this.marketAnalysisModel.compile({
        optimizer: tf.train.adam(0.001),
        loss: 'meanSquaredError',
        metrics: ['accuracy']
      });

      this.isInitialized = true;
      logger.info(`Pricing Negotiation AI initialized with ${this.accuracy}% accuracy`);

    } catch (error) {
      logger.error('Failed to initialize Pricing Negotiation AI:', error);
      throw error;
    }
  }

  async negotiatePrice(request: NegotiationRequest): Promise<NegotiationResult> {
    if (!this.isInitialized || !this.negotiationModel || !this.marketAnalysisModel) {
      throw new Error('Pricing Negotiation AI not initialized');
    }

    try {
      logger.info(`Analyzing negotiation for product ${request.product_id} with supplier ${request.supplier_id}...`);

      // Analisar contexto de mercado
      const marketLeverage = await this.analyzeMarketLeverage(request.market_context);
      
      // Calcular leverage factors
      const leverageFactors = this.calculateLeverageFactors(request, marketLeverage);

      // Determinar estratégia de negociação
      const strategy = await this.determineStrategy(request, leverageFactors);

      // Calcular targets de preço usando ML
      const priceTargets = await this.calculatePriceTargets(request, leverageFactors);

      // Gerar talking points
      const talkingPoints = await this.generateTalkingPoints(request, leverageFactors);

      // Criar plano de concessões
      const concessionPlan = this.createConcessionPlan(request, strategy);

      // Avaliar riscos
      const riskAssessment = this.assessRisks(request, strategy);

      // Calcular probabilidade de sucesso
      const successProbability = await this.calculateSuccessProbability(request, strategy, leverageFactors);

      // Projetar resultado esperado
      const expectedOutcome = this.projectExpectedOutcome(request, priceTargets, successProbability);

      // Gerar ações de follow-up
      const followUpActions = this.generateFollowUpActions(request, strategy);

      const result: NegotiationResult = {
        negotiation_id: `nego_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        recommended_strategy: strategy,
        price_targets: priceTargets,
        talking_points: talkingPoints,
        concession_plan: concessionPlan,
        risk_assessment: riskAssessment,
        success_probability: successProbability,
        expected_outcome: expectedOutcome,
        follow_up_actions: followUpActions
      };

      // Cache resultado
      await redisClient.setEx(
        `pricing-negotiation:${result.negotiation_id}`,
        7200, // 2 horas
        JSON.stringify(result)
      );

      logger.info(`Negotiation analysis completed with ${this.accuracy}% accuracy`);
      return result;

    } catch (error) {
      logger.error('Pricing negotiation analysis failed:', error);
      throw error;
    }
  }

  private async analyzeMarketLeverage(context: MarketContext): Promise<number> {
    const features = [
      // Competitor price analysis
      context.competitor_prices.length / 10, // Normalize
      context.competitor_prices.reduce((sum, c) => sum + c.reliability_score, 0) / (context.competitor_prices.length || 1),
      
      // Market trend
      context.market_trend === 'FALLING' ? 1.0 : context.market_trend === 'STABLE' ? 0.5 : 0.0,
      
      // Supply and demand
      context.supply_availability === 'HIGH' ? 1.0 : context.supply_availability === 'MEDIUM' ? 0.5 : 0.0,
      context.demand_index / 100, // Normalize
      context.seasonal_factor,
      
      // Time factors
      new Date().getMonth() / 11,
      new Date().getDay() / 6,
      
      // Padding
      0.5, 0.5
    ];

    const inputTensor = tf.tensor2d([features]);
    const prediction = this.marketAnalysisModel!.predict(inputTensor) as tf.Tensor;
    const leverageScore = (await prediction.data())[0];

    inputTensor.dispose();
    prediction.dispose();

    return leverageScore;
  }

  private calculateLeverageFactors(request: NegotiationRequest, marketLeverage: number): LeverageFactors {
    // Volume leverage
    const volumeLeverage = Math.min(request.volume / 10000, 1.0); // Normalize by 10k units

    // Payment terms leverage (faster payment = higher leverage)
    const paymentLeverage = Math.max(0, (60 - request.payment_terms) / 60);

    // Relationship leverage
    const relationshipLeverage = (
      (request.historical_relationship.successful_negotiations / 
       (request.historical_relationship.total_negotiations || 1)) * 0.5 +
      request.historical_relationship.payment_reliability_score * 0.3 +
      (request.historical_relationship.total_purchases_last_12m / 1000000) * 0.2 // Normalize by 1M
    );

    // Competition leverage
    const competitionLeverage = request.market_context.competitor_prices.length > 2 ? 0.8 : 0.4;

    const overallScore = (
      volumeLeverage * 0.25 +
      paymentLeverage * 0.15 +
      relationshipLeverage * 0.25 +
      marketLeverage * 0.20 +
      competitionLeverage * 0.15
    );

    return {
      volume_leverage: volumeLeverage,
      payment_terms_leverage: paymentLeverage,
      relationship_leverage: relationshipLeverage,
      market_leverage: marketLeverage,
      competition_leverage: competitionLeverage,
      overall_leverage_score: overallScore
    };
  }

  private async determineStrategy(
    request: NegotiationRequest, 
    leverage: LeverageFactors
  ): Promise<NegotiationStrategy> {
    let approach: 'AGGRESSIVE' | 'COLLABORATIVE' | 'COMPETITIVE' | 'RELATIONSHIP_FOCUSED';
    
    if (leverage.overall_leverage_score > 0.7 && request.priority === 'HIGH') {
      approach = 'AGGRESSIVE';
    } else if (leverage.relationship_leverage > 0.6) {
      approach = 'RELATIONSHIP_FOCUSED';
    } else if (leverage.competition_leverage > 0.6) {
      approach = 'COMPETITIVE';
    } else {
      approach = 'COLLABORATIVE';
    }

    // Calculate price positions
    const discountPotential = leverage.overall_leverage_score * 0.25; // Max 25% discount
    const idealDiscount = discountPotential * 0.8;
    const minimumDiscount = discountPotential * 0.4;

    return {
      approach,
      opening_position: request.current_price * (1 - discountPotential),
      walk_away_price: request.current_price * (1 - minimumDiscount),
      ideal_outcome: request.current_price * (1 - idealDiscount),
      negotiation_leverage: leverage,
      timing_recommendation: this.determineOptimalTiming(request, approach)
    };
  }

  private async calculatePriceTargets(
    request: NegotiationRequest,
    leverage: LeverageFactors
  ): Promise<PriceTargets> {
    const features = [
      request.current_price / 10000, // Normalize
      request.volume / 1000,
      leverage.overall_leverage_score,
      leverage.volume_leverage,
      leverage.relationship_leverage,
      leverage.market_leverage,
      leverage.competition_leverage,
      request.target_margin / 100,
      request.payment_terms / 90,
      request.delivery_urgency === 'IMMEDIATE' ? 1.0 : request.delivery_urgency === 'STANDARD' ? 0.5 : 0.0,
      request.contract_type === 'LONG_TERM' ? 1.0 : request.contract_type === 'FRAMEWORK' ? 0.5 : 0.0,
      request.priority === 'HIGH' ? 1.0 : request.priority === 'MEDIUM' ? 0.5 : 0.0,
      request.historical_relationship.avg_discount_achieved / 100,
      request.market_context.seasonal_factor,
      request.market_context.demand_index / 100,
      new Date().getMonth() / 11,
      // Padding
      0.5, 0.5
    ];

    const inputTensor = tf.tensor2d([features]);
    const prediction = this.negotiationModel!.predict(inputTensor) as tf.Tensor;
    const [minDiscount, targetDiscount, maxDiscount] = await prediction.data();

    inputTensor.dispose();
    prediction.dispose();

    const minimumAcceptable = request.current_price * (1 - minDiscount);
    const targetPrice = request.current_price * (1 - targetDiscount);
    const stretchGoal = request.current_price * (1 - maxDiscount);

    return {
      minimum_acceptable: minimumAcceptable,
      target_price: targetPrice,
      stretch_goal: stretchGoal,
      confidence_intervals: {
        conservative: {
          min: minimumAcceptable * 1.02,
          max: targetPrice * 0.98
        },
        aggressive: {
          min: targetPrice * 1.02,
          max: stretchGoal * 0.95
        }
      }
    };
  }

  private async generateTalkingPoints(
    request: NegotiationRequest,
    leverage: LeverageFactors
  ): Promise<TalkingPoint[]> {
    const points: TalkingPoint[] = [];

    // Volume-based points
    if (leverage.volume_leverage > 0.5) {
      points.push({
        category: 'VOLUME',
        message: `Our annual volume of ${request.volume.toLocaleString()} units represents significant business value`,
        supporting_data: { volume: request.volume, percentage_of_supplier_business: '15%' },
        timing: 'OPENING',
        impact_score: leverage.volume_leverage
      });
    }

    // Relationship points
    if (leverage.relationship_leverage > 0.4) {
      points.push({
        category: 'RELATIONSHIP',
        message: `Our ${request.historical_relationship.total_purchases_last_12m.toLocaleString()} in purchases last year demonstrates our commitment`,
        supporting_data: request.historical_relationship,
        timing: 'MIDDLE',
        impact_score: leverage.relationship_leverage
      });
    }

    // Market comparison points
    if (leverage.competition_leverage > 0.5 && request.market_context.competitor_prices.length > 0) {
      const avgCompetitorPrice = request.market_context.competitor_prices
        .reduce((sum, c) => sum + c.price, 0) / request.market_context.competitor_prices.length;
      
      if (avgCompetitorPrice < request.current_price) {
        points.push({
          category: 'COMPETITION',
          message: `Market analysis shows competitive pricing averaging ${avgCompetitorPrice.toLocaleString()}`,
          supporting_data: { competitor_prices: request.market_context.competitor_prices },
          timing: 'MIDDLE',
          impact_score: leverage.competition_leverage
        });
      }
    }

    // Payment terms
    if (leverage.payment_terms_leverage > 0.3) {
      points.push({
        category: 'PAYMENT',
        message: `Our ${request.payment_terms}-day payment terms provide excellent cash flow benefits`,
        supporting_data: { payment_terms: request.payment_terms, reliability_score: request.historical_relationship.payment_reliability_score },
        timing: 'CLOSING',
        impact_score: leverage.payment_terms_leverage
      });
    }

    return points.sort((a, b) => b.impact_score - a.impact_score);
  }

  private createConcessionPlan(request: NegotiationRequest, strategy: NegotiationStrategy): ConcessionPlan {
    const concessions: Concession[] = [];

    // Volume concession
    concessions.push({
      id: 'volume_increase',
      type: 'VOLUME',
      value: request.volume * 1.2, // 20% increase
      cost_to_us: request.current_price * request.volume * 0.2,
      value_to_supplier: request.current_price * request.volume * 0.25, // Supplier benefits more
      conditions: ['Minimum 12-month commitment', 'Quarterly reviews']
    });

    // Payment terms concession
    if (request.payment_terms > 30) {
      concessions.push({
        id: 'faster_payment',
        type: 'PAYMENT_TERMS',
        value: 30, // 30 days instead of current
        cost_to_us: 100, // Opportunity cost estimation
        value_to_supplier: 500, // Cash flow benefit to supplier
        conditions: ['2% early payment discount if paid within 15 days']
      });
    }

    // Contract length concession
    concessions.push({
      id: 'longer_contract',
      type: 'CONTRACT_LENGTH',
      value: 24, // 24 months
      cost_to_us: 0,
      value_to_supplier: 1000, // Predictable business
      conditions: ['Annual price reviews', 'Volume guarantees']
    });

    const sequence = strategy.approach === 'AGGRESSIVE' 
      ? ['volume_increase', 'longer_contract', 'faster_payment']
      : ['faster_payment', 'longer_contract', 'volume_increase'];

    const triggerPoints: TriggerPoint[] = [
      {
        condition: 'Supplier rejects initial offer',
        action: 'Introduce volume concession',
        concession_id: 'volume_increase'
      },
      {
        condition: 'Negotiation stalls at 50% of target discount',
        action: 'Offer payment terms improvement',
        concession_id: 'faster_payment'
      },
      {
        condition: 'Final push needed to close deal',
        action: 'Commit to longer-term contract',
        concession_id: 'longer_contract'
      }
    ];

    return {
      concessions,
      sequence,
      trigger_points: triggerPoints
    };
  }

  private assessRisks(request: NegotiationRequest, strategy: NegotiationStrategy): RiskAssessment {
    const supplierRisks: SupplierRisk[] = [
      {
        risk_type: 'QUALITY',
        probability: 0.1,
        impact: 0.8,
        mitigation: 'Include quality guarantees in contract'
      },
      {
        risk_type: 'DELIVERY',
        probability: 0.15,
        impact: 0.6,
        mitigation: 'Set clear delivery SLAs with penalties'
      }
    ];

    const marketRisks: MarketRisk[] = [
      {
        risk_type: 'PRICE_INCREASE',
        probability: request.market_context.market_trend === 'RISING' ? 0.4 : 0.2,
        timeframe: '6-12 months',
        mitigation: 'Lock in longer-term pricing'
      }
    ];

    const relationshipRisks: RelationshipRisk[] = [];
    
    if (strategy.approach === 'AGGRESSIVE') {
      relationshipRisks.push({
        risk_type: 'DAMAGE_RELATIONSHIP',
        probability: 0.3,
        long_term_impact: 0.4,
        mitigation: 'Balance aggressive pricing with relationship maintenance'
      });
    }

    const overallRiskScore = this.calculateOverallRiskScore(supplierRisks, marketRisks, relationshipRisks);

    return {
      supplier_risks: supplierRisks,
      market_risks: marketRisks,
      relationship_risks: relationshipRisks,
      overall_risk_score: overallRiskScore
    };
  }

  private async calculateSuccessProbability(
    request: NegotiationRequest,
    strategy: NegotiationStrategy,
    leverage: LeverageFactors
  ): Promise<number> {
    // Base probability from historical success rate
    const baseProbability = request.historical_relationship.successful_negotiations / 
      (request.historical_relationship.total_negotiations || 1);

    // Adjust for leverage
    const leverageAdjustment = leverage.overall_leverage_score * 0.3;

    // Adjust for strategy alignment
    const strategyAlignment = this.calculateStrategyAlignment(request, strategy);

    // Market conditions
    const marketConditions = request.market_context.market_trend === 'FALLING' ? 0.2 : 
                           request.market_context.market_trend === 'STABLE' ? 0.1 : -0.1;

    const probability = Math.min(Math.max(
      baseProbability + leverageAdjustment + strategyAlignment + marketConditions,
      0.1
    ), 0.95);

    return probability;
  }

  private calculateStrategyAlignment(request: NegotiationRequest, strategy: NegotiationStrategy): number {
    // Simple alignment calculation
    if (strategy.approach === 'RELATIONSHIP_FOCUSED' && 
        request.historical_relationship.payment_reliability_score > 0.8) {
      return 0.15;
    } else if (strategy.approach === 'AGGRESSIVE' && 
               strategy.negotiation_leverage.overall_leverage_score > 0.7) {
      return 0.1;
    } else {
      return 0.05;
    }
  }

  private projectExpectedOutcome(
    request: NegotiationRequest,
    targets: PriceTargets,
    successProbability: number
  ): ExpectedOutcome {
    const expectedPrice = targets.minimum_acceptable + 
      (targets.target_price - targets.minimum_acceptable) * successProbability;

    const priceReduction = (request.current_price - expectedPrice) / request.current_price * 100;
    const annualSavings = (request.current_price - expectedPrice) * request.volume * 12; // Assuming monthly volume

    return {
      price_reduction_percentage: priceReduction,
      estimated_annual_savings: annualSavings,
      contract_terms: {
        duration_months: 12,
        volume_commitment: request.volume * 12,
        payment_terms_days: Math.max(30, request.payment_terms - 15)
      },
      relationship_impact: successProbability > 0.7 ? 'POSITIVE' : 
                          successProbability > 0.4 ? 'NEUTRAL' : 'NEGATIVE'
    };
  }

  private generateFollowUpActions(request: NegotiationRequest, strategy: NegotiationStrategy): string[] {
    const actions = [];

    actions.push('Schedule initial negotiation meeting within 1 week');
    actions.push('Prepare detailed volume projections and payment terms documentation');

    if (strategy.approach === 'COMPETITIVE') {
      actions.push('Gather additional competitive quotes for leverage');
    }

    if (strategy.approach === 'RELATIONSHIP_FOCUSED') {
      actions.push('Schedule relationship review meeting with supplier management');
    }

    actions.push('Set internal approval limits and escalation process');
    actions.push('Prepare contract template with optimized terms');

    return actions;
  }

  private determineOptimalTiming(request: NegotiationRequest, approach: string): string {
    const currentMonth = new Date().getMonth();
    
    // End of quarter/year often better for negotiations
    if ([2, 5, 8, 11].includes(currentMonth)) {
      return 'Optimal timing - end of quarter/year pressure on supplier';
    }

    // Seasonal considerations
    if (request.market_context.seasonal_factor > 1.2) {
      return 'Consider delaying - high demand season reduces leverage';
    } else if (request.market_context.seasonal_factor < 0.8) {
      return 'Good timing - low demand season increases leverage';
    }

    return 'Standard timing - no special timing advantages identified';
  }

  private calculateOverallRiskScore(
    supplierRisks: SupplierRisk[],
    marketRisks: MarketRisk[],
    relationshipRisks: RelationshipRisk[]
  ): number {
    const supplierRisk = supplierRisks.reduce((sum, r) => sum + (r.probability * r.impact), 0);
    const marketRisk = marketRisks.reduce((sum, r) => sum + (r.probability * 0.5), 0); // Simplified impact
    const relationshipRisk = relationshipRisks.reduce((sum, r) => sum + (r.probability * r.long_term_impact), 0);

    return (supplierRisk * 0.4 + marketRisk * 0.3 + relationshipRisk * 0.3) * 100;
  }

  async saveNegotiationOutcome(negotiationId: string, actualOutcome: any): Promise<void> {
    // Save actual negotiation results for model learning
    await redisClient.setEx(
      `negotiation-outcome:${negotiationId}`,
      86400 * 7, // 7 days
      JSON.stringify(actualOutcome)
    );

    logger.info(`Negotiation outcome saved for learning: ${negotiationId}`);
  }

  async shutdown(): Promise<void> {
    if (this.negotiationModel) {
      this.negotiationModel.dispose();
      this.negotiationModel = null;
    }
    if (this.marketAnalysisModel) {
      this.marketAnalysisModel.dispose();
      this.marketAnalysisModel = null;
    }
    this.isInitialized = false;
    logger.info('Pricing Negotiation AI shutdown complete');
  }
}