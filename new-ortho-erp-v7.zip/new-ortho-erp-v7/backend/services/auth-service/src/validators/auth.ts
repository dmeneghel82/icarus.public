import Joi from 'joi';

// Login validation schema
export const validateLogin = (data: any) => {
  const schema = Joi.object({
    email: Joi.string()
      .email()
      .required()
      .messages({
        'string.email': 'Please provide a valid email address',
        'any.required': 'Email is required',
      }),
    password: Joi.string()
      .min(6)
      .required()
      .messages({
        'string.min': 'Password must be at least 6 characters long',
        'any.required': 'Password is required',
      }),
  });

  return schema.validate(data);
};

// Register validation schema
export const validateRegister = (data: any) => {
  const schema = Joi.object({
    email: Joi.string()
      .email()
      .required()
      .messages({
        'string.email': 'Please provide a valid email address',
        'any.required': 'Email is required',
      }),
    password: Joi.string()
      .min(8)
      .pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])'))
      .required()
      .messages({
        'string.min': 'Password must be at least 8 characters long',
        'string.pattern.base': 'Password must contain at least one lowercase letter, one uppercase letter, one number, and one special character',
        'any.required': 'Password is required',
      }),
    confirmPassword: Joi.string()
      .valid(Joi.ref('password'))
      .required()
      .messages({
        'any.only': 'Passwords do not match',
        'any.required': 'Password confirmation is required',
      }),
    firstName: Joi.string()
      .min(2)
      .max(50)
      .required()
      .messages({
        'string.min': 'First name must be at least 2 characters long',
        'string.max': 'First name must not exceed 50 characters',
        'any.required': 'First name is required',
      }),
    lastName: Joi.string()
      .min(2)
      .max(50)
      .required()
      .messages({
        'string.min': 'Last name must be at least 2 characters long',
        'string.max': 'Last name must not exceed 50 characters',
        'any.required': 'Last name is required',
      }),
    role: Joi.string()
      .valid('ADMIN', 'MANAGER', 'USER', 'TECHNICIAN', 'DOCTOR')
      .default('USER')
      .messages({
        'any.only': 'Role must be one of: ADMIN, MANAGER, USER, TECHNICIAN, DOCTOR',
      }),
    department: Joi.string()
      .valid(
        'ADMINISTRATION',
        'SALES', 
        'PURCHASES',
        'INVENTORY',
        'FINANCIAL',
        'SURGERY',
        'QUALITY',
        'IT',
        'HR'
      )
      .optional()
      .messages({
        'any.only': 'Invalid department selected',
      }),
    phone: Joi.string()
      .pattern(new RegExp('^[\+]?[1-9][\d]{0,15}$'))
      .optional()
      .messages({
        'string.pattern.base': 'Please provide a valid phone number',
      }),
  });

  return schema.validate(data);
};

// Forgot password validation schema
export const validateForgotPassword = (data: any) => {
  const schema = Joi.object({
    email: Joi.string()
      .email()
      .required()
      .messages({
        'string.email': 'Please provide a valid email address',
        'any.required': 'Email is required',
      }),
  });

  return schema.validate(data);
};

// Reset password validation schema
export const validateResetPassword = (data: any) => {
  const schema = Joi.object({
    token: Joi.string()
      .required()
      .messages({
        'any.required': 'Reset token is required',
      }),
    password: Joi.string()
      .min(8)
      .pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])'))
      .required()
      .messages({
        'string.min': 'Password must be at least 8 characters long',
        'string.pattern.base': 'Password must contain at least one lowercase letter, one uppercase letter, one number, and one special character',
        'any.required': 'Password is required',
      }),
    confirmPassword: Joi.string()
      .valid(Joi.ref('password'))
      .required()
      .messages({
        'any.only': 'Passwords do not match',
        'any.required': 'Password confirmation is required',
      }),
  });

  return schema.validate(data);
};

// Change password validation schema
export const validateChangePassword = (data: any) => {
  const schema = Joi.object({
    currentPassword: Joi.string()
      .required()
      .messages({
        'any.required': 'Current password is required',
      }),
    newPassword: Joi.string()
      .min(8)
      .pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])'))
      .required()
      .messages({
        'string.min': 'New password must be at least 8 characters long',
        'string.pattern.base': 'New password must contain at least one lowercase letter, one uppercase letter, one number, and one special character',
        'any.required': 'New password is required',
      }),
    confirmPassword: Joi.string()
      .valid(Joi.ref('newPassword'))
      .required()
      .messages({
        'any.only': 'Passwords do not match',
        'any.required': 'Password confirmation is required',
      }),
  });

  return schema.validate(data);
};

// Update profile validation schema
export const validateUpdateProfile = (data: any) => {
  const schema = Joi.object({
    firstName: Joi.string()
      .min(2)
      .max(50)
      .optional()
      .messages({
        'string.min': 'First name must be at least 2 characters long',
        'string.max': 'First name must not exceed 50 characters',
      }),
    lastName: Joi.string()
      .min(2)
      .max(50)
      .optional()
      .messages({
        'string.min': 'Last name must be at least 2 characters long',
        'string.max': 'Last name must not exceed 50 characters',
      }),
    phone: Joi.string()
      .pattern(new RegExp('^[\+]?[1-9][\d]{0,15}$'))
      .optional()
      .allow('')
      .messages({
        'string.pattern.base': 'Please provide a valid phone number',
      }),
    department: Joi.string()
      .valid(
        'ADMINISTRATION',
        'SALES', 
        'PURCHASES',
        'INVENTORY',
        'FINANCIAL',
        'SURGERY',
        'QUALITY',
        'IT',
        'HR'
      )
      .optional()
      .messages({
        'any.only': 'Invalid department selected',
      }),
  });

  return schema.validate(data);
};