import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import { authRoutes } from './routes/auth';
import { errorHandler } from './middleware/errorHandler';
import { logger } from './utils/logger';
import { redisClient } from './utils/redis';
import { prisma } from './utils/database';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8001;

// ======================
// SECURITY MIDDLEWARE
// ======================

app.use(helmet());
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://app.neworth.com'] 
    : ['http://localhost:3000', 'http://localhost:3001'],
  credentials: true,
}));

// Auth-specific rate limiting
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 auth requests per windowMs
  message: 'Too many authentication attempts, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/api/login', authLimiter);
app.use('/api/register', authLimiter);
app.use('/api/forgot-password', authLimiter);

// Body parsing
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// ======================
// HEALTH CHECK
// ======================

app.get('/health', async (req, res) => {
  try {
    // Check database connection
    await prisma.$queryRaw`SELECT 1`;
    
    // Check Redis connection
    await redisClient.ping();
    
    res.json({
      status: 'ok',
      service: 'auth-service',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: process.env.npm_package_version || '1.0.0',
      database: 'connected',
      cache: 'connected',
    });
  } catch (error) {
    logger.error('Health check failed:', error);
    res.status(503).json({
      status: 'error',
      service: 'auth-service',
      timestamp: new Date().toISOString(),
      error: 'Service unavailable',
    });
  }
});

// ======================
// API ROUTES
// ======================

app.use('/api', authRoutes);

// ======================
// ERROR HANDLING
// ======================

app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.originalUrl} not found`,
    service: 'auth-service',
    timestamp: new Date().toISOString(),
  });
});

app.use(errorHandler);

// ======================
// SERVER STARTUP
// ======================

const startServer = async () => {
  try {
    // Test database connection
    await prisma.$connect();
    logger.info('Connected to PostgreSQL database');

    // Test Redis connection
    await redisClient.ping();
    logger.info('Connected to Redis');

    // Start server
    app.listen(PORT, () => {
      logger.info(`🔐 NEW ORTHO Auth Service running on port ${PORT}`);
      logger.info(`💚 Health Check: http://localhost:${PORT}/health`);
    });

  } catch (error) {
    logger.error('Failed to start auth service:', error);
    process.exit(1);
  }
};

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received. Shutting down auth service gracefully...');
  await prisma.$disconnect();
  await redisClient.quit();
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received. Shutting down auth service gracefully...');
  await prisma.$disconnect();
  await redisClient.quit();
  process.exit(0);
});

startServer();