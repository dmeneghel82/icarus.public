import nodemailer from 'nodemailer';
import { logger } from './logger';

// Email configuration
const emailConfig = {
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true', // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER || 'noreply@neworth.com',
    pass: process.env.SMTP_PASS || 'your_app_password_here',
  },
};

// Create transporter
const createTransporter = () => {
  return nodemailer.createTransporter(emailConfig);
};

// Email templates
const emailTemplates = {
  passwordReset: {
    subject: 'NEW ORTHO ERP - Password Reset Request',
    html: (resetToken: string, userEmail: string) => `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Reset - NEW ORTHO ERP</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #1a1b2e, #2d2d3f); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
          .button { display: inline-block; background: #8b5cf6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
          .warning { background: #ff675730; border-left: 4px solid #ff4757; padding: 15px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🏥 NEW ORTHO ERP</h1>
            <p>Password Reset Request</p>
          </div>
          <div class="content">
            <h2>Hello,</h2>
            <p>We received a request to reset the password for your NEW ORTHO ERP account associated with <strong>${userEmail}</strong>.</p>
            
            <p>Click the button below to reset your password:</p>
            
            <a href="${process.env.FRONTEND_URL || 'http://localhost:3001'}/reset-password?token=${resetToken}" class="button">
              Reset Password
            </a>
            
            <div class="warning">
              <strong>⚠️ Important:</strong>
              <ul>
                <li>This link will expire in 1 hour</li>
                <li>If you didn't request this reset, please ignore this email</li>
                <li>For security, this link can only be used once</li>
              </ul>
            </div>
            
            <p>If the button doesn't work, copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #8b5cf6;">
              ${process.env.FRONTEND_URL || 'http://localhost:3001'}/reset-password?token=${resetToken}
            </p>
            
            <p>If you have any questions, please contact our support team.</p>
            
            <p>Best regards,<br>NEW ORTHO ERP Security Team</p>
          </div>
          <div class="footer">
            <p>© 2025 NEW ORTHO. All rights reserved.</p>
            <p>This is an automated email. Please do not reply to this message.</p>
          </div>
        </div>
      </body>
      </html>
    `,
  },
  
  welcomeEmail: {
    subject: 'Welcome to NEW ORTHO ERP v7',
    html: (firstName: string, email: string) => `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome - NEW ORTHO ERP</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #1a1b2e, #2d2d3f); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
          .feature { background: white; padding: 15px; margin: 10px 0; border-radius: 6px; border-left: 4px solid #00d4aa; }
          .button { display: inline-block; background: #8b5cf6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🏥 NEW ORTHO ERP v7</h1>
            <p>Welcome to the Future of OPME Management</p>
          </div>
          <div class="content">
            <h2>Welcome, ${firstName}! 🎉</h2>
            <p>Your NEW ORTHO ERP account has been successfully created with email: <strong>${email}</strong></p>
            
            <p>You now have access to the most advanced OPME management system with:</p>
            
            <div class="feature">
              <h3>🤖 105 Specialized AIs</h3>
              <p>Intelligent automation for surgery scheduling, inventory management, and financial optimization</p>
            </div>
            
            <div class="feature">
              <h3>🔗 250+ API Integrations</h3>
              <p>Seamless connections with SISCOMEX, SEFAZ, ANVISA, and hospital systems</p>
            </div>
            
            <div class="feature">
              <h3>🎨 Modern Interface</h3>
              <p>Glassmorphism design with intuitive workflows for all OPME processes</p>
            </div>
            
            <a href="${process.env.FRONTEND_URL || 'http://localhost:3001'}/login" class="button">
              Access NEW ORTHO ERP
            </a>
            
            <p>Need help getting started? Check out our documentation or contact our support team.</p>
            
            <p>Best regards,<br>NEW ORTHO Team</p>
          </div>
          <div class="footer">
            <p>© 2025 NEW ORTHO. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
  },
};

/**
 * Send password reset email
 */
export const sendPasswordResetEmail = async (email: string, resetToken: string): Promise<void> => {
  try {
    const transporter = createTransporter();
    
    const mailOptions = {
      from: {
        name: 'NEW ORTHO ERP',
        address: emailConfig.auth.user,
      },
      to: email,
      subject: emailTemplates.passwordReset.subject,
      html: emailTemplates.passwordReset.html(resetToken, email),
    };

    const result = await transporter.sendMail(mailOptions);
    
    logger.info('Password reset email sent successfully:', {
      messageId: result.messageId,
      recipient: email,
    });

  } catch (error) {
    logger.error('Failed to send password reset email:', error);
    throw new Error('Failed to send password reset email');
  }
};

/**
 * Send welcome email
 */
export const sendWelcomeEmail = async (email: string, firstName: string): Promise<void> => {
  try {
    const transporter = createTransporter();
    
    const mailOptions = {
      from: {
        name: 'NEW ORTHO ERP',
        address: emailConfig.auth.user,
      },
      to: email,
      subject: emailTemplates.welcomeEmail.subject,
      html: emailTemplates.welcomeEmail.html(firstName, email),
    };

    const result = await transporter.sendMail(mailOptions);
    
    logger.info('Welcome email sent successfully:', {
      messageId: result.messageId,
      recipient: email,
    });

  } catch (error) {
    logger.error('Failed to send welcome email:', error);
    // Don't throw error for welcome email as it's not critical
  }
};

/**
 * Send custom email
 */
export const sendCustomEmail = async (
  to: string,
  subject: string,
  htmlContent: string,
  textContent?: string
): Promise<void> => {
  try {
    const transporter = createTransporter();
    
    const mailOptions = {
      from: {
        name: 'NEW ORTHO ERP',
        address: emailConfig.auth.user,
      },
      to,
      subject,
      html: htmlContent,
      text: textContent,
    };

    const result = await transporter.sendMail(mailOptions);
    
    logger.info('Custom email sent successfully:', {
      messageId: result.messageId,
      recipient: to,
      subject,
    });

  } catch (error) {
    logger.error('Failed to send custom email:', error);
    throw new Error('Failed to send email');
  }
};

/**
 * Verify email configuration
 */
export const verifyEmailConfig = async (): Promise<boolean> => {
  try {
    const transporter = createTransporter();
    await transporter.verify();
    logger.info('Email configuration verified successfully');
    return true;
  } catch (error) {
    logger.error('Email configuration verification failed:', error);
    return false;
  }
};