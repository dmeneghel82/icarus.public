import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'ortho_jwt_secret_key_2025_secure';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'ortho_refresh_secret_key_2025_secure';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '15m'; // 15 minutes
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '7d'; // 7 days

interface TokenPayload {
  userId: string;
  email: string;
  role: string;
  permissions: string[];
}

interface GeneratedTokens {
  accessToken: string;
  refreshToken: string;
}

/**
 * Generate access and refresh tokens
 */
export const generateTokens = (payload: TokenPayload): GeneratedTokens => {
  const accessToken = jwt.sign(
    {
      userId: payload.userId,
      email: payload.email,
      role: payload.role,
      permissions: payload.permissions,
      type: 'access',
    },
    JWT_SECRET,
    {
      expiresIn: JWT_EXPIRES_IN,
      issuer: 'new-ortho-erp',
      audience: 'new-ortho-users',
    }
  );

  const refreshToken = jwt.sign(
    {
      userId: payload.userId,
      email: payload.email,
      type: 'refresh',
    },
    JWT_REFRESH_SECRET,
    {
      expiresIn: JWT_REFRESH_EXPIRES_IN,
      issuer: 'new-ortho-erp',
      audience: 'new-ortho-users',
    }
  );

  return {
    accessToken,
    refreshToken,
  };
};

/**
 * Verify JWT token
 */
export const verifyToken = (token: string, type: 'access' | 'refresh' = 'access') => {
  const secret = type === 'access' ? JWT_SECRET : JWT_REFRESH_SECRET;
  
  return jwt.verify(token, secret, {
    issuer: 'new-ortho-erp',
    audience: 'new-ortho-users',
  });
};

/**
 * Decode JWT token without verification (use with caution)
 */
export const decodeToken = (token: string) => {
  return jwt.decode(token);
};

/**
 * Get token expiration time
 */
export const getTokenExpiration = (token: string): Date | null => {
  try {
    const decoded = jwt.decode(token) as any;
    if (decoded && decoded.exp) {
      return new Date(decoded.exp * 1000);
    }
    return null;
  } catch (error) {
    return null;
  }
};

/**
 * Check if token is expired
 */
export const isTokenExpired = (token: string): boolean => {
  try {
    const decoded = jwt.decode(token) as any;
    if (decoded && decoded.exp) {
      return Date.now() >= decoded.exp * 1000;
    }
    return true;
  } catch (error) {
    return true;
  }
};

/**
 * Generate password reset token (different from JWT)
 */
export const generatePasswordResetToken = (): string => {
  return jwt.sign(
    {
      type: 'password-reset',
      timestamp: Date.now(),
    },
    JWT_SECRET,
    {
      expiresIn: '1h', // 1 hour
      issuer: 'new-ortho-erp',
    }
  );
};

/**
 * Verify password reset token
 */
export const verifyPasswordResetToken = (token: string) => {
  return jwt.verify(token, JWT_SECRET, {
    issuer: 'new-ortho-erp',
  });
};