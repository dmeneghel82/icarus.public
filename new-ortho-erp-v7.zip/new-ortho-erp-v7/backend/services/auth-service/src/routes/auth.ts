import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../utils/database';
import { redisClient } from '../utils/redis';
import { logger } from '../utils/logger';
import { validateLogin, validateRegister, validateForgotPassword } from '../validators/auth';
import { generateTokens, verifyToken } from '../utils/jwt';
import { sendPasswordResetEmail } from '../utils/email';
import { asyncHandler } from '../middleware/asyncHandler';
import crypto from 'crypto';

const router = Router();

// ======================
// AUTHENTICATION ROUTES
// ======================

/**
 * POST /api/register
 * Register new user
 */
router.post('/register', asyncHandler(async (req, res) => {
  // Validate input
  const { error, value } = validateRegister(req.body);
  if (error) {
    return res.status(400).json({
      success: false,
      error: 'Validation error',
      details: error.details.map(detail => detail.message),
    });
  }

  const { email, password, firstName, lastName, role, department } = value;

  // Check if user already exists
  const existingUser = await prisma.user.findUnique({
    where: { email },
  });

  if (existingUser) {
    return res.status(409).json({
      success: false,
      error: 'User already exists',
      message: 'A user with this email already exists',
    });
  }

  // Hash password
  const saltRounds = 12;
  const hashedPassword = await bcrypt.hash(password, saltRounds);

  // Create user
  const user = await prisma.user.create({
    data: {
      email,
      password: hashedPassword,
      firstName,
      lastName,
      role: role || 'USER',
      department,
      isActive: true,
      emailVerified: false,
      createdAt: new Date(),
    },
    select: {
      id: true,
      email: true,
      firstName: true,
      lastName: true,
      role: true,
      department: true,
      isActive: true,
      createdAt: true,
    },
  });

  logger.info(`New user registered: ${email}`);

  res.status(201).json({
    success: true,
    message: 'User registered successfully',
    user,
  });
}));

/**
 * POST /api/login
 * User authentication
 */
router.post('/login', asyncHandler(async (req, res) => {
  // Validate input
  const { error, value } = validateLogin(req.body);
  if (error) {
    return res.status(400).json({
      success: false,
      error: 'Validation error',
      details: error.details.map(detail => detail.message),
    });
  }

  const { email, password } = value;

  // Find user with permissions
  const user = await prisma.user.findUnique({
    where: { email },
    include: {
      userRoles: {
        include: {
          role: {
            include: {
              rolePermissions: {
                include: {
                  permission: true,
                },
              },
            },
          },
        },
      },
    },
  });

  if (!user) {
    return res.status(401).json({
      success: false,
      error: 'Authentication failed',
      message: 'Invalid credentials',
    });
  }

  if (!user.isActive) {
    return res.status(401).json({
      success: false,
      error: 'Account disabled',
      message: 'Your account has been disabled. Please contact support.',
    });
  }

  // Verify password
  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) {
    return res.status(401).json({
      success: false,
      error: 'Authentication failed',
      message: 'Invalid credentials',
    });
  }

  // Extract permissions
  const permissions = user.userRoles.flatMap(ur => 
    ur.role.rolePermissions.map(rp => rp.permission.name)
  );

  // Generate tokens
  const { accessToken, refreshToken } = generateTokens({
    userId: user.id,
    email: user.email,
    role: user.role,
    permissions,
  });

  // Store refresh token in Redis (expires in 7 days)
  await redisClient.setEx(`refresh_token:${user.id}`, 7 * 24 * 60 * 60, refreshToken);

  // Store user session in Redis (expires in 24 hours)
  await redisClient.setEx(
    `session:${user.id}`, 
    24 * 60 * 60, 
    JSON.stringify({
      userId: user.id,
      email: user.email,
      role: user.role,
      permissions,
      loginTime: new Date().toISOString(),
    })
  );

  // Update last login
  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });

  logger.info(`User logged in: ${email}`);

  res.json({
    success: true,
    message: 'Login successful',
    user: {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
      department: user.department,
      permissions,
    },
    tokens: {
      accessToken,
      refreshToken,
    },
  });
}));

/**
 * POST /api/refresh
 * Refresh access token using refresh token
 */
router.post('/refresh', asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(400).json({
      success: false,
      error: 'Refresh token required',
    });
  }

  try {
    // Verify refresh token
    const decoded = verifyToken(refreshToken, 'refresh') as any;
    
    // Check if refresh token exists in Redis
    const storedToken = await redisClient.get(`refresh_token:${decoded.userId}`);
    if (storedToken !== refreshToken) {
      return res.status(401).json({
        success: false,
        error: 'Invalid refresh token',
      });
    }

    // Get user with permissions
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      include: {
        userRoles: {
          include: {
            role: {
              include: {
                rolePermissions: {
                  include: {
                    permission: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!user || !user.isActive) {
      return res.status(401).json({
        success: false,
        error: 'User not found or inactive',
      });
    }

    // Extract permissions
    const permissions = user.userRoles.flatMap(ur => 
      ur.role.rolePermissions.map(rp => rp.permission.name)
    );

    // Generate new access token
    const { accessToken } = generateTokens({
      userId: user.id,
      email: user.email,
      role: user.role,
      permissions,
    });

    res.json({
      success: true,
      message: 'Token refreshed successfully',
      accessToken,
    });

  } catch (error) {
    return res.status(401).json({
      success: false,
      error: 'Invalid refresh token',
    });
  }
}));

/**
 * POST /api/logout
 * User logout
 */
router.post('/logout', asyncHandler(async (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(400).json({
      success: false,
      error: 'Token required for logout',
    });
  }

  try {
    const decoded = verifyToken(token) as any;
    
    // Add token to blacklist (expires when token would expire)
    const tokenExp = decoded.exp * 1000;
    const now = Date.now();
    const ttl = Math.max(0, Math.floor((tokenExp - now) / 1000));
    
    if (ttl > 0) {
      await redisClient.setEx(`blacklist:${token}`, ttl, 'true');
    }

    // Remove refresh token
    await redisClient.del(`refresh_token:${decoded.userId}`);
    
    // Remove user session
    await redisClient.del(`session:${decoded.userId}`);

    logger.info(`User logged out: ${decoded.email}`);

    res.json({
      success: true,
      message: 'Logout successful',
    });

  } catch (error) {
    // Even if token is invalid, we consider logout successful
    res.json({
      success: true,
      message: 'Logout successful',
    });
  }
}));

/**
 * POST /api/forgot-password
 * Request password reset
 */
router.post('/forgot-password', asyncHandler(async (req, res) => {
  const { error, value } = validateForgotPassword(req.body);
  if (error) {
    return res.status(400).json({
      success: false,
      error: 'Validation error',
      details: error.details.map(detail => detail.message),
    });
  }

  const { email } = value;

  const user = await prisma.user.findUnique({
    where: { email },
  });

  // Always return success to prevent email enumeration
  const response = {
    success: true,
    message: 'If the email exists in our system, you will receive a password reset link',
  };

  if (!user || !user.isActive) {
    return res.json(response);
  }

  // Generate password reset token
  const resetToken = crypto.randomBytes(32).toString('hex');
  const resetTokenExpiry = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

  // Store reset token
  await prisma.user.update({
    where: { id: user.id },
    data: {
      resetToken,
      resetTokenExpiry,
    },
  });

  // Send password reset email
  try {
    await sendPasswordResetEmail(user.email, resetToken);
    logger.info(`Password reset email sent to: ${email}`);
  } catch (error) {
    logger.error('Failed to send password reset email:', error);
  }

  res.json(response);
}));

/**
 * POST /api/reset-password
 * Reset password using token
 */
router.post('/reset-password', asyncHandler(async (req, res) => {
  const { token, password } = req.body;

  if (!token || !password) {
    return res.status(400).json({
      success: false,
      error: 'Token and password are required',
    });
  }

  if (password.length < 8) {
    return res.status(400).json({
      success: false,
      error: 'Password must be at least 8 characters long',
    });
  }

  const user = await prisma.user.findFirst({
    where: {
      resetToken: token,
      resetTokenExpiry: {
        gt: new Date(),
      },
    },
  });

  if (!user) {
    return res.status(400).json({
      success: false,
      error: 'Invalid or expired reset token',
    });
  }

  // Hash new password
  const hashedPassword = await bcrypt.hash(password, 12);

  // Update password and clear reset token
  await prisma.user.update({
    where: { id: user.id },
    data: {
      password: hashedPassword,
      resetToken: null,
      resetTokenExpiry: null,
    },
  });

  logger.info(`Password reset successful for user: ${user.email}`);

  res.json({
    success: true,
    message: 'Password reset successful',
  });
}));

/**
 * GET /api/me
 * Get current user info
 */
router.get('/me', asyncHandler(async (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({
      success: false,
      error: 'Token required',
    });
  }

  try {
    const decoded = verifyToken(token) as any;
    
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        department: true,
        isActive: true,
        emailVerified: true,
        lastLoginAt: true,
        createdAt: true,
      },
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found',
      });
    }

    res.json({
      success: true,
      user,
    });

  } catch (error) {
    return res.status(401).json({
      success: false,
      error: 'Invalid token',
    });
  }
}));

export { router as authRoutes };