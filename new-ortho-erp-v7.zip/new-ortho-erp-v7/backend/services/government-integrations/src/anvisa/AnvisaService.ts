import axios, { AxiosInstance } from 'axios';
import { logger } from '../utils/logger';
import { redisClient } from '../utils/redis';
import * as crypto from 'crypto';

interface AnvisaCredentials {
  client_id: string;
  client_secret: string;
  cnpj: string;
  certificate_path: string;
  private_key_path: string;
  environment: 'production' | 'homologation';
}

interface MedicalDeviceRegistry {
  registration_number: string;
  product_name: string;
  manufacturer_name: string;
  manufacturer_country: string;
  regulatory_class: 'I' | 'II' | 'III' | 'IV';
  registration_type: 'PRODUCT' | 'GROUP' | 'SYSTEM';
  registration_status: 'ACTIVE' | 'EXPIRED' | 'CANCELLED' | 'SUSPENDED';
  registration_date: Date;
  expiration_date: Date;
  technical_description: string;
  intended_use: string;
  ncm_code: string;
  gtin_ean?: string;
  lot_control_required: boolean;
  sterilization_required: boolean;
  single_use: boolean;
  implantable: boolean;
  life_support: boolean;
  contraindications: string[];
  warnings: string[];
  storage_conditions: string;
  shelf_life_months: number;
  registration_holder: CompanyInfo;
  authorized_representatives: CompanyInfo[];
  manufacturing_sites: ManufacturingSite[];
  clinical_evaluation: ClinicalEvaluation;
  quality_certifications: QualityCertification[];
  post_market_surveillance: PostMarketSurveillance;
}

interface CompanyInfo {
  cnpj: string;
  company_name: string;
  fantasy_name?: string;
  address: Address;
  contact_info: ContactInfo;
  anvisa_authorization: string;
  authorization_expiry: Date;
  responsible_technical: TechnicalResponsible;
}

interface Address {
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
  zip_code: string;
  country: string;
}

interface ContactInfo {
  phone: string;
  email: string;
  website?: string;
}

interface TechnicalResponsible {
  name: string;
  profession: string;
  registration_number: string;
  registration_council: string;
}

interface ManufacturingSite {
  site_id: string;
  company_name: string;
  address: Address;
  country: string;
  gmp_certification: string;
  certification_expiry: Date;
  inspection_status: 'APPROVED' | 'PENDING' | 'NON_COMPLIANT';
  last_inspection_date: Date;
}

interface ClinicalEvaluation {
  evaluation_type: 'CLINICAL_INVESTIGATION' | 'LITERATURE_REVIEW' | 'COMBINATION';
  studies_count: number;
  patients_enrolled: number;
  primary_endpoint_met: boolean;
  safety_profile: 'EXCELLENT' | 'GOOD' | 'ACCEPTABLE' | 'CONCERNING';
  effectiveness_demonstrated: boolean;
  follow_up_required: boolean;
  study_locations: string[];
}

interface QualityCertification {
  certification_type: 'ISO13485' | 'CE_MARK' | 'FDA_510K' | 'GMP' | 'OTHER';
  certification_number: string;
  certifying_body: string;
  issue_date: Date;
  expiry_date: Date;
  scope: string;
  status: 'VALID' | 'EXPIRED' | 'SUSPENDED';
}

interface PostMarketSurveillance {
  surveillance_plan: string;
  periodic_reports_required: boolean;
  report_frequency_months: number;
  adverse_events_reported: number;
  field_safety_notices: number;
  recalls_initiated: number;
  effectiveness_confirmed: boolean;
  risk_benefit_positive: boolean;
}

interface EstablishmentInfo {
  cnpj: string;
  company_name: string;
  fantasy_name?: string;
  establishment_type: 'MANUFACTURER' | 'IMPORTER' | 'DISTRIBUTOR' | 'RETAILER' | 'HOSPITAL' | 'CLINIC';
  anvisa_authorization: string;
  authorization_status: 'ACTIVE' | 'EXPIRED' | 'CANCELLED' | 'SUSPENDED';
  authorization_date: Date;
  expiration_date: Date;
  address: Address;
  contact_info: ContactInfo;
  responsible_technical: TechnicalResponsible;
  authorized_activities: AuthorizedActivity[];
  inspection_history: InspectionRecord[];
  compliance_status: ComplianceStatus;
  product_categories: string[];
  quality_system: QualitySystemInfo;
}

interface AuthorizedActivity {
  activity_code: string;
  activity_description: string;
  product_classes: string[];
  geographical_scope: 'LOCAL' | 'REGIONAL' | 'NATIONAL' | 'INTERNATIONAL';
  volume_limit?: number;
  special_conditions: string[];
}

interface InspectionRecord {
  inspection_id: string;
  inspection_date: Date;
  inspection_type: 'ROUTINE' | 'FOR_CAUSE' | 'PRE_MARKET' | 'SURVEILLANCE';
  inspector_team: string[];
  findings: InspectionFinding[];
  overall_rating: 'COMPLIANT' | 'MINOR_DEFICIENCIES' | 'MAJOR_DEFICIENCIES' | 'CRITICAL';
  corrective_actions_required: boolean;
  follow_up_date?: Date;
  reinspection_required: boolean;
}

interface InspectionFinding {
  finding_id: string;
  regulation_reference: string;
  severity: 'CRITICAL' | 'MAJOR' | 'MINOR' | 'OBSERVATION';
  description: string;
  evidence: string;
  corrective_action_required: string;
  response_deadline: Date;
  status: 'OPEN' | 'CLOSED' | 'PENDING';
}

interface ComplianceStatus {
  overall_status: 'COMPLIANT' | 'NON_COMPLIANT' | 'UNDER_REVIEW';
  open_violations: number;
  pending_corrective_actions: number;
  compliance_score: number; // 0-100
  last_assessment_date: Date;
  next_assessment_due: Date;
  risk_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

interface QualitySystemInfo {
  iso13485_certified: boolean;
  certification_body: string;
  certificate_number: string;
  certificate_expiry: Date;
  internal_audit_frequency: number;
  management_review_frequency: number;
  capa_system_implemented: boolean;
  design_controls_implemented: boolean;
  supplier_controls_implemented: boolean;
}

interface AdverseEventReport {
  report_id: string;
  product_registration: string;
  product_name: string;
  manufacturer_name: string;
  event_date: Date;
  report_date: Date;
  reporter_type: 'HEALTHCARE_PROFESSIONAL' | 'PATIENT' | 'MANUFACTURER' | 'IMPORTER';
  reporter_info: ReporterInfo;
  patient_info: PatientInfo;
  device_info: DeviceInfo;
  event_description: string;
  event_severity: 'DEATH' | 'LIFE_THREATENING' | 'HOSPITALIZATION' | 'DISABILITY' | 'INTERVENTION' | 'OTHER';
  event_outcome: 'RECOVERED' | 'RECOVERING' | 'NOT_RECOVERED' | 'UNKNOWN' | 'DEATH';
  device_problem: string[];
  clinical_outcome: string[];
  investigation_findings: string;
  corrective_actions: string[];
  preventive_actions: string[];
  regulatory_actions: RegulatoryAction[];
  status: 'UNDER_INVESTIGATION' | 'CLOSED' | 'REQUIRES_FOLLOW_UP';
}

interface ReporterInfo {
  name?: string;
  profession?: string;
  institution?: string;
  contact_info: ContactInfo;
  relationship_to_patient: string;
}

interface PatientInfo {
  age?: number;
  gender?: 'M' | 'F' | 'OTHER';
  weight?: number;
  relevant_medical_history: string;
  concomitant_treatments: string[];
  allergies: string[];
}

interface DeviceInfo {
  lot_number?: string;
  serial_number?: string;
  manufacture_date?: Date;
  expiration_date?: Date;
  implant_date?: Date;
  device_age_at_event?: number;
  device_location?: string;
  device_returned_to_manufacturer: boolean;
  device_evaluated: boolean;
}

interface RegulatoryAction {
  action_type: 'FIELD_SAFETY_NOTICE' | 'RECALL' | 'MARKET_WITHDRAWAL' | 'LABELING_CHANGE' | 'INVESTIGATION';
  action_date: Date;
  action_description: string;
  affected_products: string[];
  geographic_scope: string;
  completion_status: 'INITIATED' | 'IN_PROGRESS' | 'COMPLETED';
}

interface RecallInformation {
  recall_id: string;
  recall_type: 'VOLUNTARY' | 'MANDATORY';
  recall_class: 'I' | 'II' | 'III'; // Class I = most serious
  product_registration: string;
  product_name: string;
  manufacturer_name: string;
  recall_reason: string;
  health_hazard_evaluation: string;
  recall_initiation_date: Date;
  recall_status: 'ONGOING' | 'COMPLETED' | 'TERMINATED';
  affected_lot_numbers: string[];
  distribution_pattern: string;
  quantity_distributed: number;
  quantity_recovered: number;
  effectiveness_checks_conducted: number;
  public_notification_issued: boolean;
  press_release_date?: Date;
  consignee_notifications: number;
  root_cause_analysis: string;
  corrective_actions: string[];
  preventive_actions: string[];
}

export class AnvisaService {
  private httpClient: AxiosInstance;
  private credentials: AnvisaCredentials;
  private accessToken: string | null = null;
  private tokenExpirationTime: number | null = null;
  private baseURL: string;

  constructor(credentials: AnvisaCredentials) {
    this.credentials = credentials;
    this.baseURL = credentials.environment === 'production'
      ? 'https://consultas.anvisa.gov.br/api'
      : 'https://hom-consultas.anvisa.gov.br/api';

    this.httpClient = axios.create({
      baseURL: this.baseURL,
      timeout: 45000,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'NEW-ORTHO-ERP/7.0.0'
      }
    });

    this.setupInterceptors();
    logger.info('ANVISA Service initialized');
  }

  private setupInterceptors(): void {
    this.httpClient.interceptors.request.use(
      async (config) => {
        await this.ensureValidToken();
        if (this.accessToken) {
          config.headers['Authorization'] = `Bearer ${this.accessToken}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    this.httpClient.interceptors.response.use(
      (response) => response,
      async (error) => {
        if (error.response?.status === 401) {
          this.accessToken = null;
          this.tokenExpirationTime = null;
          await this.ensureValidToken();
          return this.httpClient.request(error.config);
        }
        return Promise.reject(error);
      }
    );
  }

  private async ensureValidToken(): Promise<void> {
    if (this.accessToken && this.tokenExpirationTime && Date.now() < this.tokenExpirationTime) {
      return;
    }

    await this.authenticate();
  }

  private async authenticate(): Promise<void> {
    try {
      logger.info('Authenticating with ANVISA...');

      const authData = {
        grant_type: 'client_credentials',
        client_id: this.credentials.client_id,
        client_secret: this.credentials.client_secret,
        scope: 'produtos estabelecimentos eventos recalls'
      };

      const response = await axios.post(`${this.baseURL}/oauth/token`, authData);

      this.accessToken = response.data.access_token;
      this.tokenExpirationTime = Date.now() + (response.data.expires_in * 1000) - 60000;

      await redisClient.setEx(
        `anvisa-token:${this.credentials.client_id}`,
        response.data.expires_in - 60,
        this.accessToken
      );

      logger.info('ANVISA authentication successful');

    } catch (error) {
      logger.error('ANVISA authentication failed:', error);
      throw new Error(`Failed to authenticate with ANVISA: ${error}`);
    }
  }

  /**
   * Busca registro de produto médico
   */
  async getProductRegistry(registrationNumber: string): Promise<MedicalDeviceRegistry> {
    try {
      logger.info(`Fetching ANVISA product registry: ${registrationNumber}`);

      const cacheKey = `anvisa-product:${registrationNumber}`;
      const cached = await redisClient.get(cacheKey);
      if (cached) {
        return JSON.parse(cached);
      }

      const response = await this.httpClient.get(`/produtos/${registrationNumber}`);
      const data = response.data;

      const registry: MedicalDeviceRegistry = {
        registration_number: data.numero_registro,
        product_name: data.nome_produto,
        manufacturer_name: data.nome_fabricante,
        manufacturer_country: data.pais_fabricante,
        regulatory_class: data.classe_regulatoria,
        registration_type: data.tipo_registro,
        registration_status: data.status_registro,
        registration_date: new Date(data.data_registro),
        expiration_date: new Date(data.data_vencimento),
        technical_description: data.descricao_tecnica,
        intended_use: data.finalidade_uso,
        ncm_code: data.codigo_ncm,
        gtin_ean: data.codigo_gtin,
        lot_control_required: data.controle_lote_obrigatorio,
        sterilization_required: data.esterilizacao_obrigatoria,
        single_use: data.uso_unico,
        implantable: data.implantavel,
        life_support: data.suporte_vida,
        contraindications: data.contraindicacoes || [],
        warnings: data.advertencias || [],
        storage_conditions: data.condicoes_armazenamento,
        shelf_life_months: data.prazo_validade_meses,
        registration_holder: this.parseCompanyInfo(data.detentor_registro),
        authorized_representatives: data.representantes_autorizados?.map(this.parseCompanyInfo) || [],
        manufacturing_sites: data.locais_fabricacao?.map(this.parseManufacturingSite) || [],
        clinical_evaluation: this.parseClinicalEvaluation(data.avaliacao_clinica),
        quality_certifications: data.certificacoes_qualidade?.map(this.parseQualityCertification) || [],
        post_market_surveillance: this.parsePostMarketSurveillance(data.vigilancia_pos_comercializacao)
      };

      // Cache for 12 hours
      await redisClient.setEx(cacheKey, 43200, JSON.stringify(registry));

      logger.info(`Product registry fetched successfully: ${registrationNumber}`);
      return registry;

    } catch (error) {
      logger.error(`Failed to fetch product registry ${registrationNumber}:`, error);
      throw error;
    }
  }

  /**
   * Busca múltiplos produtos por critérios
   */
  async searchProducts(criteria: {
    product_name?: string;
    manufacturer?: string;
    ncm_code?: string;
    regulatory_class?: string;
    registration_status?: string;
    limit?: number;
  }): Promise<MedicalDeviceRegistry[]> {
    try {
      logger.info('Searching ANVISA product database');

      const params = {
        nome_produto: criteria.product_name,
        fabricante: criteria.manufacturer,
        codigo_ncm: criteria.ncm_code,
        classe_regulatoria: criteria.regulatory_class,
        status_registro: criteria.registration_status,
        limite: criteria.limit || 50
      };

      const response = await this.httpClient.get('/produtos/busca', { params });
      
      const products = await Promise.all(
        response.data.resultados.map(async (item: any) => {
          return await this.getProductRegistry(item.numero_registro);
        })
      );

      logger.info(`Found ${products.length} products matching criteria`);
      return products;

    } catch (error) {
      logger.error('Failed to search products:', error);
      throw error;
    }
  }

  /**
   * Consulta informações de estabelecimento
   */
  async getEstablishmentInfo(cnpj: string): Promise<EstablishmentInfo> {
    try {
      logger.info(`Fetching establishment info for CNPJ: ${cnpj}`);

      const cacheKey = `anvisa-establishment:${cnpj}`;
      const cached = await redisClient.get(cacheKey);
      if (cached) {
        return JSON.parse(cached);
      }

      const response = await this.httpClient.get(`/estabelecimentos/${cnpj}`);
      const data = response.data;

      const establishment: EstablishmentInfo = {
        cnpj: data.cnpj,
        company_name: data.razao_social,
        fantasy_name: data.nome_fantasia,
        establishment_type: data.tipo_estabelecimento,
        anvisa_authorization: data.autorizacao_anvisa,
        authorization_status: data.status_autorizacao,
        authorization_date: new Date(data.data_autorizacao),
        expiration_date: new Date(data.data_vencimento),
        address: this.parseAddress(data.endereco),
        contact_info: this.parseContactInfo(data.contato),
        responsible_technical: this.parseTechnicalResponsible(data.responsavel_tecnico),
        authorized_activities: data.atividades_autorizadas?.map(this.parseAuthorizedActivity) || [],
        inspection_history: data.historico_inspecoes?.map(this.parseInspectionRecord) || [],
        compliance_status: this.parseComplianceStatus(data.status_conformidade),
        product_categories: data.categorias_produtos || [],
        quality_system: this.parseQualitySystemInfo(data.sistema_qualidade)
      };

      // Cache for 6 hours
      await redisClient.setEx(cacheKey, 21600, JSON.stringify(establishment));

      logger.info(`Establishment info fetched for CNPJ: ${cnpj}`);
      return establishment;

    } catch (error) {
      logger.error(`Failed to fetch establishment info for CNPJ ${cnpj}:`, error);
      throw error;
    }
  }

  /**
   * Consulta eventos adversos
   */
  async getAdverseEvents(criteria: {
    product_registration?: string;
    manufacturer?: string;
    start_date?: Date;
    end_date?: Date;
    severity?: string;
    limit?: number;
  }): Promise<AdverseEventReport[]> {
    try {
      logger.info('Fetching adverse event reports');

      const params = {
        registro_produto: criteria.product_registration,
        fabricante: criteria.manufacturer,
        data_inicio: criteria.start_date?.toISOString().split('T')[0],
        data_fim: criteria.end_date?.toISOString().split('T')[0],
        gravidade: criteria.severity,
        limite: criteria.limit || 100
      };

      const response = await this.httpClient.get('/eventos-adversos', { params });

      const events = response.data.eventos.map((data: any) => ({
        report_id: data.id_relatorio,
        product_registration: data.registro_produto,
        product_name: data.nome_produto,
        manufacturer_name: data.nome_fabricante,
        event_date: new Date(data.data_evento),
        report_date: new Date(data.data_relatorio),
        reporter_type: data.tipo_relator,
        reporter_info: this.parseReporterInfo(data.info_relator),
        patient_info: this.parsePatientInfo(data.info_paciente),
        device_info: this.parseDeviceInfo(data.info_dispositivo),
        event_description: data.descricao_evento,
        event_severity: data.gravidade_evento,
        event_outcome: data.desfecho_evento,
        device_problem: data.problema_dispositivo || [],
        clinical_outcome: data.desfecho_clinico || [],
        investigation_findings: data.achados_investigacao,
        corrective_actions: data.acoes_corretivas || [],
        preventive_actions: data.acoes_preventivas || [],
        regulatory_actions: data.acoes_regulatorias?.map(this.parseRegulatoryAction) || [],
        status: data.status
      }));

      // Cache for 1 hour
      const cacheKey = `anvisa-adverse-events:${this.generateCacheKey(criteria)}`;
      await redisClient.setEx(cacheKey, 3600, JSON.stringify(events));

      logger.info(`Found ${events.length} adverse event reports`);
      return events;

    } catch (error) {
      logger.error('Failed to fetch adverse events:', error);
      throw error;
    }
  }

  /**
   * Consulta recalls ativos
   */
  async getActiveRecalls(product_category?: string): Promise<RecallInformation[]> {
    try {
      logger.info('Fetching active product recalls');

      const params = product_category ? { categoria_produto: product_category } : {};
      const response = await this.httpClient.get('/recalls', { params });

      const recalls = response.data.recalls.map((data: any) => ({
        recall_id: data.id_recall,
        recall_type: data.tipo_recall,
        recall_class: data.classe_recall,
        product_registration: data.registro_produto,
        product_name: data.nome_produto,
        manufacturer_name: data.nome_fabricante,
        recall_reason: data.motivo_recall,
        health_hazard_evaluation: data.avaliacao_risco_saude,
        recall_initiation_date: new Date(data.data_inicio_recall),
        recall_status: data.status_recall,
        affected_lot_numbers: data.lotes_afetados || [],
        distribution_pattern: data.padrao_distribuicao,
        quantity_distributed: data.quantidade_distribuida,
        quantity_recovered: data.quantidade_recuperada,
        effectiveness_checks_conducted: data.verificacoes_efetividade,
        public_notification_issued: data.notificacao_publica_emitida,
        press_release_date: data.data_comunicado ? new Date(data.data_comunicado) : undefined,
        consignee_notifications: data.notificacoes_consignatarios,
        root_cause_analysis: data.analise_causa_raiz,
        corrective_actions: data.acoes_corretivas || [],
        preventive_actions: data.acoes_preventivas || []
      }));

      // Cache for 2 hours
      const cacheKey = `anvisa-recalls:${product_category || 'all'}`;
      await redisClient.setEx(cacheKey, 7200, JSON.stringify(recalls));

      logger.info(`Found ${recalls.length} active recalls`);
      return recalls;

    } catch (error) {
      logger.error('Failed to fetch recalls:', error);
      throw error;
    }
  }

  /**
   * Valida conformidade de produto
   */
  async validateProductCompliance(registrationNumber: string): Promise<{
    compliant: boolean;
    issues: string[];
    warnings: string[];
    recommendations: string[];
    compliance_score: number;
    last_check: Date;
  }> {
    try {
      logger.info(`Validating product compliance: ${registrationNumber}`);

      const [product, recalls, adverseEvents] = await Promise.all([
        this.getProductRegistry(registrationNumber),
        this.getActiveRecalls(),
        this.getAdverseEvents({ product_registration: registrationNumber, limit: 50 })
      ]);

      const issues: string[] = [];
      const warnings: string[] = [];
      const recommendations: string[] = [];
      let complianceScore = 100;

      // Check registration status
      if (product.registration_status !== 'ACTIVE') {
        issues.push(`Product registration is ${product.registration_status}`);
        complianceScore -= 50;
      }

      // Check expiration
      if (product.expiration_date < new Date()) {
        issues.push('Product registration has expired');
        complianceScore -= 40;
      }

      // Check for active recalls
      const productRecalls = recalls.filter(r => 
        r.product_registration === registrationNumber && r.recall_status === 'ONGOING'
      );
      if (productRecalls.length > 0) {
        issues.push(`Product has ${productRecalls.length} active recall(s)`);
        complianceScore -= 30 * productRecalls.length;
      }

      // Analyze adverse events
      if (adverseEvents.length > 10) {
        warnings.push(`High number of adverse events reported: ${adverseEvents.length}`);
        complianceScore -= 10;
      }

      const criticalEvents = adverseEvents.filter(e => 
        e.event_severity === 'DEATH' || e.event_severity === 'LIFE_THREATENING'
      );
      if (criticalEvents.length > 0) {
        warnings.push(`${criticalEvents.length} critical adverse event(s) reported`);
        complianceScore -= 15;
      }

      // Check quality certifications
      const expiredCertifications = product.quality_certifications.filter(c => 
        c.expiry_date < new Date()
      );
      if (expiredCertifications.length > 0) {
        warnings.push(`${expiredCertifications.length} quality certification(s) expired`);
        complianceScore -= 5 * expiredCertifications.length;
      }

      // Generate recommendations
      if (product.expiration_date.getTime() - Date.now() < 90 * 24 * 60 * 60 * 1000) {
        recommendations.push('Product registration expires within 90 days - consider renewal');
      }

      if (product.post_market_surveillance.adverse_events_reported > 20) {
        recommendations.push('Consider enhanced post-market surveillance due to high adverse event count');
      }

      const result = {
        compliant: issues.length === 0,
        issues,
        warnings,
        recommendations,
        compliance_score: Math.max(complianceScore, 0),
        last_check: new Date()
      };

      // Cache for 1 hour
      await redisClient.setEx(
        `anvisa-compliance:${registrationNumber}`,
        3600,
        JSON.stringify(result)
      );

      logger.info(`Product compliance validation completed: ${registrationNumber}`);
      return result;

    } catch (error) {
      logger.error(`Failed to validate product compliance ${registrationNumber}:`, error);
      throw error;
    }
  }

  /**
   * Monitor mudanças regulatórias
   */
  async getRegulartoryUpdates(lastCheckDate?: Date): Promise<any[]> {
    try {
      logger.info('Fetching regulatory updates from ANVISA');

      const params = lastCheckDate ? {
        data_inicio: lastCheckDate.toISOString().split('T')[0]
      } : {};

      const response = await this.httpClient.get('/atualizacoes-regulatorias', { params });
      
      const updates = response.data.atualizacoes || [];

      // Store latest check time
      await redisClient.set('anvisa-last-update-check', new Date().toISOString());

      logger.info(`Found ${updates.length} regulatory updates`);
      return updates;

    } catch (error) {
      logger.error('Failed to fetch regulatory updates:', error);
      throw error;
    }
  }

  // Helper methods for parsing data structures
  private parseCompanyInfo(data: any): CompanyInfo {
    return {
      cnpj: data.cnpj,
      company_name: data.razao_social,
      fantasy_name: data.nome_fantasia,
      address: this.parseAddress(data.endereco),
      contact_info: this.parseContactInfo(data.contato),
      anvisa_authorization: data.autorizacao_anvisa,
      authorization_expiry: new Date(data.vencimento_autorizacao),
      responsible_technical: this.parseTechnicalResponsible(data.responsavel_tecnico)
    };
  }

  private parseAddress(data: any): Address {
    return {
      street: data.logradouro,
      number: data.numero,
      complement: data.complemento,
      neighborhood: data.bairro,
      city: data.cidade,
      state: data.estado,
      zip_code: data.cep,
      country: data.pais
    };
  }

  private parseContactInfo(data: any): ContactInfo {
    return {
      phone: data.telefone,
      email: data.email,
      website: data.website
    };
  }

  private parseTechnicalResponsible(data: any): TechnicalResponsible {
    return {
      name: data.nome,
      profession: data.profissao,
      registration_number: data.numero_registro,
      registration_council: data.conselho_registro
    };
  }

  private parseManufacturingSite(data: any): ManufacturingSite {
    return {
      site_id: data.id_local,
      company_name: data.nome_empresa,
      address: this.parseAddress(data.endereco),
      country: data.pais,
      gmp_certification: data.certificacao_bpf,
      certification_expiry: new Date(data.vencimento_certificacao),
      inspection_status: data.status_inspecao,
      last_inspection_date: new Date(data.data_ultima_inspecao)
    };
  }

  private parseClinicalEvaluation(data: any): ClinicalEvaluation {
    return {
      evaluation_type: data.tipo_avaliacao,
      studies_count: data.quantidade_estudos,
      patients_enrolled: data.pacientes_incluidos,
      primary_endpoint_met: data.desfecho_primario_alcancado,
      safety_profile: data.perfil_seguranca,
      effectiveness_demonstrated: data.eficacia_demonstrada,
      follow_up_required: data.acompanhamento_requerido,
      study_locations: data.locais_estudo || []
    };
  }

  private parseQualityCertification(data: any): QualityCertification {
    return {
      certification_type: data.tipo_certificacao,
      certification_number: data.numero_certificacao,
      certifying_body: data.organismo_certificador,
      issue_date: new Date(data.data_emissao),
      expiry_date: new Date(data.data_vencimento),
      scope: data.escopo,
      status: data.status
    };
  }

  private parsePostMarketSurveillance(data: any): PostMarketSurveillance {
    return {
      surveillance_plan: data.plano_vigilancia,
      periodic_reports_required: data.relatorios_periodicos_requeridos,
      report_frequency_months: data.frequencia_relatorio_meses,
      adverse_events_reported: data.eventos_adversos_reportados,
      field_safety_notices: data.avisos_seguranca_campo,
      recalls_initiated: data.recalls_iniciados,
      effectiveness_confirmed: data.eficacia_confirmada,
      risk_benefit_positive: data.relacao_risco_beneficio_positiva
    };
  }

  private parseAuthorizedActivity(data: any): AuthorizedActivity {
    return {
      activity_code: data.codigo_atividade,
      activity_description: data.descricao_atividade,
      product_classes: data.classes_produtos || [],
      geographical_scope: data.abrangencia_geografica,
      volume_limit: data.limite_volume,
      special_conditions: data.condicoes_especiais || []
    };
  }

  private parseInspectionRecord(data: any): InspectionRecord {
    return {
      inspection_id: data.id_inspecao,
      inspection_date: new Date(data.data_inspecao),
      inspection_type: data.tipo_inspecao,
      inspector_team: data.equipe_inspetores || [],
      findings: data.achados?.map(this.parseInspectionFinding) || [],
      overall_rating: data.classificacao_geral,
      corrective_actions_required: data.acoes_corretivas_requeridas,
      follow_up_date: data.data_acompanhamento ? new Date(data.data_acompanhamento) : undefined,
      reinspection_required: data.reinspecao_requerida
    };
  }

  private parseInspectionFinding(data: any): InspectionFinding {
    return {
      finding_id: data.id_achado,
      regulation_reference: data.referencia_regulamentacao,
      severity: data.gravidade,
      description: data.descricao,
      evidence: data.evidencia,
      corrective_action_required: data.acao_corretiva_requerida,
      response_deadline: new Date(data.prazo_resposta),
      status: data.status
    };
  }

  private parseComplianceStatus(data: any): ComplianceStatus {
    return {
      overall_status: data.status_geral,
      open_violations: data.violacoes_abertas,
      pending_corrective_actions: data.acoes_corretivas_pendentes,
      compliance_score: data.pontuacao_conformidade,
      last_assessment_date: new Date(data.data_ultima_avaliacao),
      next_assessment_due: new Date(data.proxima_avaliacao_devida),
      risk_level: data.nivel_risco
    };
  }

  private parseQualitySystemInfo(data: any): QualitySystemInfo {
    return {
      iso13485_certified: data.certificado_iso13485,
      certification_body: data.organismo_certificacao,
      certificate_number: data.numero_certificado,
      certificate_expiry: new Date(data.vencimento_certificado),
      internal_audit_frequency: data.frequencia_auditoria_interna,
      management_review_frequency: data.frequencia_analise_gestao,
      capa_system_implemented: data.sistema_capa_implementado,
      design_controls_implemented: data.controles_projeto_implementados,
      supplier_controls_implemented: data.controles_fornecedor_implementados
    };
  }

  private parseReporterInfo(data: any): ReporterInfo {
    return {
      name: data.nome,
      profession: data.profissao,
      institution: data.instituicao,
      contact_info: this.parseContactInfo(data.contato),
      relationship_to_patient: data.relacao_paciente
    };
  }

  private parsePatientInfo(data: any): PatientInfo {
    return {
      age: data.idade,
      gender: data.sexo,
      weight: data.peso,
      relevant_medical_history: data.historico_medico_relevante,
      concomitant_treatments: data.tratamentos_concomitantes || [],
      allergies: data.alergias || []
    };
  }

  private parseDeviceInfo(data: any): DeviceInfo {
    return {
      lot_number: data.numero_lote,
      serial_number: data.numero_serie,
      manufacture_date: data.data_fabricacao ? new Date(data.data_fabricacao) : undefined,
      expiration_date: data.data_vencimento ? new Date(data.data_vencimento) : undefined,
      implant_date: data.data_implante ? new Date(data.data_implante) : undefined,
      device_age_at_event: data.idade_dispositivo_evento,
      device_location: data.localizacao_dispositivo,
      device_returned_to_manufacturer: data.dispositivo_devolvido_fabricante,
      device_evaluated: data.dispositivo_avaliado
    };
  }

  private parseRegulatoryAction(data: any): RegulatoryAction {
    return {
      action_type: data.tipo_acao,
      action_date: new Date(data.data_acao),
      action_description: data.descricao_acao,
      affected_products: data.produtos_afetados || [],
      geographic_scope: data.abrangencia_geografica,
      completion_status: data.status_conclusao
    };
  }

  private generateCacheKey(criteria: any): string {
    return crypto.createHash('md5').update(JSON.stringify(criteria)).digest('hex');
  }

  async healthCheck(): Promise<{ status: string; timestamp: Date; response_time: number }> {
    const startTime = Date.now();
    
    try {
      await this.httpClient.get('/health');
      
      return {
        status: 'healthy',
        timestamp: new Date(),
        response_time: Date.now() - startTime
      };

    } catch (error) {
      logger.warn('ANVISA health check failed:', error);
      
      return {
        status: 'unhealthy',
        timestamp: new Date(),
        response_time: Date.now() - startTime
      };
    }
  }
}