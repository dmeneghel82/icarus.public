import axios, { AxiosInstance } from 'axios';
import { logger } from '../utils/logger';
import { redisClient } from '../utils/redis';
import * as crypto from 'crypto';

interface SefazCredentials {
  certificate_path: string;
  private_key_path: string;
  certificate_password: string;
  cnpj: string;
  environment: 'production' | 'homologation';
}

interface ProductPriceQuery {
  product_name: string;
  ncm_code?: string;
  gtin_ean?: string;
  manufacturer?: string;
  specifications?: string;
  target_states: string[]; // UF codes: SP, RJ, MG, etc.
  price_range?: {
    min: number;
    max: number;
  };
  date_range?: {
    start: Date;
    end: Date;
  };
}

interface ProductPriceResult {
  query_id: string;
  product_info: ProductInfo;
  price_data: StatePriceData[];
  market_analysis: MarketAnalysis;
  statistical_summary: StatisticalSummary;
  confidence_score: number;
  data_freshness: number; // days old
  sources_count: number;
}

interface ProductInfo {
  product_name: string;
  ncm_code: string;
  gtin_ean?: string;
  standardized_description: string;
  category: string;
  subcategory: string;
  manufacturer?: string;
  technical_specs?: string;
}

interface StatePriceData {
  state: string;
  state_name: string;
  prices: PriceEntry[];
  market_share: number; // percentage of total transactions
  average_price: number;
  median_price: number;
  price_variance: number;
  transaction_count: number;
  last_updated: Date;
  market_trend: 'RISING' | 'FALLING' | 'STABLE';
}

interface PriceEntry {
  seller_cnpj: string;
  seller_name?: string;
  city: string;
  unit_price: number;
  quantity: number;
  transaction_date: Date;
  nfe_key: string;
  cfop: string;
  icms_rate: number;
  ipi_rate: number;
  verification_status: 'VERIFIED' | 'PENDING' | 'FLAGGED';
}

interface MarketAnalysis {
  national_average: number;
  regional_averages: {
    north: number;
    northeast: number;
    southeast: number;
    south: number;
    central_west: number;
  };
  price_dispersion: number;
  outlier_count: number;
  market_concentration: number; // HHI index
  competitive_landscape: CompetitorAnalysis[];
}

interface CompetitorAnalysis {
  competitor_id: string;
  market_share: number;
  average_price: number;
  price_positioning: 'PREMIUM' | 'MAINSTREAM' | 'ECONOMY';
  geographic_coverage: string[];
  volume_trend: 'GROWING' | 'STABLE' | 'DECLINING';
}

interface StatisticalSummary {
  total_transactions: number;
  price_statistics: {
    min: number;
    max: number;
    mean: number;
    median: number;
    std_deviation: number;
    percentiles: {
      p25: number;
      p75: number;
      p90: number;
      p95: number;
    };
  };
  temporal_analysis: {
    price_trend: 'RISING' | 'FALLING' | 'STABLE';
    trend_strength: number; // -1 to 1
    seasonality_detected: boolean;
    seasonal_pattern?: string;
  };
  quality_metrics: {
    data_completeness: number; // percentage
    price_accuracy_score: number;
    outlier_percentage: number;
  };
}

interface NFSeQuery {
  cnpj_issuer?: string;
  cnpj_recipient?: string;
  service_code: string;
  start_date: Date;
  end_date: Date;
  city_code?: string;
  min_value?: number;
  max_value?: number;
}

interface NFSeResult {
  nfse_number: string;
  issuer_cnpj: string;
  issuer_name: string;
  recipient_cnpj: string;
  recipient_name: string;
  service_description: string;
  service_code: string;
  issue_date: Date;
  total_value: number;
  tax_values: {
    iss: number;
    pis: number;
    cofins: number;
    inss: number;
    ir: number;
  };
  city_code: string;
  verification_code: string;
}

interface TaxRegimeInfo {
  cnpj: string;
  company_name: string;
  tax_regime: 'SIMPLES' | 'LUCRO_PRESUMIDO' | 'LUCRO_REAL';
  mei_status: boolean;
  state_registration: string;
  municipal_registration?: string;
  activity_codes: string[]; // CNAE codes
  tax_rates: {
    icms_rate: number;
    iss_rate: number;
    pis_rate: number;
    cofins_rate: number;
  };
  compliance_status: 'REGULAR' | 'IRREGULAR' | 'SUSPENDED';
  last_updated: Date;
}

export class SefazService {
  private httpClients: Map<string, AxiosInstance> = new Map();
  private credentials: SefazCredentials;
  private stateEndpoints: Map<string, string> = new Map();

  constructor(credentials: SefazCredentials) {
    this.credentials = credentials;
    this.initializeStateEndpoints();
    this.setupHttpClients();
    logger.info('SEFAZ Service initialized for multi-state operations');
  }

  private initializeStateEndpoints(): void {
    const baseUrl = this.credentials.environment === 'production' 
      ? 'https://nfe.sefaz' 
      : 'https://homologacao.nfe.sefaz';

    // Major states endpoints
    this.stateEndpoints.set('SP', `${baseUrl}.sp.gov.br/ws`);
    this.stateEndpoints.set('RJ', `${baseUrl}.rj.gov.br/ws`);
    this.stateEndpoints.set('MG', `${baseUrl}.mg.gov.br/ws`);
    this.stateEndpoints.set('RS', `${baseUrl}.rs.gov.br/ws`);
    this.stateEndpoints.set('PR', `${baseUrl}.pr.gov.br/ws`);
    this.stateEndpoints.set('SC', `${baseUrl}.sc.gov.br/ws`);
    this.stateEndpoints.set('BA', `${baseUrl}.ba.gov.br/ws`);
    this.stateEndpoints.set('GO', `${baseUrl}.go.gov.br/ws`);
    this.stateEndpoints.set('PE', `${baseUrl}.pe.gov.br/ws`);
    this.stateEndpoints.set('CE', `${baseUrl}.ce.gov.br/ws`);
    this.stateEndpoints.set('DF', `${baseUrl}.df.gov.br/ws`);
    this.stateEndpoints.set('ES', `${baseUrl}.es.gov.br/ws`);
    this.stateEndpoints.set('PB', `${baseUrl}.pb.gov.br/ws`);
    this.stateEndpoints.set('RN', `${baseUrl}.rn.gov.br/ws`);
    this.stateEndpoints.set('AL', `${baseUrl}.al.gov.br/ws`);
    this.stateEndpoints.set('SE', `${baseUrl}.se.gov.br/ws`);
    this.stateEndpoints.set('MT', `${baseUrl}.mt.gov.br/ws`);
    this.stateEndpoints.set('MS', `${baseUrl}.ms.gov.br/ws`);
    this.stateEndpoints.set('TO', `${baseUrl}.to.gov.br/ws`);
    this.stateEndpoints.set('MA', `${baseUrl}.ma.gov.br/ws`);
    this.stateEndpoints.set('PI', `${baseUrl}.pi.gov.br/ws`);
    this.stateEndpoints.set('AC', `${baseUrl}.ac.gov.br/ws`);
    this.stateEndpoints.set('AP', `${baseUrl}.ap.gov.br/ws`);
    this.stateEndpoints.set('AM', `${baseUrl}.am.gov.br/ws`);
    this.stateEndpoints.set('RO', `${baseUrl}.ro.gov.br/ws`);
    this.stateEndpoints.set('RR', `${baseUrl}.rr.gov.br/ws`);
    this.stateEndpoints.set('PA', `${baseUrl}.pa.gov.br/ws`);
  }

  private setupHttpClients(): void {
    for (const [state, endpoint] of this.stateEndpoints) {
      const client = axios.create({
        baseURL: endpoint,
        timeout: 30000,
        headers: {
          'Content-Type': 'application/soap+xml',
          'Accept': 'application/soap+xml'
        }
      });

      // Add certificate authentication
      // In production, would configure SSL certificates here

      this.httpClients.set(state, client);
    }
  }

  /**
   * Pesquisa preços de produtos em múltiplos estados
   */
  async searchProductPrices(query: ProductPriceQuery): Promise<ProductPriceResult> {
    try {
      const queryId = this.generateQueryId(query);
      logger.info(`Starting multi-state price research for query: ${queryId}`);

      // Check cache first
      const cacheKey = `sefaz-price-query:${queryId}`;
      const cached = await redisClient.get(cacheKey);
      if (cached) {
        logger.info(`Returning cached result for query: ${queryId}`);
        return JSON.parse(cached);
      }

      // Execute parallel queries across states
      const statePromises = query.target_states.map(state => 
        this.searchPricesInState(state, query)
      );

      const stateResults = await Promise.allSettled(statePromises);
      const validResults = stateResults
        .filter((result): result is PromiseFulfilledResult<StatePriceData> => 
          result.status === 'fulfilled' && result.value !== null)
        .map(result => result.value);

      if (validResults.length === 0) {
        throw new Error('No price data found in any of the specified states');
      }

      // Standardize product info from best result
      const productInfo = this.extractProductInfo(query, validResults);

      // Perform market analysis
      const marketAnalysis = this.analyzeMarket(validResults);
      const statisticalSummary = this.calculateStatistics(validResults);

      const result: ProductPriceResult = {
        query_id: queryId,
        product_info: productInfo,
        price_data: validResults,
        market_analysis: marketAnalysis,
        statistical_summary: statisticalSummary,
        confidence_score: this.calculateConfidenceScore(validResults),
        data_freshness: this.calculateDataFreshness(validResults),
        sources_count: validResults.reduce((sum, state) => sum + state.transaction_count, 0)
      };

      // Cache result for 4 hours
      await redisClient.setEx(cacheKey, 14400, JSON.stringify(result));

      logger.info(`Multi-state price research completed for query: ${queryId}`);
      return result;

    } catch (error) {
      logger.error('Multi-state price research failed:', error);
      throw error;
    }
  }

  private async searchPricesInState(state: string, query: ProductPriceQuery): Promise<StatePriceData | null> {
    try {
      const client = this.httpClients.get(state);
      if (!client) {
        logger.warn(`No HTTP client configured for state: ${state}`);
        return null;
      }

      // Build SOAP query for NFe consultation
      const soapQuery = this.buildNFeConsultationSOAP(query, state);
      
      const response = await client.post('/nfeConsultaDest', soapQuery);
      
      // Parse SOAP response
      const nfeData = this.parseNFeResponse(response.data);
      
      if (!nfeData || nfeData.length === 0) {
        return null;
      }

      // Process and normalize price data
      const prices = this.processNFeData(nfeData, query);
      
      if (prices.length === 0) {
        return null;
      }

      // Calculate state-level statistics
      const averagePrice = prices.reduce((sum, p) => sum + p.unit_price, 0) / prices.length;
      const sortedPrices = prices.map(p => p.unit_price).sort((a, b) => a - b);
      const medianPrice = sortedPrices[Math.floor(sortedPrices.length / 2)];
      const priceVariance = this.calculateVariance(sortedPrices);

      return {
        state,
        state_name: this.getStateName(state),
        prices,
        market_share: this.calculateMarketShare(prices, state),
        average_price: averagePrice,
        median_price: medianPrice,
        price_variance: priceVariance,
        transaction_count: prices.length,
        last_updated: new Date(),
        market_trend: this.analyzePriceTrend(prices)
      };

    } catch (error) {
      logger.warn(`Failed to fetch price data for state ${state}:`, error);
      return null;
    }
  }

  private buildNFeConsultationSOAP(query: ProductPriceQuery, state: string): string {
    const startDate = query.date_range?.start || new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
    const endDate = query.date_range?.end || new Date();

    return `<?xml version="1.0" encoding="UTF-8"?>
    <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
      <soap:Header/>
      <soap:Body>
        <nfeConsultaDest xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeConsultaDest">
          <nfeDadosMsg>
            <consNFeDest xmlns="http://www.portalfiscal.inf.br/nfe">
              <tpAmb>2</tpAmb>
              <xServ>CONSULTAR NFE DEST</xServ>
              <CNPJ>${this.credentials.cnpj}</CNPJ>
              <indNFe>0</indNFe>
              <indEmi>1</indEmi>
              <cUF>${this.getStateCode(state)}</cUF>
              <dhIni>${startDate.toISOString()}</dhIni>
              <dhFim>${endDate.toISOString()}</dhFim>
              ${query.ncm_code ? `<NCM>${query.ncm_code}</NCM>` : ''}
              ${query.product_name ? `<xProd>${query.product_name}</xProd>` : ''}
            </consNFeDest>
          </nfeDadosMsg>
        </nfeConsultaDest>
      </soap:Body>
    </soap:Envelope>`;
  }

  private parseNFeResponse(soapResponse: string): any[] {
    // Simplified SOAP parsing - in production would use proper XML parser
    try {
      // Extract NFe data from SOAP response
      const nfeMatches = soapResponse.match(/<infNFe[^>]*>[\s\S]*?<\/infNFe>/g);
      
      if (!nfeMatches) {
        return [];
      }

      return nfeMatches.map(nfeXml => {
        // Extract key fields
        const id = this.extractXmlValue(nfeXml, 'Id');
        const emit = this.extractXmlValue(nfeXml, 'emit');
        const dest = this.extractXmlValue(nfeXml, 'dest');
        const det = this.extractXmlValue(nfeXml, 'det');
        
        return {
          id,
          emit,
          dest,
          det,
          rawXml: nfeXml
        };
      });

    } catch (error) {
      logger.warn('Failed to parse NFe SOAP response:', error);
      return [];
    }
  }

  private processNFeData(nfeData: any[], query: ProductPriceQuery): PriceEntry[] {
    const prices: PriceEntry[] = [];

    for (const nfe of nfeData) {
      try {
        // Extract price information from NFe items
        const items = this.extractNFeItems(nfe);
        
        for (const item of items) {
          // Match product based on query criteria
          if (this.matchesProductCriteria(item, query)) {
            prices.push({
              seller_cnpj: item.seller_cnpj,
              seller_name: item.seller_name,
              city: item.city,
              unit_price: item.unit_price,
              quantity: item.quantity,
              transaction_date: new Date(item.transaction_date),
              nfe_key: nfe.id,
              cfop: item.cfop,
              icms_rate: item.icms_rate,
              ipi_rate: item.ipi_rate,
              verification_status: 'VERIFIED'
            });
          }
        }

      } catch (error) {
        logger.warn('Failed to process NFe data:', error);
        continue;
      }
    }

    return prices;
  }

  private extractNFeItems(nfe: any): any[] {
    // Simplified item extraction - would use proper XML parsing in production
    return [{
      seller_cnpj: '12345678901234',
      seller_name: 'Sample Seller',
      city: 'São Paulo',
      unit_price: 100.00 + Math.random() * 50,
      quantity: Math.floor(Math.random() * 10) + 1,
      transaction_date: new Date().toISOString(),
      cfop: '5101',
      icms_rate: 18,
      ipi_rate: 5
    }];
  }

  private matchesProductCriteria(item: any, query: ProductPriceQuery): boolean {
    // Implement product matching logic
    // This would include NCM code matching, product name similarity, etc.
    return true; // Simplified for example
  }

  private analyzeMarket(stateResults: StatePriceData[]): MarketAnalysis {
    const allPrices = stateResults.flatMap(state => state.prices.map(p => p.unit_price));
    const nationalAverage = allPrices.reduce((sum, price) => sum + price, 0) / allPrices.length;

    // Calculate regional averages
    const regionalAverages = {
      north: this.calculateRegionalAverage(stateResults, ['AC', 'AP', 'AM', 'PA', 'RO', 'RR', 'TO']),
      northeast: this.calculateRegionalAverage(stateResults, ['AL', 'BA', 'CE', 'MA', 'PB', 'PE', 'PI', 'RN', 'SE']),
      southeast: this.calculateRegionalAverage(stateResults, ['ES', 'MG', 'RJ', 'SP']),
      south: this.calculateRegionalAverage(stateResults, ['PR', 'RS', 'SC']),
      central_west: this.calculateRegionalAverage(stateResults, ['DF', 'GO', 'MT', 'MS'])
    };

    // Calculate price dispersion
    const priceDispersion = this.calculatePriceDispersion(allPrices, nationalAverage);

    // Detect outliers
    const outlierCount = this.countPriceOutliers(allPrices);

    // Calculate market concentration (simplified HHI)
    const marketConcentration = this.calculateMarketConcentration(stateResults);

    // Analyze competitors
    const competitorAnalysis = this.analyzeCompetitors(stateResults);

    return {
      national_average: nationalAverage,
      regional_averages: regionalAverages,
      price_dispersion: priceDispersion,
      outlier_count: outlierCount,
      market_concentration: marketConcentration,
      competitive_landscape: competitorAnalysis
    };
  }

  private calculateStatistics(stateResults: StatePriceData[]): StatisticalSummary {
    const allPrices = stateResults.flatMap(state => state.prices.map(p => p.unit_price));
    const totalTransactions = stateResults.reduce((sum, state) => sum + state.transaction_count, 0);

    // Sort prices for percentile calculations
    const sortedPrices = [...allPrices].sort((a, b) => a - b);

    const mean = allPrices.reduce((sum, price) => sum + price, 0) / allPrices.length;
    const median = sortedPrices[Math.floor(sortedPrices.length / 2)];
    const stdDeviation = Math.sqrt(
      allPrices.reduce((sum, price) => sum + Math.pow(price - mean, 2), 0) / allPrices.length
    );

    const percentiles = {
      p25: sortedPrices[Math.floor(sortedPrices.length * 0.25)],
      p75: sortedPrices[Math.floor(sortedPrices.length * 0.75)],
      p90: sortedPrices[Math.floor(sortedPrices.length * 0.90)],
      p95: sortedPrices[Math.floor(sortedPrices.length * 0.95)]
    };

    // Analyze temporal trends
    const temporalAnalysis = this.analyzeTemporalTrends(stateResults);

    // Calculate quality metrics
    const qualityMetrics = this.calculateQualityMetrics(stateResults);

    return {
      total_transactions: totalTransactions,
      price_statistics: {
        min: Math.min(...allPrices),
        max: Math.max(...allPrices),
        mean,
        median,
        std_deviation: stdDeviation,
        percentiles
      },
      temporal_analysis: temporalAnalysis,
      quality_metrics: qualityMetrics
    };
  }

  /**
   * Consulta NFSe por critérios
   */
  async searchNFSe(query: NFSeQuery): Promise<NFSeResult[]> {
    try {
      logger.info('Searching NFSe documents');

      const results: NFSeResult[] = [];

      // In production, would query actual NFSe databases
      // This is a simplified implementation
      for (let i = 0; i < 10; i++) {
        results.push({
          nfse_number: `${Math.floor(Math.random() * 1000000)}`,
          issuer_cnpj: '12345678901234',
          issuer_name: 'Service Provider',
          recipient_cnpj: this.credentials.cnpj,
          recipient_name: 'Recipient Company',
          service_description: 'Medical consulting services',
          service_code: query.service_code,
          issue_date: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
          total_value: 100 + Math.random() * 900,
          tax_values: {
            iss: 5.0,
            pis: 0.65,
            cofins: 3.0,
            inss: 11.0,
            ir: 1.5
          },
          city_code: '3550308', // São Paulo
          verification_code: Math.random().toString(36).substr(2, 9).toUpperCase()
        });
      }

      logger.info(`Found ${results.length} NFSe documents`);
      return results;

    } catch (error) {
      logger.error('Failed to search NFSe documents:', error);
      throw error;
    }
  }

  /**
   * Consulta informações do regime tributário
   */
  async getTaxRegimeInfo(cnpj: string): Promise<TaxRegimeInfo> {
    try {
      logger.info(`Fetching tax regime info for CNPJ: ${cnpj}`);

      // Check cache first
      const cacheKey = `sefaz-tax-regime:${cnpj}`;
      const cached = await redisClient.get(cacheKey);
      if (cached) {
        return JSON.parse(cached);
      }

      // In production, would integrate with actual SEFAZ APIs
      const taxInfo: TaxRegimeInfo = {
        cnpj,
        company_name: 'Sample Company LTDA',
        tax_regime: 'LUCRO_PRESUMIDO',
        mei_status: false,
        state_registration: '123456789',
        municipal_registration: '987654321',
        activity_codes: ['4644301', '4645101'],
        tax_rates: {
          icms_rate: 18.0,
          iss_rate: 5.0,
          pis_rate: 0.65,
          cofins_rate: 3.0
        },
        compliance_status: 'REGULAR',
        last_updated: new Date()
      };

      // Cache for 24 hours
      await redisClient.setEx(cacheKey, 86400, JSON.stringify(taxInfo));

      logger.info(`Tax regime info fetched for CNPJ: ${cnpj}`);
      return taxInfo;

    } catch (error) {
      logger.error(`Failed to fetch tax regime info for CNPJ ${cnpj}:`, error);
      throw error;
    }
  }

  // Helper methods
  private generateQueryId(query: ProductPriceQuery): string {
    const data = JSON.stringify(query);
    return crypto.createHash('md5').update(data).digest('hex');
  }

  private extractProductInfo(query: ProductPriceQuery, results: StatePriceData[]): ProductInfo {
    return {
      product_name: query.product_name,
      ncm_code: query.ncm_code || '',
      gtin_ean: query.gtin_ean,
      standardized_description: query.product_name,
      category: 'Medical Devices',
      subcategory: 'OPME',
      manufacturer: query.manufacturer,
      technical_specs: query.specifications
    };
  }

  private calculateConfidenceScore(results: StatePriceData[]): number {
    const totalTransactions = results.reduce((sum, state) => sum + state.transaction_count, 0);
    const statesCovered = results.length;
    
    // Base confidence on number of transactions and geographic coverage
    const transactionScore = Math.min(totalTransactions / 100, 1.0);
    const coverageScore = Math.min(statesCovered / 5, 1.0);
    
    return (transactionScore * 0.7 + coverageScore * 0.3) * 100;
  }

  private calculateDataFreshness(results: StatePriceData[]): number {
    const now = Date.now();
    const avgAge = results.reduce((sum, state) => {
      const stateAvgAge = state.prices.reduce((s, price) => 
        s + (now - price.transaction_date.getTime()), 0) / state.prices.length;
      return sum + stateAvgAge;
    }, 0) / results.length;

    return avgAge / (1000 * 60 * 60 * 24); // Convert to days
  }

  private calculateVariance(prices: number[]): number {
    const mean = prices.reduce((sum, price) => sum + price, 0) / prices.length;
    return prices.reduce((sum, price) => sum + Math.pow(price - mean, 2), 0) / prices.length;
  }

  private analyzePriceTrend(prices: PriceEntry[]): 'RISING' | 'FALLING' | 'STABLE' {
    if (prices.length < 2) return 'STABLE';

    const sortedByDate = prices.sort((a, b) => a.transaction_date.getTime() - b.transaction_date.getTime());
    const firstHalf = sortedByDate.slice(0, Math.floor(sortedByDate.length / 2));
    const secondHalf = sortedByDate.slice(Math.floor(sortedByDate.length / 2));

    const firstAvg = firstHalf.reduce((sum, p) => sum + p.unit_price, 0) / firstHalf.length;
    const secondAvg = secondHalf.reduce((sum, p) => sum + p.unit_price, 0) / secondHalf.length;

    const change = (secondAvg - firstAvg) / firstAvg;

    if (change > 0.05) return 'RISING';
    if (change < -0.05) return 'FALLING';
    return 'STABLE';
  }

  private getStateName(code: string): string {
    const stateNames = {
      'SP': 'São Paulo', 'RJ': 'Rio de Janeiro', 'MG': 'Minas Gerais',
      'RS': 'Rio Grande do Sul', 'PR': 'Paraná', 'SC': 'Santa Catarina',
      'BA': 'Bahia', 'GO': 'Goiás', 'PE': 'Pernambuco', 'CE': 'Ceará',
      'DF': 'Distrito Federal', 'ES': 'Espírito Santo', 'PB': 'Paraíba',
      'RN': 'Rio Grande do Norte', 'AL': 'Alagoas', 'SE': 'Sergipe',
      'MT': 'Mato Grosso', 'MS': 'Mato Grosso do Sul', 'TO': 'Tocantins',
      'MA': 'Maranhão', 'PI': 'Piauí', 'AC': 'Acre', 'AP': 'Amapá',
      'AM': 'Amazonas', 'RO': 'Rondônia', 'RR': 'Roraima', 'PA': 'Pará'
    };
    return stateNames[code as keyof typeof stateNames] || code;
  }

  private getStateCode(state: string): string {
    const stateCodes = {
      'SP': '35', 'RJ': '33', 'MG': '31', 'RS': '43', 'PR': '41', 'SC': '42',
      'BA': '29', 'GO': '52', 'PE': '26', 'CE': '23', 'DF': '53', 'ES': '32'
    };
    return stateCodes[state as keyof typeof stateCodes] || '35';
  }

  private extractXmlValue(xml: string, tag: string): string {
    const regex = new RegExp(`<${tag}[^>]*>([^<]*)</${tag}>`, 'i');
    const match = xml.match(regex);
    return match ? match[1] : '';
  }

  private calculateMarketShare(prices: PriceEntry[], state: string): number {
    // Simplified market share calculation
    return Math.random() * 30 + 5; // 5-35%
  }

  private calculateRegionalAverage(states: StatePriceData[], regionStates: string[]): number {
    const regionResults = states.filter(s => regionStates.includes(s.state));
    if (regionResults.length === 0) return 0;
    
    return regionResults.reduce((sum, s) => sum + s.average_price, 0) / regionResults.length;
  }

  private calculatePriceDispersion(prices: number[], average: number): number {
    const variance = prices.reduce((sum, price) => sum + Math.pow(price - average, 2), 0) / prices.length;
    return Math.sqrt(variance) / average; // Coefficient of variation
  }

  private countPriceOutliers(prices: number[]): number {
    const sorted = [...prices].sort((a, b) => a - b);
    const q1 = sorted[Math.floor(sorted.length * 0.25)];
    const q3 = sorted[Math.floor(sorted.length * 0.75)];
    const iqr = q3 - q1;
    const lowerBound = q1 - 1.5 * iqr;
    const upperBound = q3 + 1.5 * iqr;
    
    return prices.filter(price => price < lowerBound || price > upperBound).length;
  }

  private calculateMarketConcentration(states: StatePriceData[]): number {
    // Simplified HHI calculation
    const marketShares = states.map(s => s.market_share / 100);
    return marketShares.reduce((sum, share) => sum + Math.pow(share, 2), 0) * 10000;
  }

  private analyzeCompetitors(states: StatePriceData[]): CompetitorAnalysis[] {
    // Simplified competitor analysis
    return [
      {
        competitor_id: 'COMP001',
        market_share: 25.5,
        average_price: 150.00,
        price_positioning: 'MAINSTREAM',
        geographic_coverage: ['SP', 'RJ', 'MG'],
        volume_trend: 'GROWING'
      }
    ];
  }

  private analyzeTemporalTrends(states: StatePriceData[]): any {
    const trends = states.map(s => s.market_trend);
    const risingCount = trends.filter(t => t === 'RISING').length;
    const fallingCount = trends.filter(t => t === 'FALLING').length;
    
    let overallTrend: 'RISING' | 'FALLING' | 'STABLE';
    if (risingCount > fallingCount * 1.5) {
      overallTrend = 'RISING';
    } else if (fallingCount > risingCount * 1.5) {
      overallTrend = 'FALLING';
    } else {
      overallTrend = 'STABLE';
    }

    return {
      price_trend: overallTrend,
      trend_strength: Math.abs(risingCount - fallingCount) / states.length,
      seasonality_detected: false,
      seasonal_pattern: undefined
    };
  }

  private calculateQualityMetrics(states: StatePriceData[]): any {
    const totalTransactions = states.reduce((sum, s) => sum + s.transaction_count, 0);
    const verifiedTransactions = states.reduce((sum, s) => 
      sum + s.prices.filter(p => p.verification_status === 'VERIFIED').length, 0);

    return {
      data_completeness: (verifiedTransactions / totalTransactions) * 100,
      price_accuracy_score: 85.5, // Would be calculated based on cross-validation
      outlier_percentage: 5.2 // Would be calculated from actual outlier detection
    };
  }
}