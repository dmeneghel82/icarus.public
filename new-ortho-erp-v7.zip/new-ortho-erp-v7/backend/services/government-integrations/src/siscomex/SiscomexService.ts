import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import { logger } from '../utils/logger';
import { redisClient } from '../utils/redis';
import * as https from 'https';

interface SiscomexCredentials {
  client_id: string;
  client_secret: string;
  cpf_cnpj: string;
  certificate_path: string;
  private_key_path: string;
  environment: 'production' | 'homologation';
}

interface ImportDeclaration {
  di_number: string;
  declarant_cnpj: string;
  import_date: Date;
  items: ImportItem[];
  total_value_usd: number;
  freight_value: number;
  insurance_value: number;
  customs_value: number;
  status: 'REGISTERED' | 'CLEARED' | 'INSPECTED' | 'RELEASED';
  clearance_channel: 'GREEN' | 'YELLOW' | 'RED' | 'GRAY';
}

interface ImportItem {
  item_number: number;
  ncm_code: string;
  product_description: string;
  quantity: number;
  unit_of_measure: string;
  unit_value_usd: number;
  total_value_usd: number;
  origin_country: string;
  manufacturer: string;
  anvisa_registry?: string;
  medical_device_class?: string;
  lot_number?: string;
  expiry_date?: Date;
}

interface ExportDeclaration {
  due_number: string;
  exporter_cnpj: string;
  export_date: Date;
  items: ExportItem[];
  total_value_usd: number;
  destination_country: string;
  shipping_terms: 'FOB' | 'CIF' | 'EXW' | 'DDP';
  status: 'REGISTERED' | 'TRANSMITTED' | 'CLEARED' | 'SHIPPED';
}

interface ExportItem {
  item_number: number;
  ncm_code: string;
  product_description: string;
  quantity: number;
  unit_of_measure: string;
  unit_value_usd: number;
  total_value_usd: number;
  anvisa_export_license?: string;
}

interface NCMClassification {
  ncm_code: string;
  description: string;
  import_tax_rate: number;
  ipi_rate: number;
  pis_rate: number;
  cofins_rate: number;
  antidumping_applicable: boolean;
  import_license_required: boolean;
  restrictions: string[];
}

interface CustomsStatus {
  di_number?: string;
  due_number?: string;
  current_status: string;
  status_date: Date;
  location: string;
  next_steps: string[];
  estimated_release_date?: Date;
  inspection_required: boolean;
  documents_pending: string[];
}

interface TradingPartner {
  cnpj: string;
  company_name: string;
  country: string;
  habilitation_status: 'ACTIVE' | 'SUSPENDED' | 'CANCELLED';
  certifications: string[];
  last_transaction_date: Date;
}

export class SiscomexService {
  private httpClient: AxiosInstance;
  private credentials: SiscomexCredentials;
  private accessToken: string | null = null;
  private tokenExpirationTime: number | null = null;
  private baseURL: string;

  constructor(credentials: SiscomexCredentials) {
    this.credentials = credentials;
    this.baseURL = credentials.environment === 'production' 
      ? 'https://val.portalunico.siscomex.gov.br/portal-api'
      : 'https://hom-val.portalunico.siscomex.gov.br/portal-api';

    // Configure HTTPS agent with certificates
    const httpsAgent = new https.Agent({
      cert: credentials.certificate_path,
      key: credentials.private_key_path,
      rejectUnauthorized: true
    });

    this.httpClient = axios.create({
      baseURL: this.baseURL,
      httpsAgent,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    this.setupInterceptors();
    logger.info('SISCOMEX Service initialized');
  }

  private setupInterceptors(): void {
    // Request interceptor to add authentication
    this.httpClient.interceptors.request.use(
      async (config) => {
        await this.ensureValidToken();
        if (this.accessToken) {
          config.headers['Authorization'] = `Bearer ${this.accessToken}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor for error handling
    this.httpClient.interceptors.response.use(
      (response) => response,
      async (error) => {
        if (error.response?.status === 401) {
          // Token expired, refresh and retry
          this.accessToken = null;
          this.tokenExpirationTime = null;
          await this.ensureValidToken();
          return this.httpClient.request(error.config);
        }
        return Promise.reject(error);
      }
    );
  }

  private async ensureValidToken(): Promise<void> {
    if (this.accessToken && this.tokenExpirationTime && Date.now() < this.tokenExpirationTime) {
      return; // Token still valid
    }

    await this.authenticate();
  }

  private async authenticate(): Promise<void> {
    try {
      logger.info('Authenticating with SISCOMEX...');

      const authData = {
        grant_type: 'client_credentials',
        client_id: this.credentials.client_id,
        client_secret: this.credentials.client_secret,
        scope: 'importacao exportacao classificacao'
      };

      const response = await axios.post(`${this.baseURL}/oauth/token`, authData, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });

      this.accessToken = response.data.access_token;
      this.tokenExpirationTime = Date.now() + (response.data.expires_in * 1000) - 60000; // 1 min buffer

      // Cache token in Redis
      await redisClient.setEx(
        `siscomex-token:${this.credentials.client_id}`,
        response.data.expires_in - 60,
        this.accessToken
      );

      logger.info('SISCOMEX authentication successful');

    } catch (error) {
      logger.error('SISCOMEX authentication failed:', error);
      throw new Error(`Failed to authenticate with SISCOMEX: ${error}`);
    }
  }

  /**
   * Consulta declaração de importação
   */
  async getImportDeclaration(diNumber: string): Promise<ImportDeclaration> {
    try {
      logger.info(`Fetching import declaration: ${diNumber}`);

      const response = await this.httpClient.get(`/importacao/declaracoes/${diNumber}`);
      const data = response.data;

      const declaration: ImportDeclaration = {
        di_number: data.numero_di,
        declarant_cnpj: data.cnpj_declarante,
        import_date: new Date(data.data_registro),
        items: data.itens.map((item: any) => ({
          item_number: item.numero_item,
          ncm_code: item.codigo_ncm,
          product_description: item.descricao_mercadoria,
          quantity: item.quantidade,
          unit_of_measure: item.unidade_medida,
          unit_value_usd: item.valor_unitario_usd,
          total_value_usd: item.valor_total_usd,
          origin_country: item.pais_origem,
          manufacturer: item.fabricante,
          anvisa_registry: item.registro_anvisa,
          medical_device_class: item.classe_dispositivo_medico,
          lot_number: item.numero_lote,
          expiry_date: item.data_validade ? new Date(item.data_validade) : undefined
        })),
        total_value_usd: data.valor_total_usd,
        freight_value: data.valor_frete,
        insurance_value: data.valor_seguro,
        customs_value: data.valor_aduaneiro,
        status: data.status,
        clearance_channel: data.canal_parametrizacao
      };

      // Cache result
      await redisClient.setEx(
        `siscomex-di:${diNumber}`,
        3600,
        JSON.stringify(declaration)
      );

      logger.info(`Import declaration fetched successfully: ${diNumber}`);
      return declaration;

    } catch (error) {
      logger.error(`Failed to fetch import declaration ${diNumber}:`, error);
      throw error;
    }
  }

  /**
   * Lista declarações de importação por período
   */
  async getImportDeclarations(
    startDate: Date, 
    endDate: Date,
    cnpj?: string
  ): Promise<ImportDeclaration[]> {
    try {
      logger.info(`Fetching import declarations from ${startDate} to ${endDate}`);

      const params = {
        data_inicio: startDate.toISOString().split('T')[0],
        data_fim: endDate.toISOString().split('T')[0],
        ...(cnpj && { cnpj_declarante: cnpj })
      };

      const response = await this.httpClient.get('/importacao/declaracoes', { params });
      
      const declarations = response.data.declaracoes.map((data: any) => ({
        di_number: data.numero_di,
        declarant_cnpj: data.cnpj_declarante,
        import_date: new Date(data.data_registro),
        items: [], // Summary view, full details require individual calls
        total_value_usd: data.valor_total_usd,
        freight_value: 0,
        insurance_value: 0,
        customs_value: data.valor_aduaneiro,
        status: data.status,
        clearance_channel: data.canal_parametrizacao
      }));

      logger.info(`Found ${declarations.length} import declarations`);
      return declarations;

    } catch (error) {
      logger.error('Failed to fetch import declarations:', error);
      throw error;
    }
  }

  /**
   * Consulta declaração de exportação
   */
  async getExportDeclaration(dueNumber: string): Promise<ExportDeclaration> {
    try {
      logger.info(`Fetching export declaration: ${dueNumber}`);

      const response = await this.httpClient.get(`/exportacao/declaracoes/${dueNumber}`);
      const data = response.data;

      const declaration: ExportDeclaration = {
        due_number: data.numero_due,
        exporter_cnpj: data.cnpj_exportador,
        export_date: new Date(data.data_registro),
        items: data.itens.map((item: any) => ({
          item_number: item.numero_item,
          ncm_code: item.codigo_ncm,
          product_description: item.descricao_mercadoria,
          quantity: item.quantidade,
          unit_of_measure: item.unidade_medida,
          unit_value_usd: item.valor_unitario_usd,
          total_value_usd: item.valor_total_usd,
          anvisa_export_license: item.licenca_exportacao_anvisa
        })),
        total_value_usd: data.valor_total_usd,
        destination_country: data.pais_destino,
        shipping_terms: data.condicoes_venda,
        status: data.status
      };

      // Cache result
      await redisClient.setEx(
        `siscomex-due:${dueNumber}`,
        3600,
        JSON.stringify(declaration)
      );

      logger.info(`Export declaration fetched successfully: ${dueNumber}`);
      return declaration;

    } catch (error) {
      logger.error(`Failed to fetch export declaration ${dueNumber}:`, error);
      throw error;
    }
  }

  /**
   * Consulta classificação NCM
   */
  async getNCMClassification(ncmCode: string): Promise<NCMClassification> {
    try {
      logger.info(`Fetching NCM classification: ${ncmCode}`);

      // Check cache first
      const cacheKey = `siscomex-ncm:${ncmCode}`;
      const cached = await redisClient.get(cacheKey);
      if (cached) {
        return JSON.parse(cached);
      }

      const response = await this.httpClient.get(`/classificacao/ncm/${ncmCode}`);
      const data = response.data;

      const classification: NCMClassification = {
        ncm_code: data.codigo_ncm,
        description: data.descricao,
        import_tax_rate: data.aliquota_imposto_importacao,
        ipi_rate: data.aliquota_ipi,
        pis_rate: data.aliquota_pis,
        cofins_rate: data.aliquota_cofins,
        antidumping_applicable: data.antidumping_aplicavel,
        import_license_required: data.licenciamento_importacao,
        restrictions: data.restricoes || []
      };

      // Cache for 24 hours
      await redisClient.setEx(cacheKey, 86400, JSON.stringify(classification));

      logger.info(`NCM classification fetched successfully: ${ncmCode}`);
      return classification;

    } catch (error) {
      logger.error(`Failed to fetch NCM classification ${ncmCode}:`, error);
      throw error;
    }
  }

  /**
   * Consulta status aduaneiro
   */
  async getCustomsStatus(declarationNumber: string, type: 'DI' | 'DUE'): Promise<CustomsStatus> {
    try {
      logger.info(`Fetching customs status for ${type}: ${declarationNumber}`);

      const endpoint = type === 'DI' 
        ? `/importacao/status/${declarationNumber}`
        : `/exportacao/status/${declarationNumber}`;

      const response = await this.httpClient.get(endpoint);
      const data = response.data;

      const status: CustomsStatus = {
        di_number: type === 'DI' ? declarationNumber : undefined,
        due_number: type === 'DUE' ? declarationNumber : undefined,
        current_status: data.status_atual,
        status_date: new Date(data.data_status),
        location: data.local_despacho,
        next_steps: data.proximos_passos || [],
        estimated_release_date: data.data_prevista_liberacao ? 
          new Date(data.data_prevista_liberacao) : undefined,
        inspection_required: data.vistoria_necessaria,
        documents_pending: data.documentos_pendentes || []
      };

      // Cache for 1 hour
      await redisClient.setEx(
        `siscomex-status:${type}:${declarationNumber}`,
        3600,
        JSON.stringify(status)
      );

      logger.info(`Customs status fetched successfully for ${type}: ${declarationNumber}`);
      return status;

    } catch (error) {
      logger.error(`Failed to fetch customs status for ${type} ${declarationNumber}:`, error);
      throw error;
    }
  }

  /**
   * Lista parceiros comerciais habilitados
   */
  async getTradingPartners(country?: string): Promise<TradingPartner[]> {
    try {
      logger.info('Fetching trading partners');

      const params = country ? { pais: country } : {};
      const response = await this.httpClient.get('/parceiros-comerciais', { params });

      const partners = response.data.parceiros.map((data: any) => ({
        cnpj: data.cnpj,
        company_name: data.razao_social,
        country: data.pais,
        habilitation_status: data.status_habilitacao,
        certifications: data.certificacoes || [],
        last_transaction_date: new Date(data.data_ultima_transacao)
      }));

      // Cache for 6 hours
      const cacheKey = `siscomex-partners${country ? `:${country}` : ''}`;
      await redisClient.setEx(cacheKey, 21600, JSON.stringify(partners));

      logger.info(`Found ${partners.length} trading partners`);
      return partners;

    } catch (error) {
      logger.error('Failed to fetch trading partners:', error);
      throw error;
    }
  }

  /**
   * Busca produtos por descrição ou NCM
   */
  async searchProducts(query: string, searchType: 'description' | 'ncm' = 'description'): Promise<any[]> {
    try {
      logger.info(`Searching products: ${query}`);

      const params = {
        [searchType === 'ncm' ? 'codigo_ncm' : 'descricao']: query,
        limit: 100
      };

      const response = await this.httpClient.get('/consulta/produtos', { params });
      
      const products = response.data.produtos || [];

      logger.info(`Found ${products.length} products matching: ${query}`);
      return products;

    } catch (error) {
      logger.error(`Failed to search products with query ${query}:`, error);
      throw error;
    }
  }

  /**
   * Consulta histórico de transações
   */
  async getTransactionHistory(
    cnpj: string,
    startDate: Date,
    endDate: Date,
    type: 'import' | 'export' | 'both' = 'both'
  ): Promise<any[]> {
    try {
      logger.info(`Fetching transaction history for CNPJ: ${cnpj}`);

      const params = {
        cnpj,
        data_inicio: startDate.toISOString().split('T')[0],
        data_fim: endDate.toISOString().split('T')[0],
        tipo: type
      };

      const response = await this.httpClient.get('/consulta/historico-transacoes', { params });
      
      const transactions = response.data.transacoes || [];

      // Cache for 30 minutes
      const cacheKey = `siscomex-history:${cnpj}:${startDate.toISOString()}:${endDate.toISOString()}`;
      await redisClient.setEx(cacheKey, 1800, JSON.stringify(transactions));

      logger.info(`Found ${transactions.length} transactions for CNPJ: ${cnpj}`);
      return transactions;

    } catch (error) {
      logger.error(`Failed to fetch transaction history for CNPJ ${cnpj}:`, error);
      throw error;
    }
  }

  /**
   * Validar viabilidade de importação
   */
  async validateImportViability(productData: {
    ncm_code: string;
    origin_country: string;
    value_usd: number;
    quantity: number;
  }): Promise<{
    viable: boolean;
    restrictions: string[];
    required_licenses: string[];
    estimated_taxes: {
      import_tax: number;
      ipi: number;
      pis: number;
      cofins: number;
      total: number;
    };
    estimated_clearance_time: number; // days
  }> {
    try {
      logger.info(`Validating import viability for NCM: ${productData.ncm_code}`);

      const [ncmClassification, restrictions] = await Promise.all([
        this.getNCMClassification(productData.ncm_code),
        this.httpClient.get(`/consulta/restricoes/${productData.ncm_code}/${productData.origin_country}`)
      ]);

      const estimatedTaxes = {
        import_tax: productData.value_usd * (ncmClassification.import_tax_rate / 100),
        ipi: productData.value_usd * (ncmClassification.ipi_rate / 100),
        pis: productData.value_usd * (ncmClassification.pis_rate / 100),
        cofins: productData.value_usd * (ncmClassification.cofins_rate / 100),
        total: 0
      };

      estimatedTaxes.total = estimatedTaxes.import_tax + estimatedTaxes.ipi + 
                            estimatedTaxes.pis + estimatedTaxes.cofins;

      const result = {
        viable: restrictions.data.viable,
        restrictions: restrictions.data.restricoes || [],
        required_licenses: restrictions.data.licencas_necessarias || [],
        estimated_taxes: estimatedTaxes,
        estimated_clearance_time: restrictions.data.tempo_estimado_liberacao || 5
      };

      logger.info(`Import viability validated for NCM: ${productData.ncm_code}`);
      return result;

    } catch (error) {
      logger.error(`Failed to validate import viability for NCM ${productData.ncm_code}:`, error);
      throw error;
    }
  }

  /**
   * Monitorar mudanças regulatórias
   */
  async getRegulatory ChangeNotifications(lastCheckDate?: Date): Promise<any[]> {
    try {
      logger.info('Fetching regulatory change notifications');

      const params = lastCheckDate ? {
        data_inicio: lastCheckDate.toISOString().split('T')[0]
      } : {};

      const response = await this.httpClient.get('/notificacoes/mudancas-regulatorias', { params });
      
      const notifications = response.data.notificacoes || [];

      // Store latest check time
      await redisClient.set('siscomex-last-regulatory-check', new Date().toISOString());

      logger.info(`Found ${notifications.length} regulatory change notifications`);
      return notifications;

    } catch (error) {
      logger.error('Failed to fetch regulatory change notifications:', error);
      throw error;
    }
  }

  /**
   * Health check do serviço
   */
  async healthCheck(): Promise<{ status: string; timestamp: Date; response_time: number }> {
    const startTime = Date.now();
    
    try {
      await this.httpClient.get('/health');
      
      return {
        status: 'healthy',
        timestamp: new Date(),
        response_time: Date.now() - startTime
      };

    } catch (error) {
      logger.warn('SISCOMEX health check failed:', error);
      
      return {
        status: 'unhealthy',
        timestamp: new Date(),
        response_time: Date.now() - startTime
      };
    }
  }
}