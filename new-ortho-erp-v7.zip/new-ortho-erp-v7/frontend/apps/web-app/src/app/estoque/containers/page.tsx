'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Package, 
  Plus, 
  Search, 
  Filter, 
  MapPin, 
  Thermometer, 
  Droplets,
  Battery,
  QrCode,
  Scan,
  AlertTriangle,
  CheckCircle,
  Clock,
  Truck,
  Settings
} from 'lucide-react';
import { ContainerGrid } from '@/components/inventory/ContainerGrid';
import { ContainerMap } from '@/components/inventory/ContainerMap';
import { NewContainerModal } from '@/components/inventory/NewContainerModal';
import { ContainerDetailsModal } from '@/components/inventory/ContainerDetailsModal';
import { AIOptimizationPanel } from '@/components/inventory/AIOptimizationPanel';

export default function ContainersPage() {
  const [view, setView] = useState<'grid' | 'map'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedContainer, setSelectedContainer] = useState<any>(null);
  const [showNewContainer, setShowNewContainer] = useState(false);
  const [showContainerDetails, setShowContainerDetails] = useState(false);
  const [filters, setFilters] = useState({
    status: 'all',
    type: 'all',
    location: 'all',
    urgent: false
  });

  return (
    <div className="min-h-screen bg-gradient-bg">
      <div className="main-content">
        <div className="flex flex-col space-y-6">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between"
          >
            <div>
              <h1 className="text-3xl font-display font-bold text-white mb-2">
                📦 Containers Inteligentes
              </h1>
              <p className="text-gray-400">
                Gestão de containers OPME com IA e controle de validade
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* View Toggle */}
              <div className="glass-card p-1 flex">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setView('grid')}
                  className={`px-4 py-2 rounded-lg text-sm transition-all ${
                    view === 'grid' 
                      ? 'bg-purple-500 text-white' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Package className="w-4 h-4" />
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setView('map')}
                  className={`px-4 py-2 rounded-lg text-sm transition-all ${
                    view === 'map' 
                      ? 'bg-purple-500 text-white' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <MapPin className="w-4 h-4" />
                </motion.button>
              </div>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowNewContainer(true)}
                className="btn-primary flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Novo Container
              </motion.button>
            </div>
          </motion.div>

          {/* Container Stats */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
              className="glass-card p-4 text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Package className="w-5 h-5 text-turquoise-400" />
                <span className="text-2xl font-bold text-turquoise-400">34</span>
              </div>
              <div className="text-sm text-gray-400">Total Containers</div>
              <div className="text-xs text-gray-500 mt-1">+3 este mês</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="glass-card p-4 text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-2xl font-bold text-green-400">28</span>
              </div>
              <div className="text-sm text-gray-400">Disponíveis</div>
              <div className="text-xs text-gray-500 mt-1">Prontos para uso</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
              className="glass-card p-4 text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Truck className="w-5 h-5 text-blue-400" />
                <span className="text-2xl font-bold text-blue-400">4</span>
              </div>
              <div className="text-sm text-gray-400">Em Trânsito</div>
              <div className="text-xs text-gray-500 mt-1">Para hospitais</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 }}
              className="glass-card p-4 text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-orange-400" />
                <span className="text-2xl font-bold text-orange-400">2</span>
              </div>
              <div className="text-sm text-gray-400">Manutenção</div>
              <div className="text-xs text-gray-500 mt-1">Sensores offline</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
              className="glass-card p-4 text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Clock className="w-5 h-5 text-red-400" />
                <span className="text-2xl font-bold text-red-400">12</span>
              </div>
              <div className="text-sm text-gray-400">Vencimento Próximo</div>
              <div className="text-xs text-gray-500 mt-1">Próximos 30 dias</div>
            </motion.div>
          </div>

          {/* AI Optimization Panel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <AIOptimizationPanel />
          </motion.div>

          {/* Search and Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="glass-card p-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 flex-1">
                {/* Search */}
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Buscar por código, localização ou hospital..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="input-field-glass pl-10 w-full"
                  />
                </div>

                {/* Filters */}
                <select
                  value={filters.status}
                  onChange={(e) => setFilters({...filters, status: e.target.value})}
                  className="input-field-glass min-w-[140px]"
                >
                  <option value="all">Todos Status</option>
                  <option value="AVAILABLE">Disponível</option>
                  <option value="IN_USE">Em Uso</option>
                  <option value="IN_TRANSIT">Em Trânsito</option>
                  <option value="MAINTENANCE">Manutenção</option>
                </select>

                <select
                  value={filters.type}
                  onChange={(e) => setFilters({...filters, type: e.target.value})}
                  className="input-field-glass min-w-[120px]"
                >
                  <option value="all">Todos Tipos</option>
                  <option value="MOBILE">Móvel</option>
                  <option value="FIXED">Fixo</option>
                  <option value="SMART">Inteligente</option>
                </select>
              </div>

              <div className="flex items-center space-x-3">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-secondary flex items-center gap-2"
                >
                  <QrCode className="w-4 h-4" />
                  Scan QR
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-secondary flex items-center gap-2"
                >
                  <Settings className="w-4 h-4" />
                  IA Config
                </motion.button>
              </div>
            </div>
          </motion.div>

          {/* Container Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            {view === 'grid' ? (
              <ContainerGrid 
                searchQuery={searchQuery}
                filters={filters}
                onSelectContainer={(container) => {
                  setSelectedContainer(container);
                  setShowContainerDetails(true);
                }}
              />
            ) : (
              <ContainerMap 
                searchQuery={searchQuery}
                filters={filters}
                onSelectContainer={(container) => {
                  setSelectedContainer(container);
                  setShowContainerDetails(true);
                }}
              />
            )}
          </motion.div>
        </div>
      </div>

      {/* Modals */}
      {showNewContainer && (
        <NewContainerModal 
          onClose={() => setShowNewContainer(false)}
        />
      )}

      {showContainerDetails && selectedContainer && (
        <ContainerDetailsModal 
          container={selectedContainer}
          onClose={() => {
            setShowContainerDetails(false);
            setSelectedContainer(null);
          }}
        />
      )}
    </div>
  );
}