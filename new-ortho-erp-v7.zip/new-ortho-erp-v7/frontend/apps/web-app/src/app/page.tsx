'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';

export default function HomePage() {
  const router = useRouter();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading) {
      if (user) {
        // User is authenticated, redirect to dashboard
        router.replace('/dashboard');
      } else {
        // User is not authenticated, redirect to login
        router.replace('/login');
      }
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-bg">
        <div className="glass-card p-8 text-center">
          <div className="mb-6">
            <div className="text-4xl font-display font-bold text-gradient-purple mb-2">
              NEW ORTHO ERP
            </div>
            <div className="text-sm text-gray-400">v7.0</div>
          </div>
          <LoadingSpinner size="lg" />
          <p className="text-gray-400 mt-4">Carregando sistema...</p>
        </div>
      </div>
    );
  }

  return null;
}