'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Filter, 
  Upload, 
  FileText, 
  Camera, 
  Truck,
  DollarSign,
  CheckCircle,
  XCircle,
  Eye,
  Edit,
  Printer
} from 'lucide-react';
import { PostSurgeryTable } from '@/components/surgery/PostSurgeryTable';
import { MaterialUsageModal } from '@/components/surgery/MaterialUsageModal';
import { BillingAuthModal } from '@/components/surgery/BillingAuthModal';
import { StatusProgressBar } from '@/components/surgery/StatusProgressBar';

export default function PostSurgeryPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSurgery, setSelectedSurgery] = useState<any>(null);
  const [showMaterialUsage, setShowMaterialUsage] = useState(false);
  const [showBillingAuth, setShowBillingAuth] = useState(false);
  const [filters, setFilters] = useState({
    status: 'all',
    patient: '',
    dateRange: 'all'
  });

  // Status flow para pós-cirúrgico conforme especificação
  const postSurgeryStatuses = [
    { id: 'LOGISTICS', label: 'Logística', color: 'bg-blue-500' },
    { id: 'IN_SURGERY', label: 'Cirurgia', color: 'bg-red-500' },
    { id: 'REVERSE_LOGISTICS', label: 'Logística Reversa', color: 'bg-orange-500' },
    { id: 'POST_QUOTATION', label: 'Cotação Pós-cirúrgica', color: 'bg-purple-500' },
    { id: 'BILLING_AUTH', label: 'Autorização Faturamento', color: 'bg-green-500' },
    { id: 'BILLING', label: 'Faturamento (NF)', color: 'bg-emerald-500' }
  ];

  return (
    <div className="min-h-screen bg-gradient-bg">
      <div className="main-content">
        <div className="flex flex-col space-y-6">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between"
          >
            <div>
              <h1 className="text-3xl font-display font-bold text-white mb-2">
                📋 Pós-cirúrgico
              </h1>
              <p className="text-gray-400">
                Faturamento e documentação de materiais utilizados
              </p>
            </div>
          </motion.div>

          {/* Status Flow Indicator */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass-card p-6"
          >
            <h3 className="text-white font-semibold mb-4 flex items-center space-x-2">
              <Truck className="w-5 h-5 text-turquoise-400" />
              <span>Fluxo Pós-cirúrgico</span>
            </h3>
            
            <StatusProgressBar 
              statuses={postSurgeryStatuses}
              currentStatus="REVERSE_LOGISTICS"
            />
          </motion.div>

          {/* Search and Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-card p-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 flex-1">
                {/* Search by Patient */}
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Buscar por paciente..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="input-field-glass pl-10 w-full"
                  />
                </div>

                {/* Quick Filters */}
                <select
                  value={filters.status}
                  onChange={(e) => setFilters({...filters, status: e.target.value})}
                  className="input-field-glass min-w-[200px]"
                >
                  <option value="all">Todos os Status</option>
                  <option value="REVERSE_LOGISTICS">Logística Reversa</option>
                  <option value="POST_QUOTATION">Cotação Pós</option>
                  <option value="BILLING_AUTH">Aguardando Autorização</option>
                  <option value="BILLING">Faturamento</option>
                </select>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-3">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-secondary flex items-center gap-2"
                >
                  <Printer className="w-4 h-4" />
                  Relatórios
                </motion.button>
              </div>
            </div>
          </motion.div>

          {/* Post-Surgery Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="glass-card"
          >
            <div className="p-6 border-b border-white border-opacity-10">
              <h3 className="text-white font-semibold flex items-center space-x-2">
                <FileText className="w-5 h-5 text-purple-400" />
                <span>Cirurgias para Faturamento</span>
              </h3>
            </div>

            <PostSurgeryTable 
              searchQuery={searchQuery}
              filters={filters}
              onSelectSurgery={setSelectedSurgery}
              onShowMaterialUsage={(surgery) => {
                setSelectedSurgery(surgery);
                setShowMaterialUsage(true);
              }}
              onShowBillingAuth={(surgery) => {
                setSelectedSurgery(surgery);
                setShowBillingAuth(true);
              }}
            />
          </motion.div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 }}
              className="glass-card p-4 text-center"
            >
              <div className="text-2xl font-bold text-turquoise-400 mb-1">24</div>
              <div className="text-sm text-gray-400">Aguardando Faturamento</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
              className="glass-card p-4 text-center"
            >
              <div className="text-2xl font-bold text-green-400 mb-1">18</div>
              <div className="text-sm text-gray-400">Autorizadas</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 }}
              className="glass-card p-4 text-center"
            >
              <div className="text-2xl font-bold text-orange-400 mb-1">6</div>
              <div className="text-sm text-gray-400">Faturamento Parcial</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7 }}
              className="glass-card p-4 text-center"
            >
              <div className="text-2xl font-bold text-purple-400 mb-1">R$ 487K</div>
              <div className="text-sm text-gray-400">Valor Total</div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {showMaterialUsage && selectedSurgery && (
        <MaterialUsageModal 
          surgery={selectedSurgery}
          onClose={() => {
            setShowMaterialUsage(false);
            setSelectedSurgery(null);
          }}
        />
      )}

      {showBillingAuth && selectedSurgery && (
        <BillingAuthModal 
          surgery={selectedSurgery}
          onClose={() => {
            setShowBillingAuth(false);
            setSelectedSurgery(null);
          }}
        />
      )}
    </div>
  );
}