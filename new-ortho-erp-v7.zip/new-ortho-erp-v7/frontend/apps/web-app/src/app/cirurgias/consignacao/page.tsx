'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Plus, 
  Search, 
  Filter, 
  AlertTriangle, 
  Package, 
  Truck,
  QrCode,
  Scan,
  Clock,
  CheckCircle,
  FileText,
  Download
} from 'lucide-react';
import { ConsignmentTable } from '@/components/surgery/ConsignmentTable';
import { NewConsignmentModal } from '@/components/surgery/NewConsignmentModal';
import { ContainerScanModal } from '@/components/surgery/ContainerScanModal';
import { UrgencyToggle } from '@/components/surgery/UrgencyToggle';

export default function ConsignmentPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewConsignment, setShowNewConsignment] = useState(false);
  const [showContainerScan, setShowContainerScan] = useState(false);
  const [filters, setFilters] = useState({
    status: 'all',
    urgent: 'all',
    hospital: 'all',
    dateRange: 'all'
  });

  return (
    <div className="min-h-screen bg-gradient-bg">
      <div className="main-content">
        <div className="flex flex-col space-y-6">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between"
          >
            <div>
              <h1 className="text-3xl font-display font-bold text-white mb-2">
                📦 Pedidos em Consignação
              </h1>
              <p className="text-gray-400">
                Gestão de containers e materiais para cirurgias
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowContainerScan(true)}
                className="btn-secondary flex items-center gap-2"
              >
                <QrCode className="w-5 h-5" />
                Scan Container
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowNewConsignment(true)}
                className="btn-primary flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Nova Consignação
              </motion.button>
            </div>
          </motion.div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
              className="glass-card p-4 text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-red-400" />
                <span className="text-2xl font-bold text-red-400">8</span>
              </div>
              <div className="text-sm text-gray-400">Urgências Ativas</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="glass-card p-4 text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Package className="w-5 h-5 text-turquoise-400" />
                <span className="text-2xl font-bold text-turquoise-400">34</span>
              </div>
              <div className="text-sm text-gray-400">Containers Ativos</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
              className="glass-card p-4 text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Truck className="w-5 h-5 text-blue-400" />
                <span className="text-2xl font-bold text-blue-400">12</span>
              </div>
              <div className="text-sm text-gray-400">Em Trânsito</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 }}
              className="glass-card p-4 text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-2xl font-bold text-green-400">156</span>
              </div>
              <div className="text-sm text-gray-400">Entregues Hoje</div>
            </motion.div>
          </div>

          {/* Search and Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="glass-card p-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 flex-1">
                {/* Search */}
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Buscar por hospital, médico ou container..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="input-field-glass pl-10 w-full"
                  />
                </div>

                {/* Urgency Filter */}
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-300">Mostrar:</span>
                  <UrgencyToggle
                    value={filters.urgent}
                    onChange={(value) => setFilters({...filters, urgent: value})}
                  />
                </div>

                {/* Status Filter */}
                <select
                  value={filters.status}
                  onChange={(e) => setFilters({...filters, status: e.target.value})}
                  className="input-field-glass min-w-[150px]"
                >
                  <option value="all">Todos Status</option>
                  <option value="PREPARING">Preparando</option>
                  <option value="READY">Pronto</option>
                  <option value="DISPATCHED">Enviado</option>
                  <option value="DELIVERED">Entregue</option>
                  <option value="IN_USE">Em Uso</option>
                  <option value="RETURNED">Devolvido</option>
                </select>
              </div>

              <div className="flex items-center space-x-3">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-secondary flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Exportar
                </motion.button>
              </div>
            </div>
          </motion.div>

          {/* Urgency Alert Banner */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-red-500 bg-opacity-20 border border-red-500 border-opacity-30 rounded-xl p-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <AlertTriangle className="w-6 h-6 text-red-400" />
                <div>
                  <div className="text-red-400 font-semibold">
                    8 Cirurgias de Urgência Ativas
                  </div>
                  <div className="text-red-300 text-sm">
                    Notificações enviadas via email, WhatsApp e push. 
                    Containers preparados com valores simbólicos R$ 100,00.
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-red-500 bg-opacity-20 text-red-300 px-4 py-2 rounded-lg text-sm hover:bg-opacity-30 transition-all"
                >
                  Ver Urgências
                </motion.button>
              </div>
            </div>
          </motion.div>

          {/* Consignment Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="glass-card"
          >
            <div className="p-6 border-b border-white border-opacity-10">
              <div className="flex items-center justify-between">
                <h3 className="text-white font-semibold flex items-center space-x-2">
                  <Package className="w-5 h-5 text-purple-400" />
                  <span>Pedidos em Consignação</span>
                </h3>
                
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span className="text-gray-400">Urgência</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-gray-400">Eletiva</span>
                  </div>
                </div>
              </div>
            </div>

            <ConsignmentTable 
              searchQuery={searchQuery}
              filters={filters}
              onScanContainer={() => setShowContainerScan(true)}
            />
          </motion.div>
        </div>
      </div>

      {/* Modals */}
      {showNewConsignment && (
        <NewConsignmentModal 
          onClose={() => setShowNewConsignment(false)}
        />
      )}

      {showContainerScan && (
        <ContainerScanModal 
          onClose={() => setShowContainerScan(false)}
        />
      )}
    </div>
  );
}