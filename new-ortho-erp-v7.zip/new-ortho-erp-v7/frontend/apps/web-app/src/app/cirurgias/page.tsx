'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Filter, 
  Plus, 
  Calendar,
  AlertTriangle,
  Clock,
  CheckCircle,
  Hospital,
  User,
  FileText,
  Truck
} from 'lucide-react';
import { SurgeryKanban } from '@/components/surgery/SurgeryKanban';
import { SurgeryFilters } from '@/components/surgery/SurgeryFilters';
import { NewSurgeryModal } from '@/components/surgery/NewSurgeryModal';
import { SurgeryStats } from '@/components/surgery/SurgeryStats';

export default function SurgeriesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    status: 'all',
    type: 'all',
    hospital: 'all',
    doctor: 'all',
    insurance: 'all',
    dateRange: 'all'
  });
  const [showFilters, setShowFilters] = useState(false);
  const [showNewSurgery, setShowNewSurgery] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-bg">
      {/* Header */}
      <div className="main-content">
        <div className="flex flex-col space-y-6">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between"
          >
            <div>
              <h1 className="text-3xl font-display font-bold text-white mb-2">
                🏥 Módulo Cirurgias
              </h1>
              <p className="text-gray-400">
                Gestão completa do fluxo cirúrgico com Kanban interativo
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowNewSurgery(true)}
                className="btn-primary flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Nova Cirurgia
              </motion.button>
            </div>
          </motion.div>

          {/* Statistics Cards */}
          <SurgeryStats />

          {/* Search and Filters Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass-card p-4"
          >
            <div className="flex items-center space-x-4">
              {/* Search */}
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Buscar por paciente, médico, convênio ou hospital..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="input-field-glass pl-10 w-full"
                />
              </div>

              {/* Filter Toggle */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowFilters(!showFilters)}
                className={`btn-secondary flex items-center gap-2 ${
                  showFilters ? 'bg-purple-500 bg-opacity-20' : ''
                }`}
              >
                <Filter className="w-5 h-5" />
                Filtros
              </motion.button>
            </div>

            {/* Expandable Filters */}
            {showFilters && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 pt-4 border-t border-white border-opacity-10"
              >
                <SurgeryFilters
                  filters={filters}
                  onFiltersChange={setFilters}
                />
              </motion.div>
            )}
          </motion.div>

          {/* Kanban Board */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <SurgeryKanban 
              searchQuery={searchQuery}
              filters={filters}
            />
          </motion.div>
        </div>
      </div>

      {/* Modals */}
      {showNewSurgery && (
        <NewSurgeryModal 
          onClose={() => setShowNewSurgery(false)}
        />
      )}
    </div>
  );
}