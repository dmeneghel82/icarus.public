'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  User, 
  Hospital, 
  Calendar, 
  DollarSign, 
  CheckCircle, 
  XCircle,
  Eye,
  Edit,
  Upload,
  FileText,
  Camera,
  AlertTriangle,
  Package,
  CreditCard
} from 'lucide-react';
import { formatCurrency, formatDate } from '@/utils/format';
import { StatusProgressBar } from './StatusProgressBar';

interface PostSurgeryTableProps {
  searchQuery: string;
  filters: any;
  onSelectSurgery: (surgery: any) => void;
  onShowMaterialUsage: (surgery: any) => void;
  onShowBillingAuth: (surgery: any) => void;
}

// Mock data - seria carregado da API
const mockSurgeries = [
  {
    id: '1',
    code: 'CIR-2025-001',
    patient: { name: 'João Silva', insurance: 'Unimed', insuranceNumber: '123456789' },
    doctor: { name: 'Dr. Carlos Oliveira', specialty: 'Ortopedia' },
    hospital: { name: 'Hospital São Lucas' },
    procedure: 'Artroplastia de Joelho',
    surgeryDate: new Date('2025-08-20'),
    status: 'REVERSE_LOGISTICS',
    totalValue: 45000.00,
    authorizedValue: 45000.00,
    billedValue: 0,
    billingType: null,
    isUrgent: false,
    materialsUsed: [
      { name: 'Prótese de Joelho', quantity: 1, unitPrice: 35000, used: true },
      { name: 'Parafuso Cortical', quantity: 4, unitPrice: 250, used: true },
      { name: 'Placa Óssea', quantity: 1, unitPrice: 2000, used: false }
    ],
    documents: {
      surgicalReport: true,
      images: 3,
      seals: true
    }
  },
  {
    id: '2',
    code: 'CIR-2025-002',
    patient: { name: 'Maria Santos', insurance: 'Bradesco Saúde', insuranceNumber: '987654321' },
    doctor: { name: 'Dra. Ana Costa', specialty: 'Cardiologia' },
    hospital: { name: 'Hospital Santa Maria' },
    procedure: 'Implante de Stent Coronário',
    surgeryDate: new Date('2025-08-19'),
    status: 'BILLING_AUTH',
    totalValue: 28000.00,
    authorizedValue: 28000.00,
    billedValue: 0,
    billingType: null,
    isUrgent: true,
    materialsUsed: [
      { name: 'Stent Drug-Eluting', quantity: 2, unitPrice: 12000, used: true },
      { name: 'Cateter Balão', quantity: 1, unitPrice: 1500, used: true },
      { name: 'Guia Coronário', quantity: 1, unitPrice: 500, used: true }
    ],
    documents: {
      surgicalReport: true,
      images: 5,
      seals: true
    }
  },
  {
    id: '3',
    code: 'CIR-2025-003',
    patient: { name: 'Pedro Oliveira', insurance: 'SUS', insuranceNumber: '456789123' },
    doctor: { name: 'Dr. João Silva', specialty: 'Neurocirurgia' },
    hospital: { name: 'Hospital Albert Einstein' },
    procedure: 'Craniotomia para Ressecção de Tumor',
    surgeryDate: new Date('2025-08-18'),
    status: 'BILLING',
    totalValue: 85000.00,
    authorizedValue: 75000.00,
    billedValue: 75000.00,
    billingType: 'TOTAL',
    isUrgent: false,
    materialsUsed: [
      { name: 'Placa de Titânio Craniana', quantity: 1, unitPrice: 15000, used: true },
      { name: 'Parafusos Cranianos', quantity: 8, unitPrice: 200, used: true },
      { name: 'Dura-mater Artificial', quantity: 1, unitPrice: 3000, used: true }
    ],
    documents: {
      surgicalReport: true,
      images: 12,
      seals: true
    }
  }
];

export function PostSurgeryTable({ 
  searchQuery, 
  filters, 
  onSelectSurgery, 
  onShowMaterialUsage, 
  onShowBillingAuth 
}: PostSurgeryTableProps) {
  const [selectedSurgeries, setSelectedSurgeries] = useState<string[]>([]);

  // Filter surgeries
  const filteredSurgeries = mockSurgeries.filter(surgery => {
    if (searchQuery && !surgery.patient.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    if (filters.status !== 'all' && surgery.status !== filters.status) {
      return false;
    }
    return true;
  });

  const getStatusColor = (status: string) => {
    const colors = {
      'REVERSE_LOGISTICS': 'bg-orange-500',
      'POST_QUOTATION': 'bg-purple-500', 
      'BILLING_AUTH': 'bg-yellow-500',
      'BILLING': 'bg-green-500'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-500';
  };

  const getStatusLabel = (status: string) => {
    const labels = {
      'REVERSE_LOGISTICS': 'Logística Reversa',
      'POST_QUOTATION': 'Cotação Pós',
      'BILLING_AUTH': 'Aguardando Autorização', 
      'BILLING': 'Faturamento'
    };
    return labels[status as keyof typeof labels] || status;
  };

  const handleSelectSurgery = (surgeryId: string) => {
    setSelectedSurgeries(prev => 
      prev.includes(surgeryId) 
        ? prev.filter(id => id !== surgeryId)
        : [...prev, surgeryId]
    );
  };

  const handleBillingAuthorization = (surgery: any, type: 'PARTIAL' | 'TOTAL') => {
    // Implementar autorização de faturamento
    console.log(`Autorização ${type} para cirurgia ${surgery.code}`);
    onShowBillingAuth(surgery);
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-white border-opacity-10">
            <th className="text-left py-4 px-6 text-gray-400 font-medium">
              <input 
                type="checkbox" 
                className="rounded"
                onChange={(e) => {
                  if (e.target.checked) {
                    setSelectedSurgeries(filteredSurgeries.map(s => s.id));
                  } else {
                    setSelectedSurgeries([]);
                  }
                }}
              />
            </th>
            <th className="text-left py-4 px-6 text-gray-400 font-medium">Paciente</th>
            <th className="text-left py-4 px-6 text-gray-400 font-medium">Médico/Hospital</th>
            <th className="text-left py-4 px-6 text-gray-400 font-medium">Procedimento</th>
            <th className="text-left py-4 px-6 text-gray-400 font-medium">Data Cirurgia</th>
            <th className="text-left py-4 px-6 text-gray-400 font-medium">Status</th>
            <th className="text-left py-4 px-6 text-gray-400 font-medium">Valor</th>
            <th className="text-left py-4 px-6 text-gray-400 font-medium">Autorização</th>
            <th className="text-center py-4 px-6 text-gray-400 font-medium">Ações</th>
          </tr>
        </thead>
        <tbody>
          {filteredSurgeries.map((surgery, index) => (
            <motion.tr
              key={surgery.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="border-b border-white border-opacity-5 hover:bg-white hover:bg-opacity-5 transition-colors"
            >
              {/* Checkbox */}
              <td className="py-4 px-6">
                <input 
                  type="checkbox"
                  checked={selectedSurgeries.includes(surgery.id)}
                  onChange={() => handleSelectSurgery(surgery.id)}
                  className="rounded"
                />
              </td>

              {/* Patient */}
              <td className="py-4 px-6">
                <div className="flex items-center space-x-2">
                  {surgery.isUrgent && (
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                  )}
                  <div>
                    <div className="text-white font-medium">
                      {surgery.patient.name}
                    </div>
                    <div className="text-gray-400 text-sm">
                      {surgery.patient.insurance} • {surgery.patient.insuranceNumber}
                    </div>
                  </div>
                </div>
              </td>

              {/* Doctor/Hospital */}
              <td className="py-4 px-6">
                <div>
                  <div className="text-white text-sm">
                    {surgery.doctor.name}
                  </div>
                  <div className="text-gray-400 text-sm">
                    {surgery.hospital.name}
                  </div>
                </div>
              </td>

              {/* Procedure */}
              <td className="py-4 px-6">
                <div className="text-white text-sm">
                  {surgery.procedure}
                </div>
                <div className="text-gray-400 text-xs">
                  {surgery.doctor.specialty}
                </div>
              </td>

              {/* Surgery Date */}
              <td className="py-4 px-6">
                <div className="text-white text-sm">
                  {formatDate(surgery.surgeryDate)}
                </div>
              </td>

              {/* Status */}
              <td className="py-4 px-6">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${getStatusColor(surgery.status)}`} />
                  <span className="text-white text-sm">
                    {getStatusLabel(surgery.status)}
                  </span>
                </div>

                {/* Progress Bar */}
                <div className="mt-2">
                  <StatusProgressBar 
                    statuses={[
                      { id: 'REVERSE_LOGISTICS', label: 'Logística Reversa', color: 'bg-orange-500' },
                      { id: 'POST_QUOTATION', label: 'Cotação Pós', color: 'bg-purple-500' },
                      { id: 'BILLING_AUTH', label: 'Autorização', color: 'bg-yellow-500' },
                      { id: 'BILLING', label: 'Faturamento', color: 'bg-green-500' }
                    ]}
                    currentStatus={surgery.status}
                    size="sm"
                  />
                </div>
              </td>

              {/* Value */}
              <td className="py-4 px-6">
                <div className="text-green-400 font-medium">
                  {formatCurrency(surgery.totalValue)}
                </div>
                {surgery.billedValue > 0 && (
                  <div className="text-gray-400 text-sm">
                    Faturado: {formatCurrency(surgery.billedValue)}
                  </div>
                )}
              </td>

              {/* Authorization Buttons */}
              <td className="py-4 px-6">
                {surgery.status === 'BILLING_AUTH' ? (
                  <div className="flex space-x-2">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleBillingAuthorization(surgery, 'PARTIAL')}
                      className="bg-orange-500 bg-opacity-20 text-orange-300 px-3 py-1 rounded-full text-xs hover:bg-opacity-30 transition-all"
                    >
                      Parcial
                    </motion.button>
                    
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleBillingAuthorization(surgery, 'TOTAL')}
                      className="bg-green-500 bg-opacity-20 text-green-300 px-3 py-1 rounded-full text-xs hover:bg-opacity-30 transition-all"
                    >
                      Total
                    </motion.button>
                  </div>
                ) : surgery.billingType ? (
                  <div className={`text-xs px-2 py-1 rounded-full ${
                    surgery.billingType === 'PARTIAL' 
                      ? 'bg-orange-500 bg-opacity-20 text-orange-300'
                      : 'bg-green-500 bg-opacity-20 text-green-300'
                  }`}>
                    {surgery.billingType === 'PARTIAL' ? 'Parcial' : 'Total'}
                  </div>
                ) : (
                  <span className="text-gray-500 text-sm">-</span>
                )}
              </td>

              {/* Actions */}
              <td className="py-4 px-6">
                <div className="flex items-center justify-center space-x-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => onSelectSurgery(surgery)}
                    className="p-1 rounded-full hover:bg-white hover:bg-opacity-10"
                    title="Ver Detalhes"
                  >
                    <Eye className="w-4 h-4 text-turquoise-400" />
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => onShowMaterialUsage(surgery)}
                    className="p-1 rounded-full hover:bg-white hover:bg-opacity-10"
                    title="Materiais Utilizados"
                  >
                    <Package className="w-4 h-4 text-purple-400" />
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-1 rounded-full hover:bg-white hover:bg-opacity-10"
                    title="Documentos"
                  >
                    <FileText className="w-4 h-4 text-blue-400" />
                  </motion.button>

                  {surgery.status === 'BILLING' && (
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="p-1 rounded-full hover:bg-white hover:bg-opacity-10"
                      title="Emitir NF"
                    >
                      <CreditCard className="w-4 h-4 text-green-400" />
                    </motion.button>
                  )}
                </div>
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>

      {/* Empty State */}
      {filteredSurgeries.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <p className="text-gray-500">Nenhuma cirurgia encontrada</p>
        </div>
      )}

      {/* Bulk Actions */}
      {selectedSurgeries.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-6 left-1/2 transform -translate-x-1/2 glass-card p-4 z-50"
        >
          <div className="flex items-center space-x-4">
            <span className="text-white">
              {selectedSurgeries.length} selecionadas
            </span>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-secondary text-sm"
            >
              Autorização em Lote
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-primary text-sm"
            >
              Gerar Relatório
            </motion.button>
          </div>
        </motion.div>
      )}
    </div>
  );
}