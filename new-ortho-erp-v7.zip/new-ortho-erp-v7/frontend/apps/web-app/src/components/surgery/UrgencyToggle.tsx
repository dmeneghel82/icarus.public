'use client';

import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';

interface UrgencyToggleProps {
  isUrgent?: boolean;
  onChange?: (isUrgent: boolean) => void;
  value?: string; // for filter component
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  label?: boolean;
}

export function UrgencyToggle({ 
  isUrgent = false, 
  onChange, 
  value, 
  size = 'md', 
  disabled = false,
  label = true 
}: UrgencyToggleProps) {
  // For filter mode
  if (value !== undefined && onChange) {
    return (
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as any)}
        className="input-field-glass min-w-[120px] text-sm"
      >
        <option value="all">Todos</option>
        <option value="urgent">Urgências</option>
        <option value="elective">Eletivas</option>
      </select>
    );
  }

  const sizeClasses = {
    sm: {
      container: 'w-10 h-5',
      toggle: 'w-4 h-4',
      text: 'text-xs'
    },
    md: {
      container: 'w-12 h-6',
      toggle: 'w-5 h-5',
      text: 'text-sm'
    },
    lg: {
      container: 'w-16 h-8',
      toggle: 'w-6 h-6',
      text: 'text-base'
    }
  };

  const classes = sizeClasses[size];

  return (
    <div className="flex items-center space-x-3">
      {label && (
        <span className={`text-gray-300 ${classes.text}`}>
          {isUrgent ? 'Urgência' : 'Eletiva'}
        </span>
      )}
      
      {/* Toggle Switch */}
      <motion.button
        onClick={() => !disabled && onChange && onChange(!isUrgent)}
        className={`
          ${classes.container} 
          rounded-full 
          transition-all 
          duration-300 
          flex 
          items-center 
          relative
          ${isUrgent 
            ? 'bg-red-500 justify-end shadow-lg shadow-red-500/30' 
            : 'bg-gray-600 justify-start'
          }
          ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:scale-105'}
        `}
        whileHover={!disabled ? { scale: 1.05 } : {}}
        whileTap={!disabled ? { scale: 0.95 } : {}}
        title={isUrgent ? 'Cirurgia de Urgência' : 'Cirurgia Eletiva'}
      >
        {/* Toggle Circle */}
        <motion.div
          className={`
            ${classes.toggle} 
            bg-white 
            rounded-full 
            transition-all 
            duration-300 
            mx-0.5
            flex
            items-center
            justify-center
            shadow-lg
          `}
          layout
          animate={{
            x: isUrgent ? 0 : 0,
          }}
        >
          {isUrgent && (
            <AlertTriangle className="w-3 h-3 text-red-500" />
          )}
        </motion.div>

        {/* Background Indicators */}
        <div className="absolute inset-0 flex items-center justify-between px-1">
          {!isUrgent && (
            <div className="text-white text-xs opacity-60">OFF</div>
          )}
          {isUrgent && (
            <div className="text-white text-xs opacity-60 ml-auto">ON</div>
          )}
        </div>
      </motion.button>

      {/* Status Text with Icon */}
      <div className="flex items-center space-x-1">
        {isUrgent ? (
          <>
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span className={`text-red-400 font-medium ${classes.text}`}>
              LIGAR URGÊNCIA
            </span>
          </>
        ) : (
          <span className={`text-gray-400 ${classes.text}`}>
            Cirurgia Eletiva
          </span>
        )}
      </div>

      {/* Additional Info */}
      {isUrgent && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-red-500 bg-opacity-20 border border-red-500 border-opacity-30 rounded-lg px-2 py-1"
        >
          <div className="text-red-300 text-xs font-medium">
            Notificação Máxima Ativa
          </div>
        </motion.div>
      )}
    </div>
  );
}

// Alternative compact version for tables
export function UrgencyBadge({ isUrgent }: { isUrgent: boolean }) {
  if (!isUrgent) return null;

  return (
    <motion.div
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      className="inline-flex items-center space-x-1 bg-red-500 bg-opacity-20 border border-red-500 border-opacity-30 px-2 py-1 rounded-full"
    >
      <AlertTriangle className="w-3 h-3 text-red-400" />
      <span className="text-red-400 text-xs font-medium uppercase">
        Urgência
      </span>
    </motion.div>
  );
}

// Status indicator for different states
export function UrgencyIndicator({ 
  isUrgent, 
  showLabel = false 
}: { 
  isUrgent: boolean; 
  showLabel?: boolean; 
}) {
  return (
    <div className="flex items-center space-x-2">
      <div className={`w-2 h-2 rounded-full ${
        isUrgent ? 'bg-red-500' : 'bg-green-500'
      }`} />
      
      {showLabel && (
        <span className={`text-xs ${
          isUrgent ? 'text-red-400' : 'text-green-400'
        }`}>
          {isUrgent ? 'Urgência' : 'Eletiva'}
        </span>
      )}
    </div>
  );
}