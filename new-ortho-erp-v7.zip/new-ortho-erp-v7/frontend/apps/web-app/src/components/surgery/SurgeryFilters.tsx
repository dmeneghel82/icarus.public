'use client';

import { motion } from 'framer-motion';
import { Calendar, Hospital, User, Shield, Activity } from 'lucide-react';

interface SurgeryFiltersProps {
  filters: {
    status: string;
    type: string;
    hospital: string;
    doctor: string;
    insurance: string;
    dateRange: string;
  };
  onFiltersChange: (filters: any) => void;
}

export function SurgeryFilters({ filters, onFiltersChange }: SurgeryFiltersProps) {
  const handleFilterChange = (key: string, value: string) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const clearFilters = () => {
    onFiltersChange({
      status: 'all',
      type: 'all',
      hospital: 'all',
      doctor: 'all',
      insurance: 'all',
      dateRange: 'all'
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4"
    >
      {/* Status Filter */}
      <div>
        <label className="flex items-center space-x-2 text-sm text-gray-300 mb-2">
          <Activity className="w-4 h-4" />
          <span>Status</span>
        </label>
        <select
          value={filters.status}
          onChange={(e) => handleFilterChange('status', e.target.value)}
          className="input-field-glass text-sm"
        >
          <option value="all">Todos</option>
          <option value="MEDICAL_REQUEST">Pedido Médico</option>
          <option value="PRICE_TABLE">Tabela de Preços</option>
          <option value="QUOTATION">Cotação</option>
          <option value="ANALYSIS">Análise</option>
          <option value="PRE_AUTHORIZATION">Autorização Pré</option>
          <option value="SCHEDULED">Agendamento</option>
          <option value="LOGISTICS">Logística</option>
          <option value="IN_SURGERY">Em Cirurgia</option>
          <option value="REVERSE_LOGISTICS">Logística Reversa</option>
          <option value="POST_SURGERY">Pós-cirúrgico</option>
          <option value="POST_QUOTATION">Cotação Pós</option>
          <option value="BILLING_AUTH">Autorização Fatur.</option>
          <option value="BILLING">Faturamento</option>
          <option value="COMPLETED">Concluída</option>
          <option value="CANCELLED">Cancelada</option>
        </select>
      </div>

      {/* Type Filter (Urgência/Eletiva) */}
      <div>
        <label className="flex items-center space-x-2 text-sm text-gray-300 mb-2">
          <Activity className="w-4 h-4" />
          <span>Tipo</span>
        </label>
        <select
          value={filters.type}
          onChange={(e) => handleFilterChange('type', e.target.value)}
          className="input-field-glass text-sm"
        >
          <option value="all">Todos</option>
          <option value="elective">Eletiva</option>
          <option value="urgent">Urgência</option>
          <option value="emergency">Emergência</option>
        </select>
      </div>

      {/* Hospital Filter */}
      <div>
        <label className="flex items-center space-x-2 text-sm text-gray-300 mb-2">
          <Hospital className="w-4 h-4" />
          <span>Hospital</span>
        </label>
        <select
          value={filters.hospital}
          onChange={(e) => handleFilterChange('hospital', e.target.value)}
          className="input-field-glass text-sm"
        >
          <option value="all">Todos</option>
          <option value="hospital_001">Hospital São Lucas</option>
          <option value="hospital_002">Hospital Santa Maria</option>
          <option value="hospital_003">Hospital Albert Einstein</option>
          <option value="hospital_004">Hospital Sírio-Libanês</option>
        </select>
      </div>

      {/* Doctor Filter */}
      <div>
        <label className="flex items-center space-x-2 text-sm text-gray-300 mb-2">
          <User className="w-4 h-4" />
          <span>Médico</span>
        </label>
        <select
          value={filters.doctor}
          onChange={(e) => handleFilterChange('doctor', e.target.value)}
          className="input-field-glass text-sm"
        >
          <option value="all">Todos</option>
          <option value="doctor_001">Dr. João Silva</option>
          <option value="doctor_002">Dra. Maria Santos</option>
          <option value="doctor_003">Dr. Carlos Oliveira</option>
          <option value="doctor_004">Dra. Ana Costa</option>
        </select>
      </div>

      {/* Insurance Filter */}
      <div>
        <label className="flex items-center space-x-2 text-sm text-gray-300 mb-2">
          <Shield className="w-4 h-4" />
          <span>Convênio</span>
        </label>
        <select
          value={filters.insurance}
          onChange={(e) => handleFilterChange('insurance', e.target.value)}
          className="input-field-glass text-sm"
        >
          <option value="all">Todos</option>
          <option value="sus">SUS</option>
          <option value="particular">Particular</option>
          <option value="unimed">Unimed</option>
          <option value="bradesco">Bradesco Saúde</option>
          <option value="amil">Amil</option>
        </select>
      </div>

      {/* Date Range Filter */}
      <div>
        <label className="flex items-center space-x-2 text-sm text-gray-300 mb-2">
          <Calendar className="w-4 h-4" />
          <span>Período</span>
        </label>
        <select
          value={filters.dateRange}
          onChange={(e) => handleFilterChange('dateRange', e.target.value)}
          className="input-field-glass text-sm"
        >
          <option value="all">Todos</option>
          <option value="today">Hoje</option>
          <option value="tomorrow">Amanhã</option>
          <option value="week">Esta Semana</option>
          <option value="month">Este Mês</option>
          <option value="overdue">Atrasadas</option>
        </select>
      </div>

      {/* Clear Filters Button */}
      <div className="md:col-span-3 lg:col-span-6 flex justify-end">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={clearFilters}
          className="btn-secondary text-sm"
        >
          Limpar Filtros
        </motion.button>
      </div>
    </motion.div>
  );
}