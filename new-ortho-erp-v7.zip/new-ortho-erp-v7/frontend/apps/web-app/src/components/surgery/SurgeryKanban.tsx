'use client';

import { useState, useEffect } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, 
  DollarSign, 
  Calculator, 
  Search as SearchIcon, 
  CheckCircle, 
  Calendar,
  Truck,
  Scissors,
  RotateCcw,
  FileBarChart,
  CreditCard,
  AlertTriangle
} from 'lucide-react';
import { SurgeryCard } from './SurgeryCard';
import { useSurgeries } from '@/hooks/useSurgeries';

interface SurgeryKanbanProps {
  searchQuery: string;
  filters: any;
}

// Status flow conforme especificado no documento
const SURGERY_COLUMNS = [
  {
    id: 'MEDICAL_REQUEST',
    title: 'Pedido Médico',
    icon: FileText,
    color: 'bg-orange-500',
    description: 'Solicitações médicas recebidas'
  },
  {
    id: 'PRICE_TABLE',
    title: 'Tabela de Preços',
    icon: DollarSign,
    color: 'bg-blue-500',
    description: 'Definição de preços'
  },
  {
    id: 'QUOTATION',
    title: 'Cotação',
    icon: Calculator,
    color: 'bg-purple-500',
    description: 'Cotação de materiais'
  },
  {
    id: 'ANALYSIS',
    title: 'Análise',
    icon: SearchIcon,
    color: 'bg-yellow-500',
    description: 'Em processo de autorização'
  },
  {
    id: 'PRE_AUTHORIZATION',
    title: 'Autorização Pré',
    icon: CheckCircle,
    color: 'bg-green-500',
    description: 'Autorização do convênio'
  },
  {
    id: 'SCHEDULED',
    title: 'Agendamento',
    icon: Calendar,
    color: 'bg-turquoise-500',
    description: 'Cirurgias agendadas'
  },
  {
    id: 'LOGISTICS',
    title: 'Logística',
    icon: Truck,
    color: 'bg-indigo-500',
    description: 'Entrega de materiais'
  },
  {
    id: 'IN_SURGERY',
    title: 'Cirurgia',
    icon: Scissors,
    color: 'bg-red-500',
    description: 'Em andamento'
  },
  {
    id: 'REVERSE_LOGISTICS',
    title: 'Logística Reversa',
    icon: RotateCcw,
    color: 'bg-orange-400',
    description: 'Retorno de materiais'
  },
  {
    id: 'POST_SURGERY',
    title: 'Pós-cirúrgico',
    icon: FileBarChart,
    color: 'bg-teal-500',
    description: 'Documentação pós-operatória'
  },
  {
    id: 'POST_QUOTATION',
    title: 'Cotação Pós',
    icon: Calculator,
    color: 'bg-purple-400',
    description: 'Cotação pós-cirúrgica'
  },
  {
    id: 'BILLING_AUTH',
    title: 'Autorização Fatur.',
    icon: CheckCircle,
    color: 'bg-green-400',
    description: 'Autorização para faturamento'
  },
  {
    id: 'BILLING',
    title: 'Faturamento',
    icon: CreditCard,
    color: 'bg-emerald-500',
    description: 'Emissão de NF'
  }
];

export function SurgeryKanban({ searchQuery, filters }: SurgeryKanbanProps) {
  const { surgeries, loading, moveSurgery, updateSurgeryStatus } = useSurgeries();
  const [filteredSurgeries, setFilteredSurgeries] = useState<any[]>([]);

  // Filter surgeries based on search and filters
  useEffect(() => {
    let filtered = surgeries || [];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter((surgery: any) => 
        surgery.patient?.name.toLowerCase().includes(query) ||
        surgery.doctor?.name.toLowerCase().includes(query) ||
        surgery.hospital?.name.toLowerCase().includes(query) ||
        surgery.insurance?.name.toLowerCase().includes(query) ||
        surgery.code.toLowerCase().includes(query)
      );
    }

    // Apply other filters
    if (filters.type !== 'all') {
      filtered = filtered.filter((surgery: any) => 
        surgery.type === filters.type || 
        (filters.type === 'urgent' && surgery.isUrgent) ||
        (filters.type === 'elective' && !surgery.isUrgent)
      );
    }

    if (filters.hospital !== 'all') {
      filtered = filtered.filter((surgery: any) => surgery.hospitalId === filters.hospital);
    }

    if (filters.doctor !== 'all') {
      filtered = filtered.filter((surgery: any) => surgery.doctorId === filters.doctor);
    }

    if (filters.insurance !== 'all') {
      filtered = filtered.filter((surgery: any) => surgery.insuranceId === filters.insurance);
    }

    setFilteredSurgeries(filtered);
  }, [surgeries, searchQuery, filters]);

  // Group surgeries by status
  const surgeriesByStatus = SURGERY_COLUMNS.reduce((acc, column) => {
    acc[column.id] = filteredSurgeries.filter(
      (surgery: any) => surgery.status === column.id
    );
    return acc;
  }, {} as Record<string, any[]>);

  const handleDragEnd = async (result: any) => {
    const { destination, source, draggableId } = result;

    // Dropped outside the list
    if (!destination) return;

    // Dropped in the same position
    if (
      destination.droppableId === source.droppableId &&
      destination.index === source.index
    ) {
      return;
    }

    const newStatus = destination.droppableId;
    
    try {
      await updateSurgeryStatus(draggableId, newStatus);
      
      // Optionally move the surgery in the UI immediately for better UX
      await moveSurgery(draggableId, source.droppableId, destination.droppableId, source.index, destination.index);
    } catch (error) {
      console.error('Error moving surgery:', error);
    }
  };

  if (loading) {
    return (
      <div className="glass-card p-8 text-center">
        <div className="spinner mx-auto mb-4" />
        <p className="text-gray-400">Carregando cirurgias...</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto pb-6">
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="flex space-x-4 min-w-max">
          {SURGERY_COLUMNS.map((column) => {
            const columnSurgeries = surgeriesByStatus[column.id] || [];
            const Icon = column.icon;

            return (
              <motion.div
                key={column.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: SURGERY_COLUMNS.indexOf(column) * 0.05 }}
                className="flex flex-col w-80 min-h-[600px]"
              >
                {/* Column Header */}
                <div className="glass-card p-4 mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${column.color}`} />
                      <Icon className="w-5 h-5 text-white" />
                      <h3 className="font-semibold text-white text-sm">
                        {column.title}
                      </h3>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <span className="bg-white bg-opacity-20 text-white text-xs px-2 py-1 rounded-full">
                        {columnSurgeries.length}
                      </span>
                      
                      {/* Urgent indicator */}
                      {columnSurgeries.some((surgery: any) => surgery.isUrgent) && (
                        <AlertTriangle className="w-4 h-4 text-red-400" />
                      )}
                    </div>
                  </div>
                  
                  <p className="text-gray-400 text-xs">
                    {column.description}
                  </p>
                </div>

                {/* Droppable Area */}
                <Droppable droppableId={column.id}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={`flex-1 space-y-3 p-2 rounded-xl transition-all duration-200 ${
                        snapshot.isDraggingOver 
                          ? 'bg-white bg-opacity-10 border-2 border-dashed border-purple-400' 
                          : 'border-2 border-transparent'
                      }`}
                    >
                      <AnimatePresence>
                        {columnSurgeries.map((surgery: any, index: number) => (
                          <Draggable
                            key={surgery.id}
                            draggableId={surgery.id}
                            index={index}
                          >
                            {(provided, snapshot) => (
                              <motion.div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.9 }}
                                className={`transform transition-transform duration-200 ${
                                  snapshot.isDragging 
                                    ? 'rotate-3 scale-105 z-50' 
                                    : 'hover:scale-102'
                                }`}
                              >
                                <SurgeryCard 
                                  surgery={surgery}
                                  isDragging={snapshot.isDragging}
                                />
                              </motion.div>
                            )}
                          </Draggable>
                        ))}
                      </AnimatePresence>
                      {provided.placeholder}

                      {/* Empty state */}
                      {columnSurgeries.length === 0 && (
                        <div className="glass-subtle p-4 text-center rounded-xl border-2 border-dashed border-gray-600">
                          <Icon className="w-8 h-8 text-gray-500 mx-auto mb-2" />
                          <p className="text-gray-500 text-sm">
                            Nenhuma cirurgia neste status
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </Droppable>
              </motion.div>
            );
          })}
        </div>
      </DragDropContext>

      {/* Legend */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-6 glass-card p-4"
      >
        <h4 className="text-white font-semibold mb-3">Legenda de Cores:</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full" />
            <span className="text-gray-300 text-sm">Pendente</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-orange-500 rounded-full" />
            <span className="text-gray-300 text-sm">Em Negociação</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-500 rounded-full" />
            <span className="text-gray-300 text-sm">Em Processamento</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full" />
            <span className="text-gray-300 text-sm">Concluído</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}