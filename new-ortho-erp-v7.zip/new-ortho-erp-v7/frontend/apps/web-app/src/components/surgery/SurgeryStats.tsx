'use client';

import { motion } from 'framer-motion';
import { 
  Activity, 
  Calendar, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  DollarSign,
  TrendingUp,
  TrendingDown 
} from 'lucide-react';

export function SurgeryStats() {
  // Mock data - in real app, this would come from API
  const stats = {
    total: 156,
    today: 8,
    urgent: 12,
    completed: 89,
    pending: 45,
    revenue: 2847350,
    avgTime: 180, // minutes
    successRate: 94.5
  };

  const statsCards = [
    {
      title: 'Total de Cirurgias',
      value: stats.total,
      icon: Activity,
      color: 'turquoise',
      trend: { value: '+12%', isUp: true },
      description: 'Este mês'
    },
    {
      title: 'Cirurgias Hoje',
      value: stats.today,
      icon: Calendar,
      color: 'blue',
      trend: { value: '+3', isUp: true },
      description: 'Agendadas para hoje'
    },
    {
      title: 'Urgências',
      value: stats.urgent,
      icon: AlertTriangle,
      color: 'red',
      trend: { value: '-2', isUp: false },
      description: 'Últimas 24h'
    },
    {
      title: 'Concluídas',
      value: stats.completed,
      icon: CheckCircle,
      color: 'green',
      trend: { value: '+8%', isUp: true },
      description: 'Este mês'
    },
    {
      title: 'Pendentes',
      value: stats.pending,
      icon: Clock,
      color: 'orange',
      trend: { value: '-5%', isUp: false },
      description: 'Aguardando autorização'
    },
    {
      title: 'Receita',
      value: `R$ ${(stats.revenue / 1000000).toFixed(1)}M`,
      icon: DollarSign,
      color: 'purple',
      trend: { value: '+16.04%', isUp: true },
      description: 'Este mês'
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap = {
      turquoise: {
        bg: 'bg-turquoise-500',
        text: 'text-turquoise-400',
        border: 'border-turquoise-500'
      },
      blue: {
        bg: 'bg-blue-500',
        text: 'text-blue-400',
        border: 'border-blue-500'
      },
      red: {
        bg: 'bg-red-500',
        text: 'text-red-400',
        border: 'border-red-500'
      },
      green: {
        bg: 'bg-green-500',
        text: 'text-green-400',
        border: 'border-green-500'
      },
      orange: {
        bg: 'bg-orange-500',
        text: 'text-orange-400',
        border: 'border-orange-500'
      },
      purple: {
        bg: 'bg-purple-500',
        text: 'text-purple-400',
        border: 'border-purple-500'
      }
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.turquoise;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {statsCards.map((stat, index) => {
        const colors = getColorClasses(stat.color);
        const Icon = stat.icon;
        const TrendIcon = stat.trend.isUp ? TrendingUp : TrendingDown;

        return (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass-card p-4 hover:bg-opacity-20 hover:scale-105 transition-all duration-300 cursor-pointer group"
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-3">
              <div className={`p-2 rounded-xl ${colors.bg} bg-opacity-20`}>
                <Icon className={`w-5 h-5 ${colors.text}`} />
              </div>
              
              <div className={`flex items-center space-x-1 text-xs ${
                stat.trend.isUp ? 'text-green-400' : 'text-red-400'
              }`}>
                <TrendIcon className="w-3 h-3" />
                <span>{stat.trend.value}</span>
              </div>
            </div>

            {/* Value */}
            <div className="mb-2">
              <div className="text-2xl font-bold text-white group-hover:text-opacity-90">
                {stat.value}
              </div>
              <div className="text-sm text-gray-400">
                {stat.title}
              </div>
            </div>

            {/* Description */}
            <div className="text-xs text-gray-500">
              {stat.description}
            </div>

            {/* Progress bar for some stats */}
            {(stat.title === 'Concluídas' || stat.title === 'Pendentes') && (
              <div className="mt-3">
                <div className="w-full bg-gray-700 rounded-full h-1">
                  <div 
                    className={`h-1 rounded-full ${colors.bg} bg-opacity-60 transition-all duration-1000`}
                    style={{ 
                      width: `${stat.title === 'Concluídas' 
                        ? (stats.completed / stats.total * 100) 
                        : (stats.pending / stats.total * 100)
                      }%` 
                    }}
                  />
                </div>
              </div>
            )}
          </motion.div>
        );
      })}

      {/* Quick Actions Panel */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="xl:col-span-6 glass-card p-4 mt-4"
      >
        <h4 className="text-white font-semibold mb-3 flex items-center space-x-2">
          <Activity className="w-5 h-5 text-turquoise-400" />
          <span>Resumo Operacional</span>
        </h4>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div className="text-center">
            <div className="text-turquoise-400 font-semibold">
              {stats.successRate}%
            </div>
            <div className="text-gray-400">Taxa de Sucesso</div>
          </div>
          
          <div className="text-center">
            <div className="text-purple-400 font-semibold">
              {Math.floor(stats.avgTime / 60)}h {stats.avgTime % 60}m
            </div>
            <div className="text-gray-400">Tempo Médio</div>
          </div>
          
          <div className="text-center">
            <div className="text-orange-400 font-semibold">
              {Math.round((stats.pending / stats.total) * 100)}%
            </div>
            <div className="text-gray-400">Pendentes</div>
          </div>
          
          <div className="text-center">
            <div className="text-green-400 font-semibold">
              R$ {(stats.revenue / stats.completed).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-gray-400">Ticket Médio</div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}