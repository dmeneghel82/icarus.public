'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  User, 
  Hospital, 
  Calendar, 
  Clock, 
  AlertTriangle, 
  FileText, 
  DollarSign,
  Eye,
  Edit,
  Container,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { formatCurrency, formatDate, formatTime } from '@/utils/format';

interface SurgeryCardProps {
  surgery: any;
  isDragging?: boolean;
}

export function SurgeryCard({ surgery, isDragging }: SurgeryCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  const getUrgencyColor = () => {
    return surgery.isUrgent ? 'border-red-400 bg-red-500 bg-opacity-10' : 'border-gray-600';
  };

  const getStatusColor = (status: string) => {
    const statusColors = {
      'MEDICAL_REQUEST': 'text-orange-400',
      'PRICE_TABLE': 'text-blue-400',
      'QUOTATION': 'text-purple-400',
      'ANALYSIS': 'text-yellow-400',
      'PRE_AUTHORIZATION': 'text-green-400',
      'SCHEDULED': 'text-turquoise-400',
      'LOGISTICS': 'text-indigo-400',
      'IN_SURGERY': 'text-red-400',
      'REVERSE_LOGISTICS': 'text-orange-300',
      'POST_SURGERY': 'text-teal-400',
      'POST_QUOTATION': 'text-purple-300',
      'BILLING_AUTH': 'text-green-300',
      'BILLING': 'text-emerald-400',
      'COMPLETED': 'text-green-500',
      'CANCELLED': 'text-red-500'
    };
    return statusColors[status as keyof typeof statusColors] || 'text-gray-400';
  };

  const getBillingTypeColor = (type: string) => {
    return type === 'PARTIAL' ? 'text-yellow-400' : 'text-green-400';
  };

  return (
    <motion.div
      layout
      className={`glass-card p-4 cursor-pointer transition-all duration-200 hover:bg-opacity-20 ${
        getUrgencyColor()
      } ${isDragging ? 'shadow-2xl ring-2 ring-purple-400' : ''}`}
      whileHover={{ y: -2 }}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-2">
          {surgery.isUrgent && (
            <div className="flex items-center space-x-1 bg-red-500 bg-opacity-20 px-2 py-1 rounded-full">
              <AlertTriangle className="w-3 h-3 text-red-400" />
              <span className="text-red-400 text-xs font-medium">URGÊNCIA</span>
            </div>
          )}
          
          <span className="text-gray-400 text-sm font-mono">
            #{surgery.code.slice(-6)}
          </span>
        </div>

        <div className="flex items-center space-x-1">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={(e) => {
              e.stopPropagation();
              setShowDetails(!showDetails);
            }}
            className="p-1 rounded-full hover:bg-white hover:bg-opacity-10"
          >
            <Eye className="w-4 h-4 text-gray-400" />
          </motion.button>
        </div>
      </div>

      {/* Patient Info */}
      <div className="mb-3">
        <div className="flex items-center space-x-2 mb-1">
          <User className="w-4 h-4 text-turquoise-400" />
          <span className="text-white font-medium text-sm">
            {surgery.patient?.name || 'Paciente não informado'}
          </span>
        </div>
        
        {surgery.patient?.insurance && (
          <div className="text-gray-400 text-xs ml-6">
            {surgery.patient.insurance} • {surgery.patient.insuranceNumber}
          </div>
        )}
      </div>

      {/* Doctor and Hospital */}
      <div className="space-y-2 mb-3">
        <div className="flex items-center space-x-2">
          <User className="w-4 h-4 text-purple-400" />
          <span className="text-gray-300 text-sm">
            {surgery.doctor?.name || 'Médico não informado'}
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <Hospital className="w-4 h-4 text-blue-400" />
          <span className="text-gray-300 text-sm">
            {surgery.hospital?.name || 'Hospital não informado'}
          </span>
        </div>
      </div>

      {/* Procedure */}
      <div className="mb-3">
        <div className="text-white text-sm font-medium">
          {surgery.procedure || 'Procedimento não especificado'}
        </div>
        <div className="text-gray-400 text-xs">
          {surgery.specialty}
        </div>
      </div>

      {/* Schedule Info */}
      {surgery.scheduledAt && (
        <div className="flex items-center space-x-4 mb-3 text-xs">
          <div className="flex items-center space-x-1">
            <Calendar className="w-3 h-3 text-turquoise-400" />
            <span className="text-gray-300">
              {formatDate(surgery.scheduledAt)}
            </span>
          </div>
          
          <div className="flex items-center space-x-1">
            <Clock className="w-3 h-3 text-turquoise-400" />
            <span className="text-gray-300">
              {formatTime(surgery.scheduledAt)}
            </span>
          </div>
        </div>
      )}

      {/* Financial Info */}
      {surgery.totalValue && (
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-1">
            <DollarSign className="w-4 h-4 text-green-400" />
            <span className="text-green-400 text-sm font-medium">
              {formatCurrency(surgery.totalValue)}
            </span>
          </div>

          {surgery.billingType && (
            <div className={`text-xs px-2 py-1 rounded-full bg-opacity-20 ${
              surgery.billingType === 'PARTIAL' 
                ? 'bg-yellow-500 text-yellow-300' 
                : 'bg-green-500 text-green-300'
            }`}>
              {surgery.billingType === 'PARTIAL' ? 'Parcial' : 'Total'}
            </div>
          )}
        </div>
      )}

      {/* Container Info */}
      {surgery.containerUsed && (
        <div className="flex items-center space-x-2 mb-3">
          <Container className="w-4 h-4 text-indigo-400" />
          <span className="text-indigo-400 text-sm">
            Container: {surgery.containerUsed}
          </span>
        </div>
      )}

      {/* Status Indicator */}
      <div className="flex items-center justify-between">
        <div className={`text-xs font-medium ${getStatusColor(surgery.status)}`}>
          {surgery.status.replace('_', ' ').toLowerCase()}
        </div>

        {/* Authorizations */}
        <div className="flex items-center space-x-1">
          {surgery.authorizationFile && (
            <CheckCircle className="w-3 h-3 text-green-400" title="Autorização OK" />
          )}
          
          {surgery.medicalRequestFile && (
            <FileText className="w-3 h-3 text-blue-400" title="Pedido Médico" />
          )}
        </div>
      </div>

      {/* Expandable Details */}
      {showDetails && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="mt-3 pt-3 border-t border-white border-opacity-10"
        >
          {/* Materials */}
          {surgery.materials && surgery.materials.length > 0 && (
            <div className="mb-2">
              <div className="text-xs text-gray-400 mb-1">
                Materiais ({surgery.materials.length}):
              </div>
              <div className="text-xs text-gray-300">
                {surgery.materials.slice(0, 3).map((material: any, index: number) => (
                  <div key={index}>• {material.name || material.product?.name}</div>
                ))}
                {surgery.materials.length > 3 && (
                  <div className="text-gray-500">
                    +{surgery.materials.length - 3} mais...
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Observations */}
          {surgery.observations && (
            <div className="mb-2">
              <div className="text-xs text-gray-400 mb-1">Observações:</div>
              <div className="text-xs text-gray-300">
                {surgery.observations.length > 100 
                  ? surgery.observations.substring(0, 100) + '...'
                  : surgery.observations
                }
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-2 mt-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="text-xs bg-purple-500 bg-opacity-20 text-purple-300 px-3 py-1 rounded-full hover:bg-opacity-30 transition-all"
            >
              Ver Detalhes
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="text-xs bg-turquoise-500 bg-opacity-20 text-turquoise-300 px-3 py-1 rounded-full hover:bg-opacity-30 transition-all"
            >
              Editar
            </motion.button>
          </div>
        </motion.div>
      )}

      {/* Toggle Button (Urgência) */}
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className={`w-8 h-4 rounded-full transition-all duration-200 flex items-center ${
            surgery.isUrgent 
              ? 'bg-red-500 justify-end' 
              : 'bg-gray-600 justify-start'
          }`}
          title={surgery.isUrgent ? 'Cirurgia de Urgência' : 'Cirurgia Eletiva'}
        >
          <div className={`w-3 h-3 bg-white rounded-full transition-all duration-200 mx-0.5`} />
        </motion.button>
      </div>
    </motion.div>
  );
}