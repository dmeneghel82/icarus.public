# NEW ORTHO ERP v7 - Production Deployment Guide

## 🚀 Overview

NEW ORTHO ERP v7 is an enterprise-grade OPME (Órteses, Próteses e Materiais Especiais) distribution system designed for the Brazilian healthcare market. This guide provides comprehensive instructions for deploying the system to production using Kubernetes.

## 📋 Prerequisites

### Infrastructure Requirements

| Component | Minimum | Recommended | Notes |
|-----------|---------|-------------|-------|
| **Kubernetes Cluster** | v1.28+ | v1.29+ | EKS, GKE, or AKS |
| **Nodes** | 6 nodes | 12 nodes | Mixed instance types |
| **vCPUs** | 24 cores | 48 cores | Across all nodes |
| **RAM** | 96GB | 192GB | Across all nodes |
| **Storage** | 2TB SSD | 5TB SSD | High IOPS required |
| **Network** | 10Gbps | 25Gbps | Low latency |

### Node Requirements

```yaml
# Node Groups
monitoring:
  instance_type: m5.2xlarge
  min_nodes: 3
  max_nodes: 6

compute:
  instance_type: c5.2xlarge  
  min_nodes: 3
  max_nodes: 12

database:
  instance_type: r5.2xlarge
  min_nodes: 3
  max_nodes: 6

gpu:
  instance_type: p3.2xlarge
  min_nodes: 2
  max_nodes: 4
```

### External Services

- **Domain**: `new-ortho.com.br` with SSL certificates
- **S3 Bucket**: For backups and static assets
- **CDN**: CloudFront or similar
- **DNS**: Route53 or equivalent
- **Email**: SMTP service for notifications

## 🔧 Installation Steps

### Step 1: Cluster Preparation

```bash
# Create namespaces
kubectl apply -f deployment/kubernetes/namespace.yaml

# Install operators
kubectl apply -f https://github.com/cloudnative-pg/cloudnative-pg/releases/latest/download/cnpg-1.20.2.yaml
kubectl apply -f https://github.com/elastic/cloud-on-k8s/releases/download/2.9.0/crds.yaml
kubectl apply -f https://github.com/elastic/cloud-on-k8s/releases/download/2.9.0/operator.yaml

# Install Prometheus Operator
kubectl apply -f https://github.com/prometheus-operator/prometheus-operator/releases/download/v0.68.0/bundle.yaml

# Install Jaeger Operator
kubectl create namespace observability-system
kubectl apply -f https://github.com/jaegertracing/jaeger-operator/releases/download/v1.49.0/jaeger-operator.yaml -n observability-system
```

### Step 2: Security Configuration

```bash
# Apply security policies
kubectl apply -f deployment/kubernetes/security/

# Verify policy enforcement
kubectl get networkpolicies --all-namespaces
kubectl get podsecuritypolicies
```

### Step 3: Storage and Database

```bash
# Deploy PostgreSQL cluster
kubectl apply -f deployment/kubernetes/databases/postgres-cluster.yaml

# Wait for database to be ready
kubectl wait --for=condition=ready cluster/postgres-cluster -n new-ortho-erp --timeout=600s

# Verify database cluster
kubectl get clusters.postgresql.cnpg.io -n new-ortho-erp
```

### Step 4: Performance Layer

```bash
# Deploy Redis cluster
kubectl apply -f deployment/kubernetes/performance/redis-cluster.yaml

# Setup Redis cluster
kubectl wait --for=condition=ready pod -l app=redis -n new-ortho-erp --timeout=300s

# Deploy performance optimizations
kubectl apply -f deployment/kubernetes/performance/
```

### Step 5: Application Secrets

Create required secrets:

```bash
# Database secrets
kubectl create secret generic new-ortho-database-secret \
  --from-literal=DATABASE_URL="postgresql://user:password@postgres-cluster-primary:5432/new_ortho_erp_prod" \
  --from-literal=DATABASE_USER="new_ortho_user" \
  --from-literal=DATABASE_PASSWORD="$(openssl rand -base64 32)" \
  -n new-ortho-erp

# Application secrets
kubectl create secret generic new-ortho-jwt-secret \
  --from-literal=JWT_SECRET="$(openssl rand -base64 64)" \
  --from-literal=JWT_REFRESH_SECRET="$(openssl rand -base64 64)" \
  -n new-ortho-erp

# Government API secrets
kubectl create secret generic new-ortho-government-api-secret \
  --from-literal=SISCOMEX_CLIENT_ID="your_siscomex_client_id" \
  --from-literal=SISCOMEX_CLIENT_SECRET="your_siscomex_secret" \
  --from-literal=SEFAZ_CLIENT_ID="your_sefaz_client_id" \
  --from-literal=SEFAZ_CLIENT_SECRET="your_sefaz_secret" \
  --from-literal=ANVISA_API_KEY="your_anvisa_api_key" \
  -n new-ortho-erp

# AI secrets
kubectl create secret generic new-ortho-ai-secret \
  --from-literal=AI_ORCHESTRATOR_SECRET="$(openssl rand -base64 32)" \
  --from-literal=TENSORFLOW_SECRET="$(openssl rand -base64 32)" \
  --from-literal=MODEL_ENCRYPTION_KEY="$(openssl rand -base64 32)" \
  -n new-ortho-ai

# Storage secrets
kubectl create secret generic new-ortho-storage-secret \
  --from-literal=AWS_ACCESS_KEY_ID="your_aws_access_key" \
  --from-literal=AWS_SECRET_ACCESS_KEY="your_aws_secret_key" \
  -n new-ortho-erp
```

### Step 6: Configuration

```bash
# Apply configuration maps
kubectl apply -f deployment/kubernetes/configmaps/

# Verify configurations
kubectl get configmaps -n new-ortho-erp
kubectl get configmaps -n new-ortho-ai
```

### Step 7: Core Applications

```bash
# Deploy backend services
kubectl apply -f deployment/kubernetes/deployments/backend-deployment.yaml

# Deploy AI services
kubectl apply -f deployment/kubernetes/deployments/ai-orchestrator-deployment.yaml

# Wait for deployments
kubectl wait --for=condition=available deployment --all -n new-ortho-erp --timeout=600s
kubectl wait --for=condition=available deployment --all -n new-ortho-ai --timeout=600s
```

### Step 8: Load Balancing

```bash
# Deploy NGINX Ingress
kubectl apply -f deployment/kubernetes/ingress/nginx-ingress.yaml

# Configure ingress rules
kubectl apply -f deployment/kubernetes/ingress/app-ingress.yaml

# Verify ingress
kubectl get ingress --all-namespaces
```

### Step 9: Monitoring Stack

```bash
# Deploy Prometheus
kubectl apply -f deployment/kubernetes/monitoring/prometheus.yaml

# Deploy Grafana
kubectl apply -f deployment/kubernetes/monitoring/grafana.yaml

# Wait for monitoring stack
kubectl wait --for=condition=available deployment --all -n new-ortho-monitoring --timeout=600s
```

### Step 10: Logging and Tracing

```bash
# Deploy Elasticsearch
kubectl apply -f deployment/kubernetes/logging/elasticsearch-cluster.yaml

# Deploy Fluentd
kubectl apply -f deployment/kubernetes/logging/fluentd-config.yaml

# Deploy Jaeger
kubectl apply -f deployment/kubernetes/logging/jaeger-tracing.yaml
```

### Step 11: Backup and Disaster Recovery

```bash
# Deploy Velero
kubectl apply -f deployment/kubernetes/disaster-recovery/velero-backup.yaml

# Create initial backup
velero backup create initial-production-backup \
  --include-namespaces new-ortho-erp,new-ortho-ai,new-ortho-monitoring \
  --wait
```

## 🔍 Verification Steps

### Health Checks

```bash
# Check all pods
kubectl get pods --all-namespaces | grep -E "(Error|CrashLoopBackOff|ImagePullBackOff)"

# Check services
kubectl get services --all-namespaces

# Check ingress
kubectl get ingress --all-namespaces

# Test endpoints
curl -k https://api.new-ortho.com.br/health
curl -k https://app.new-ortho.com.br/
curl -k https://monitoring.new-ortho.com.br/
```

### Database Verification

```bash
# Check PostgreSQL cluster
kubectl get clusters.postgresql.cnpg.io -n new-ortho-erp

# Test database connection
kubectl exec -it postgres-cluster-1 -n new-ortho-erp -- \
  psql -U new_ortho_user -d new_ortho_erp_prod -c "SELECT version();"
```

### AI Services Verification

```bash
# Check AI orchestrator
kubectl exec -n new-ortho-ai deployment/ai-orchestrator-deployment -- \
  curl -s http://localhost:8010/health

# Verify AI models
kubectl exec -n new-ortho-ai deployment/ai-orchestrator-deployment -- \
  ls -la /app/models/
```

### Monitoring Verification

```bash
# Check Prometheus targets
kubectl port-forward -n new-ortho-monitoring svc/prometheus 9090:9090 &
curl -s http://localhost:9090/api/v1/targets | jq '.data.activeTargets[].health'

# Check Grafana
kubectl port-forward -n new-ortho-monitoring svc/grafana 3000:3000 &
curl -s http://localhost:3000/api/health
```

## 📊 Performance Tuning

### Database Optimization

```sql
-- Connect to PostgreSQL and run optimization queries
\c new_ortho_erp_prod

-- Update statistics
ANALYZE;

-- Check slow queries
SELECT query, mean_time, calls 
FROM pg_stat_statements 
WHERE mean_time > 1000 
ORDER BY mean_time DESC 
LIMIT 10;

-- Refresh materialized views
SELECT refresh_materialized_views();
```

### Redis Performance

```bash
# Check Redis cluster status
kubectl exec -n new-ortho-erp redis-cluster-0 -- redis-cli cluster nodes

# Monitor Redis metrics
kubectl exec -n new-ortho-erp redis-cluster-0 -- redis-cli info memory
```

### Application Performance

```bash
# Scale based on load
kubectl scale deployment backend-deployment --replicas=10 -n new-ortho-erp
kubectl scale deployment ai-orchestrator-deployment --replicas=5 -n new-ortho-ai

# Check HPA status
kubectl get hpa --all-namespaces
```

## 🔒 Security Hardening

### Network Security

```bash
# Verify network policies
kubectl get networkpolicies --all-namespaces

# Test network isolation
kubectl run test-pod --rm -i --tty --image=busybox -- /bin/sh
```

### Pod Security

```bash
# Check pod security policies
kubectl get podsecuritypolicies

# Verify security contexts
kubectl get pods -o jsonpath='{.items[*].spec.securityContext}' --all-namespaces
```

### RBAC Verification

```bash
# Check service accounts
kubectl get serviceaccounts --all-namespaces

# Verify permissions
kubectl auth can-i list pods --as=system:serviceaccount:new-ortho-erp:new-ortho-service-account
```

## 📈 Monitoring and Alerting

### Grafana Dashboards

Access Grafana at `https://monitoring.new-ortho.com.br` with:
- Username: `admin`
- Password: Check secret `grafana-admin-password`

Available dashboards:
- **System Overview**: Overall system health
- **AI Monitoring**: AI models performance
- **Business Metrics**: Revenue, surgeries, success rates

### Prometheus Alerts

Key alerts configured:
- High error rate (>5%)
- High response time (>2s)
- Database connection issues
- AI model accuracy below 80%
- Memory usage >90%
- CPU usage >90%

### Log Analysis

Access Kibana for log analysis:
- URL: `https://monitoring.new-ortho.com.br/`
- Logs are indexed by service and severity
- Automatic LGPD/GDPR compliance filtering

## 🔄 Backup and Recovery

### Automated Backups

- **Database**: Continuous WAL archiving + daily full backups
- **Kubernetes**: Daily Velero backups
- **Application Data**: Hourly snapshots

### Recovery Procedures

```bash
# List available backups
velero backup get

# Restore from backup
velero restore create restore-$(date +%Y%m%d) \
  --from-backup BACKUP_NAME \
  --wait

# Database point-in-time recovery
# See disaster-recovery/restore-playbook.yaml for detailed procedures
```

## 🚀 Scaling Guidelines

### Horizontal Scaling

```bash
# Scale backend
kubectl scale deployment backend-deployment --replicas=15 -n new-ortho-erp

# Scale AI services
kubectl scale deployment ai-orchestrator-deployment --replicas=8 -n new-ortho-ai

# Scale databases (add replicas)
kubectl patch cluster postgres-cluster -n new-ortho-erp \
  --type merge --patch '{"spec":{"instances":5}}'
```

### Vertical Scaling

Update resource limits in deployment files:

```yaml
resources:
  requests:
    memory: "1Gi"
    cpu: "1000m"
  limits:
    memory: "4Gi"
    cpu: "4000m"
```

### Auto-scaling

HPA is configured for:
- **Backend**: 3-20 replicas based on CPU/memory/requests
- **AI Orchestrator**: 2-5 replicas based on predictions/sec
- **Redis**: 6-12 nodes based on memory usage

## 🔧 Troubleshooting

### Common Issues

1. **Pod Crashes**
   ```bash
   kubectl logs -f POD_NAME -n NAMESPACE
   kubectl describe pod POD_NAME -n NAMESPACE
   ```

2. **Database Connection Issues**
   ```bash
   kubectl get clusters.postgresql.cnpg.io -n new-ortho-erp
   kubectl logs -f postgres-cluster-1 -n new-ortho-erp
   ```

3. **AI Models Not Loading**
   ```bash
   kubectl exec -n new-ortho-ai deployment/ai-orchestrator-deployment -- \
     ls -la /app/models/
   kubectl logs -f deployment/ai-orchestrator-deployment -n new-ortho-ai
   ```

4. **Ingress Issues**
   ```bash
   kubectl describe ingress -n new-ortho-erp
   kubectl logs -f deployment/nginx-ingress-controller -n ingress-nginx
   ```

### Performance Issues

1. **High Response Times**
   - Check database query performance
   - Scale backend replicas
   - Review Redis cache hit rates

2. **Memory Issues**
   - Increase node memory
   - Optimize container limits
   - Check for memory leaks

3. **AI Performance**
   - Verify GPU allocation
   - Check model accuracy metrics
   - Scale AI orchestrator

## 📞 Support and Maintenance

### Contact Information

- **Primary Engineer**: daxmeneghel@new-ortho.com.br
- **DevOps Team**: devops@new-ortho.com.br
- **24/7 Emergency**: +55 11 99999-9999

### Maintenance Schedule

- **Daily**: Automated backups, log rotation
- **Weekly**: Database optimization, security scans
- **Monthly**: Disaster recovery tests, performance reviews
- **Quarterly**: Full security audit, capacity planning

### Update Procedures

1. Test updates in staging environment
2. Create backup before deployment
3. Deploy during maintenance window
4. Verify all services post-deployment
5. Monitor for 24 hours after deployment

## 📚 Additional Resources

- [NEW ORTHO API Documentation](https://docs.new-ortho.com.br)
- [Kubernetes Best Practices](https://kubernetes.io/docs/concepts/)
- [PostgreSQL Tuning Guide](https://wiki.postgresql.org/wiki/Performance_Optimization)
- [Disaster Recovery Playbook](deployment/kubernetes/disaster-recovery/restore-playbook.yaml)

---

## 🎯 Success Metrics

After successful deployment, monitor these KPIs:

- **Uptime**: >99.9%
- **Response Time**: <2s (95th percentile)
- **Error Rate**: <0.1%
- **AI Accuracy**: >90% average
- **Database Connections**: <80% capacity
- **Memory Usage**: <85% average
- **CPU Usage**: <75% average

## 📝 Deployment Checklist

- [ ] Infrastructure provisioned
- [ ] DNS configured
- [ ] SSL certificates installed
- [ ] Secrets created
- [ ] Database cluster deployed
- [ ] Redis cluster configured
- [ ] Applications deployed
- [ ] Ingress configured
- [ ] Monitoring stack active
- [ ] Logging configured
- [ ] Backups scheduled
- [ ] Security policies applied
- [ ] Performance optimizations enabled
- [ ] Load testing completed
- [ ] Documentation updated
- [ ] Team trained
- [ ] Go-live approval obtained

---

**NEW ORTHO ERP v7** - Enterprise Medical Device Distribution System  
© 2025 NEW ORTHO. All rights reserved.