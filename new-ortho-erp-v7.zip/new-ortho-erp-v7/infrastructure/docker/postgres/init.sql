-- NEW ORTHO ERP v7 Database Initialization
-- This script sets up the initial database structure and data

-- Create database if not exists (handled by Docker)
-- CREATE DATABASE IF NOT EXISTS new_ortho_erp;

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Create schemas for better organization
CREATE SCHEMA IF NOT EXISTS auth;
CREATE SCHEMA IF NOT EXISTS core;
CREATE SCHEMA IF NOT EXISTS inventory;
CREATE SCHEMA IF NOT EXISTS financial;
CREATE SCHEMA IF NOT EXISTS audit;

-- Set search path
SET search_path = public, auth, core, inventory, financial, audit;

-- ======================
-- INITIAL ROLES AND PERMISSIONS
-- ======================

-- Insert default roles
INSERT INTO roles (id, name, description, is_active, created_at, updated_at) 
VALUES 
    ('role_admin_001', 'ADMIN', 'System Administrator with full access', true, NOW(), NOW()),
    ('role_manager_001', 'MANAGER', 'Department Manager with extended permissions', true, NOW(), NOW()),
    ('role_user_001', 'USER', 'Regular user with standard permissions', true, NOW(), NOW()),
    ('role_doctor_001', 'DOCTOR', 'Medical doctor with surgery-related permissions', true, NOW(), NOW()),
    ('role_tech_001', 'TECHNICIAN', 'Technical staff with inventory permissions', true, NOW(), NOW()),
    ('role_financial_001', 'FINANCIAL', 'Financial team with accounting permissions', true, NOW(), NOW()),
    ('role_sales_001', 'SALES', 'Sales team with CRM permissions', true, NOW(), NOW()),
    ('role_procurement_001', 'PROCUREMENT', 'Procurement team with purchasing permissions', true, NOW(), NOW())
ON CONFLICT (id) DO NOTHING;

-- Insert default permissions
INSERT INTO permissions (id, name, description, resource, action, created_at) 
VALUES 
    -- User Management
    ('perm_user_create', 'users.create', 'Create new users', 'users', 'create', NOW()),
    ('perm_user_read', 'users.read', 'View user information', 'users', 'read', NOW()),
    ('perm_user_update', 'users.update', 'Update user information', 'users', 'update', NOW()),
    ('perm_user_delete', 'users.delete', 'Delete users', 'users', 'delete', NOW()),
    
    -- Surgery Management
    ('perm_surgery_create', 'surgeries.create', 'Schedule surgeries', 'surgeries', 'create', NOW()),
    ('perm_surgery_read', 'surgeries.read', 'View surgery information', 'surgeries', 'read', NOW()),
    ('perm_surgery_update', 'surgeries.update', 'Update surgery details', 'surgeries', 'update', NOW()),
    ('perm_surgery_delete', 'surgeries.delete', 'Cancel surgeries', 'surgeries', 'delete', NOW()),
    
    -- Inventory Management
    ('perm_inventory_create', 'inventory.create', 'Add inventory items', 'inventory', 'create', NOW()),
    ('perm_inventory_read', 'inventory.read', 'View inventory information', 'inventory', 'read', NOW()),
    ('perm_inventory_update', 'inventory.update', 'Update inventory', 'inventory', 'update', NOW()),
    ('perm_inventory_delete', 'inventory.delete', 'Remove inventory items', 'inventory', 'delete', NOW()),
    
    -- Financial Management
    ('perm_financial_create', 'financial.create', 'Create financial records', 'financial', 'create', NOW()),
    ('perm_financial_read', 'financial.read', 'View financial information', 'financial', 'read', NOW()),
    ('perm_financial_update', 'financial.update', 'Update financial records', 'financial', 'update', NOW()),
    ('perm_financial_delete', 'financial.delete', 'Delete financial records', 'financial', 'delete', NOW()),
    
    -- Dashboard and Reports
    ('perm_dashboard_read', 'dashboard.read', 'View dashboard', 'dashboard', 'read', NOW()),
    ('perm_reports_read', 'reports.read', 'View reports', 'reports', 'read', NOW()),
    ('perm_reports_create', 'reports.create', 'Generate reports', 'reports', 'create', NOW())
ON CONFLICT (id) DO NOTHING;

-- Assign permissions to roles
INSERT INTO role_permissions (id, role_id, permission_id, created_at) 
VALUES 
    -- ADMIN: Full permissions
    ('rp_admin_001', 'role_admin_001', 'perm_user_create', NOW()),
    ('rp_admin_002', 'role_admin_001', 'perm_user_read', NOW()),
    ('rp_admin_003', 'role_admin_001', 'perm_user_update', NOW()),
    ('rp_admin_004', 'role_admin_001', 'perm_user_delete', NOW()),
    ('rp_admin_005', 'role_admin_001', 'perm_surgery_create', NOW()),
    ('rp_admin_006', 'role_admin_001', 'perm_surgery_read', NOW()),
    ('rp_admin_007', 'role_admin_001', 'perm_surgery_update', NOW()),
    ('rp_admin_008', 'role_admin_001', 'perm_surgery_delete', NOW()),
    ('rp_admin_009', 'role_admin_001', 'perm_inventory_create', NOW()),
    ('rp_admin_010', 'role_admin_001', 'perm_inventory_read', NOW()),
    ('rp_admin_011', 'role_admin_001', 'perm_inventory_update', NOW()),
    ('rp_admin_012', 'role_admin_001', 'perm_inventory_delete', NOW()),
    ('rp_admin_013', 'role_admin_001', 'perm_financial_create', NOW()),
    ('rp_admin_014', 'role_admin_001', 'perm_financial_read', NOW()),
    ('rp_admin_015', 'role_admin_001', 'perm_financial_update', NOW()),
    ('rp_admin_016', 'role_admin_001', 'perm_financial_delete', NOW()),
    ('rp_admin_017', 'role_admin_001', 'perm_dashboard_read', NOW()),
    ('rp_admin_018', 'role_admin_001', 'perm_reports_read', NOW()),
    ('rp_admin_019', 'role_admin_001', 'perm_reports_create', NOW()),
    
    -- DOCTOR: Surgery-focused permissions
    ('rp_doctor_001', 'role_doctor_001', 'perm_surgery_create', NOW()),
    ('rp_doctor_002', 'role_doctor_001', 'perm_surgery_read', NOW()),
    ('rp_doctor_003', 'role_doctor_001', 'perm_surgery_update', NOW()),
    ('rp_doctor_004', 'role_doctor_001', 'perm_inventory_read', NOW()),
    ('rp_doctor_005', 'role_doctor_001', 'perm_dashboard_read', NOW()),
    
    -- TECHNICIAN: Inventory permissions
    ('rp_tech_001', 'role_tech_001', 'perm_inventory_create', NOW()),
    ('rp_tech_002', 'role_tech_001', 'perm_inventory_read', NOW()),
    ('rp_tech_003', 'role_tech_001', 'perm_inventory_update', NOW()),
    ('rp_tech_004', 'role_tech_001', 'perm_surgery_read', NOW()),
    ('rp_tech_005', 'role_tech_001', 'perm_dashboard_read', NOW()),
    
    -- USER: Basic permissions
    ('rp_user_001', 'role_user_001', 'perm_surgery_read', NOW()),
    ('rp_user_002', 'role_user_001', 'perm_inventory_read', NOW()),
    ('rp_user_003', 'role_user_001', 'perm_dashboard_read', NOW())
ON CONFLICT (id) DO NOTHING;

-- ======================
-- DEFAULT ADMIN USER
-- ======================

-- Create default admin user (password: Admin@2025!)
-- Password hash for 'Admin@2025!' using bcrypt with 12 rounds
INSERT INTO users (
    id, 
    email, 
    password, 
    first_name, 
    last_name, 
    role, 
    department, 
    is_active, 
    email_verified, 
    email_verified_at, 
    created_at, 
    updated_at
) VALUES (
    'user_admin_001',
    'admin@neworth.com',
    '$2b$12$LQv3c1yqBw2YXv5jGRW7Xu7oPJTy4eKW8KF8.Nz7Sv5sYgK5pYzWO', -- Admin@2025!
    'System',
    'Administrator',
    'ADMIN',
    'IT',
    true,
    true,
    NOW(),
    NOW(),
    NOW()
) ON CONFLICT (email) DO NOTHING;

-- Assign admin role to admin user
INSERT INTO user_role_assignments (id, user_id, role_id, assigned_at) 
VALUES (
    'ura_admin_001',
    'user_admin_001',
    'role_admin_001',
    NOW()
) ON CONFLICT (user_id, role_id) DO NOTHING;

-- ======================
-- DEFAULT CHART OF ACCOUNTS
-- ======================

INSERT INTO accounts (id, code, name, type, parent_id, is_active, created_at, updated_at) 
VALUES 
    -- Assets (Ativos)
    ('acc_1000', '1.000', 'ATIVO', 'ASSET', NULL, true, NOW(), NOW()),
    ('acc_1100', '1.100', 'ATIVO CIRCULANTE', 'ASSET', 'acc_1000', true, NOW(), NOW()),
    ('acc_1110', '1.110', 'Caixa e Equivalentes', 'ASSET', 'acc_1100', true, NOW(), NOW()),
    ('acc_1120', '1.120', 'Contas a Receber', 'ASSET', 'acc_1100', true, NOW(), NOW()),
    ('acc_1130', '1.130', 'Estoques OPME', 'ASSET', 'acc_1100', true, NOW(), NOW()),
    ('acc_1200', '1.200', 'ATIVO NÃO CIRCULANTE', 'ASSET', 'acc_1000', true, NOW(), NOW()),
    ('acc_1210', '1.210', 'Imobilizado', 'ASSET', 'acc_1200', true, NOW(), NOW()),
    
    -- Liabilities (Passivos)
    ('acc_2000', '2.000', 'PASSIVO', 'LIABILITY', NULL, true, NOW(), NOW()),
    ('acc_2100', '2.100', 'PASSIVO CIRCULANTE', 'LIABILITY', 'acc_2000', true, NOW(), NOW()),
    ('acc_2110', '2.110', 'Fornecedores', 'LIABILITY', 'acc_2100', true, NOW(), NOW()),
    ('acc_2120', '2.120', 'Contas a Pagar', 'LIABILITY', 'acc_2100', true, NOW(), NOW()),
    ('acc_2130', '2.130', 'Impostos a Recolher', 'LIABILITY', 'acc_2100', true, NOW(), NOW()),
    
    -- Equity (Patrimônio Líquido)
    ('acc_3000', '3.000', 'PATRIMÔNIO LÍQUIDO', 'EQUITY', NULL, true, NOW(), NOW()),
    ('acc_3100', '3.100', 'Capital Social', 'EQUITY', 'acc_3000', true, NOW(), NOW()),
    ('acc_3200', '3.200', 'Lucros Acumulados', 'EQUITY', 'acc_3000', true, NOW(), NOW()),
    
    -- Revenue (Receitas)
    ('acc_4000', '4.000', 'RECEITAS', 'REVENUE', NULL, true, NOW(), NOW()),
    ('acc_4100', '4.100', 'Receita de Vendas OPME', 'REVENUE', 'acc_4000', true, NOW(), NOW()),
    ('acc_4200', '4.200', 'Receita de Serviços', 'REVENUE', 'acc_4000', true, NOW(), NOW()),
    
    -- Expenses (Despesas)
    ('acc_5000', '5.000', 'DESPESAS', 'EXPENSE', NULL, true, NOW(), NOW()),
    ('acc_5100', '5.100', 'Custos dos Produtos Vendidos', 'EXPENSE', 'acc_5000', true, NOW(), NOW()),
    ('acc_5200', '5.200', 'Despesas Operacionais', 'EXPENSE', 'acc_5000', true, NOW(), NOW()),
    ('acc_5300', '5.300', 'Despesas Administrativas', 'EXPENSE', 'acc_5000', true, NOW(), NOW())
ON CONFLICT (id) DO NOTHING;

-- ======================
-- SAMPLE HOSPITALS AND DOCTORS
-- ======================

INSERT INTO hospitals (id, cnes, name, cnpj, phone, email, address, type, accreditation, is_active, created_at, updated_at) 
VALUES 
    ('hospital_001', '2077973', 'Hospital São Lucas', '12345678000100', '(11) 3456-7890', 'contato@saolucas.com.br', '{"street": "Rua das Flores, 123", "city": "São Paulo", "state": "SP", "zip": "01234-567"}', 'Privado', '{"JCI", "ONA"}', true, NOW(), NOW()),
    ('hospital_002', '2345678', 'Hospital Santa Maria', '98765432000100', '(11) 9876-5432', 'info@santamaria.com.br', '{"street": "Av. Paulista, 1000", "city": "São Paulo", "state": "SP", "zip": "01310-100"}', 'Filantrópico', '{"ONA"}', true, NOW(), NOW())
ON CONFLICT (cnes) DO NOTHING;

INSERT INTO doctors (id, crm, crm_state, name, specialties, phone, email, hospital, preferences, is_active, created_at, updated_at) 
VALUES 
    ('doctor_001', '123456', 'SP', 'Dr. João Silva', '{"Ortopedia", "Traumatologia"}', '(11) 98765-4321', 'joao.silva@email.com', 'Hospital São Lucas', '{"preferredBrands": ["Synthes", "Stryker"], "specialMaterials": ["Placas ósseas", "Parafusos"]}', true, NOW(), NOW()),
    ('doctor_002', '654321', 'SP', 'Dra. Maria Santos', '{"Cardiologia", "Cirurgia Cardiovascular"}', '(11) 91234-5678', 'maria.santos@email.com', 'Hospital Santa Maria', '{"preferredBrands": ["Medtronic", "Edwards"], "specialMaterials": ["Válvulas cardíacas", "Stents"]}', true, NOW(), NOW())
ON CONFLICT (crm) DO NOTHING;

-- ======================
-- SAMPLE PRODUCTS (OPME)
-- ======================

INSERT INTO products (id, sku, name, description, category, brand, supplier, ncm, anvisa, unit_price, cost_price, unit, min_stock, max_stock, current_stock, is_active, is_opme, specifications, created_at, updated_at) 
VALUES 
    ('prod_001', 'PLT-001', 'Placa Óssea Titânio 4 Furos', 'Placa de titânio para fixação óssea com 4 furos', 'Implantes Ortopédicos', 'Synthes', 'Medicon', '90211090', 'REG123456', 450.00, 300.00, 'UN', 5, 50, 25, true, true, '{"material": "Titânio", "furos": 4, "comprimento": "80mm"}', NOW(), NOW()),
    ('prod_002', 'PAR-001', 'Parafuso Cortical 4.5mm x 50mm', 'Parafuso cortical de titânio para fixação óssea', 'Implantes Ortopédicos', 'Synthes', 'Medicon', '90211090', 'REG123457', 35.00, 25.00, 'UN', 20, 200, 150, true, true, '{"material": "Titânio", "diametro": "4.5mm", "comprimento": "50mm"}', NOW(), NOW()),
    ('prod_003', 'STT-001', 'Stent Coronário Drug-Eluting', 'Stent coronário com liberação de medicamento', 'Cardiologia', 'Medtronic', 'Cardiotech', '90183900', 'REG789012', 2500.00, 1800.00, 'UN', 3, 30, 15, true, true, '{"diametro": "3.0mm", "comprimento": "18mm", "medicamento": "Sirolimus"}', NOW(), NOW())
ON CONFLICT (sku) DO NOTHING;

-- ======================
-- INDEXES FOR PERFORMANCE
-- ======================

-- User management indexes
CREATE INDEX IF NOT EXISTS idx_users_email_active ON users(email, is_active);
CREATE INDEX IF NOT EXISTS idx_users_role_department ON users(role, department);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_timestamp ON audit_logs(user_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_logs_resource_timestamp ON audit_logs(resource, timestamp);

-- Surgery management indexes  
CREATE INDEX IF NOT EXISTS idx_surgeries_scheduled_status ON surgeries(scheduled_at, status);
CREATE INDEX IF NOT EXISTS idx_surgeries_doctor_hospital ON surgeries(doctor_id, hospital_id);
CREATE INDEX IF NOT EXISTS idx_surgeries_patient_date ON surgeries(patient_id, scheduled_at);

-- Inventory indexes
CREATE INDEX IF NOT EXISTS idx_products_category_active ON products(category, is_active);
CREATE INDEX IF NOT EXISTS idx_products_brand_supplier ON products(brand, supplier);
CREATE INDEX IF NOT EXISTS idx_stock_movements_product_date ON stock_movements(product_id, created_at);
CREATE INDEX IF NOT EXISTS idx_containers_status_location ON containers(status, location);

-- Financial indexes
CREATE INDEX IF NOT EXISTS idx_transactions_account_date ON transactions(account_id, due_date);
CREATE INDEX IF NOT EXISTS idx_transactions_status_type ON transactions(status, type);
CREATE INDEX IF NOT EXISTS idx_accounts_type_active ON accounts(type, is_active);

-- ======================
-- FUNCTIONS AND TRIGGERS
-- ======================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply updated_at trigger to relevant tables
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_roles_updated_at BEFORE UPDATE ON roles FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON patients FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_doctors_updated_at BEFORE UPDATE ON doctors FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_hospitals_updated_at BEFORE UPDATE ON hospitals FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_surgeries_updated_at BEFORE UPDATE ON surgeries FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_containers_updated_at BEFORE UPDATE ON containers FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_accounts_updated_at BEFORE UPDATE ON accounts FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON transactions FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Function to log audit events
CREATE OR REPLACE FUNCTION audit_trigger_function()
RETURNS TRIGGER AS $$
DECLARE
    audit_user_id TEXT;
BEGIN
    -- Try to get user ID from current session (set by application)
    BEGIN
        audit_user_id := current_setting('audit.user_id');
    EXCEPTION
        WHEN OTHERS THEN
            audit_user_id := NULL;
    END;
    
    IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_logs(user_id, action, resource, resource_id, new_values, timestamp)
        VALUES(audit_user_id, 'CREATE', TG_TABLE_NAME, NEW.id::TEXT, row_to_json(NEW), NOW());
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_logs(user_id, action, resource, resource_id, old_values, new_values, timestamp)
        VALUES(audit_user_id, 'UPDATE', TG_TABLE_NAME, NEW.id::TEXT, row_to_json(OLD), row_to_json(NEW), NOW());
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO audit_logs(user_id, action, resource, resource_id, old_values, timestamp)
        VALUES(audit_user_id, 'DELETE', TG_TABLE_NAME, OLD.id::TEXT, row_to_json(OLD), NOW());
        RETURN OLD;
    END IF;
    
    RETURN NULL;
END;
$$ LANGUAGE 'plpgsql';

-- Apply audit triggers to important tables
CREATE TRIGGER audit_users AFTER INSERT OR UPDATE OR DELETE ON users FOR EACH ROW EXECUTE PROCEDURE audit_trigger_function();
CREATE TRIGGER audit_surgeries AFTER INSERT OR UPDATE OR DELETE ON surgeries FOR EACH ROW EXECUTE PROCEDURE audit_trigger_function();
CREATE TRIGGER audit_products AFTER INSERT OR UPDATE OR DELETE ON products FOR EACH ROW EXECUTE PROCEDURE audit_trigger_function();
CREATE TRIGGER audit_transactions AFTER INSERT OR UPDATE OR DELETE ON transactions FOR EACH ROW EXECUTE PROCEDURE audit_trigger_function();

COMMIT;